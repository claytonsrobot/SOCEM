Designer: Clayton Bennett
Blip: 10/16/2022

This folder includes the files necessary to build a SOCEM keyboard tray.
Fabrication method: Lasercut wood, assembled with wood glue, finished with wood stain.
To lasercut, import these DXF files into CorelDraw (in the Rapid Prototpying lab Gauss-Johnson, UIdaho)
Or, import the DXF files into some other software interface that allows you to prepare for laser cutting.

Parts include:
(x1) top
(x1) backplate
(x1) frontplate
(x2) shelf
(x2) sidewall 
(x2) spine
(x4) slat 

Wood thickness: 0.195 inches

The existing DXF files can be used, or new ones can be generated using Solidworks.
The dimensions of the Solidpart files are tied to the values in the equations text file: dimensions_keyboardTray.txt
TAKE HEED! The dimensions very much rely on the thickness of the wood.

You may, however, use wood of a different thickness.
To do this, open text file called: dimensions_keyboardTray.txt.
Change the "thickness_board" value to whatever material you have.
Before or after doing this, open your solidworks assembly file: assembly_keyboardTray.SLDASM
Update the assembly file, to adjust the parts.
Right click on each part to export a new DXF file for each part.

