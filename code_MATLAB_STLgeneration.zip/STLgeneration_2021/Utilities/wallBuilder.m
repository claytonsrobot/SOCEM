function [mat3D] = wallBuilder(mat3D,option1)
        curtaincolumn_NaN = NaN.*ones(length(mat3D(:,1)),1);
        curtaincolumn_zeros = zeros(length(mat3D(:,end)),1);
        mat3D(:,1) = curtaincolumn_zeros;
        mat3D(:,end) = curtaincolumn_NaN;
       
end
%% metadata
        % auuthor: Clayton Bennett
        % created: 05/1/2022


