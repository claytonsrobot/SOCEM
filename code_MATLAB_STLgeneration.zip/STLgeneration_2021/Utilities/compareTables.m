function[]=compareTables(a,b)
% compare any table a to any table b, checking each element for a mismatch.
% Author: Clayton Bennett
% Date: July 21sy, 2021
%% SANDBOX
for i=height(a)
    for j=1:15
        if string(table2cell(a(i,j)))~=string(table2cell(b(i,j)))
            T.File(i)
            j
        end
    end
end