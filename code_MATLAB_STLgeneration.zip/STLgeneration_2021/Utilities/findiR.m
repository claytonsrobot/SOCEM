function [iR] = findiR(reprow,iL)
    m=iL;
    while not((reprow(m)>0 || isnan(reprow(m)))&& (reprow(m+1)==0 || isnan(reprow(m+1))))
        m=m+1;
    end
    iR = m;
end