'''
HeightFixGenerator.py
Author: Austin Bebee (version 1)
Last edited: 02/15/2022, by Clayton Bennett (version 5)

Description:
    - Create spreadhseet
    - page one of plot name, horzx, and heightx values
    - page two of plot name, ideal height value

'''
# needed libraries
import math
import pandas as pd
from pandas import ExcelFile
from pandas import ExcelWriter
import numpy as np
from numpy import trapz
from datetime import date
import os
import xlsxwriter
# import peakutils
import matplotlib.pyplot as plt
from matplotlib.widgets import Cursor
# custom scripts
import EI_Interaction_Fx
import EI_No_Interaction_Fx
import pushDirection_fileNameScan
from optiH_v2 import optiH
from pushDirection_fileNameScan import pushDirection
import sideHitLengthRange_fileNameScan # not yet in service
from sideHitLengthRange_fileNameScan import sideHitLengthRange
#import generateGraphs_SOCEMAnalysis


# Edit these folders to change which data is analyzed and where they go
topFolder = r'D:\Instron Wheat Testing 2021\SAVED_DATA_2021'
analysisDirectory =  '\\August18\\' # EDIT HERE
##folderToProcess = r'D:\Instron Wheat Testing 2021\SAVED_DATA_2021\August5\encoderWorkedNo' # moved out
folderToProcess = topFolder + analysisDirectory + 'encoderWorkedYes' # moved out
addressProcessed = topFolder + analysisDirectory + 'EI_outputFiles' # moved 
analyzedFolder = topFolder + analysisDirectory +  'analyzedRaw' # new files
documentationFolder =  topFolder + analysisDirectory +  'Documentation' # where plot images are autosaved
harvestManual = date(2021,8,18) # EDIT DATE WHEN THE FOLDER IS CHANGED
loc = 'Genesee, Baldus Road'
#loc = (str(input('Location? Examples: { Genesee, Poxleitner Farm }, { Genesee, Badlus Road }, { Moscow, Plant Science Road } ')))

plotHeightSpreadsheet = r'D:\Instron Wheat Testing 2021\plotHeights2021.xlsx' # this shouldn't change for data within the same field (Example, Baldus Rd)

    
#generateGraphs = (str(input('Would you like graphs to be generated in the exported analysis files (y/n)? ')))


df2 = pd.read_excel(plotHeightSpreadsheet)
varietyList = df2.iloc[0]
varietyList = varietyList.to_numpy().tolist()
varietyList = varietyList[1:-2]
plotList = df2.iloc[1]
plotList = plotList.to_numpy().tolist()
plotList = plotList[1:-2]
heightsArray = df2.iloc[2:10,1:-2]
heightsArray = heightsArray.to_numpy()
optiHeights=[]

# MAIN FUNCTION    
for plotname in plotList: # loop through files in folder

    plotname = plotname.upper()
    plotnamesList = plotList
    plotIdx = plotList.index(plotname) # where does the filename match the concat of 
    variety = varietyList[plotIdx] #
    print('\n %' + variety + '\n %' + plotname)
    varietyAndPlotname = (variety + ', ' + plotname)      
    
    horz = [20, 40, 60, 80, 100, 120, 140,160] # Horizontal points here heights were measured. No heights for the current data set were measured beyond 160 inches. Unused horz numbers will be automatically removed.
    heights = [] # height at x
    # get heights along plot from user
    # alongPlot = getHeights()
    heights = heightsArray[:,plotIdx]
    heights = heights.tolist()

    i=0 # remove NaN values
    while i<len(heights):
        if math.isnan(heights[i]):
            nanIdx = i
            heights.pop(i)
            horz.pop(i)
        else:
            i=i+1
            
    # print('Horizontal: ', horz)
    # print('Heights: ', heights)

    [optiHeight,optiRat,optiScore, optiVar]=optiH(horz,heights,0.5)
    print('%'+optiHeight+'\n%' +optiRat+'\n%' +optiScore+'\n%'+str(optiVar))

    optiHeights.append(float(optiHeight))

print(optiHeights)
