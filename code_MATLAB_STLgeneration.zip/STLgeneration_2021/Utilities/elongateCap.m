function vector = elongateCap(vector)
    vector=[vector(1),vector,vector(end)];
end


