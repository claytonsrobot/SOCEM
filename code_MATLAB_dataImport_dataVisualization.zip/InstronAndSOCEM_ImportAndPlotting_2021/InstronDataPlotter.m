% Title: InstronDataPlotter
% Purpose: Print plots for rich INSTRON data, and input overview data, to check validity.
% Author: Clayton Bennett
% Date created: 2 August 2021
% Last updated: 2 August 2021

% User notes: Meant to be run manually section-by-section.
% Not all sections will apply to all datasets.
%% Set where graphs will be saved.
%directory; % type in manually. Where raw Instron files live, pulled in in previous scripts.
directory_processingCode = ('D:\Instron Wheat Testing 2021\MatlabCode\'); % not thoroughly modular, if the script location changes.
directory_saveGraphs = ('D:\Instron Wheat Testing 2021\SAVED_DATA_2021\graphs\'); %modular

%% Instron Data overviews, function version
% Plots all possible comparisons for each axes list for each table.
list_IAxes={'T_copy.AvgForce'};
list_TAxes={'T_copy.AreaUnderCurve', 'T_copy.EII', 'T_copy.EIN'};
list_axes={list_IAxes,list_TAxes};

toggle_save = 0; % 1 for save, 0 for don't save

cd(directory_processingCode) % To return to the directory where this script lives.

for l=1:numel(list_axes)
    for a=1:numel(list_axes{l})
        for b=1:numel(list_axes{l})
            if a ~= b
                [handle_plot_tableData,filenametext]=plot_tableData(list_axes{l}{a},list_axes{l}{b},toggle_save,directory_saveGraphs,T_copy,T_copy); % only change first three inputs: xdata, ydata, toggle_save
                cd(directory_processingCode) % To return to the directory where this script lives.
            end
        end
    end
end

%filenametext=plot_tableData('I.AveEI','I.AveMaxMoment',0,directory_saveGraphs,T,I); % only change first three inputs: xdata, ydata, toggle_save
%cd(directory_processingCode) % To return to the directory where this script lives.

close(handle_plot_tableData) % supressed 11/29/2021
%close
%% Sandbox: cycle through all vargnames
%% Instron Data overviews, script version

% I want to autpomatically generate the title, axis labels, and filename.

        % %% Edit these things:
        xdata='T_copy.AreaUnderCurve'; % Making it a string is necessary.
        ydata='T_copy.EIM';
        %I.AveDisplacementAtMaxLoad
        string_table = 'T_copy';
        toggle_save = 1;
        % %%%

% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %%
x=eval(xdata);
y=eval(ydata);
p = polyfit(x,y,1);
f = polyval(p,x);
handle_plot=plot(x,y,'o',x,f,'-');
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat('Experimental Wheat Plots'),stringFit},'Location','Northwest')

% %% Vars necessry to be in the workspace:
directory_saveGraphs;
directory_processingCode;

% %%%

% %%
% Important plots, from table T:
% LoadDeflectionSlope vs MaxLoad
%I.e. LoadDeflectionSlope vs MaxMoment
%I.e. EI vs MaxMoment
% See InstronCOlumnMagic_3.m for calculation details
% %% %%

cd(directory_saveGraphs) % To control where the graphs are saved.

% Use eval() to pull in whichever X and Y was listed above. YES!!
%handle_plot= plot(eval(xdata),eval(ydata),'b+');

set(handle_plot,'XDataSource',xdata)
set(handle_plot,'YDataSource',ydata)

string_title=strcat(xdata,'_.versus_.',ydata);
title(string_title)

%columnX=;
%xunit=I.Properties.VariableUnits(columnX);
%I.Properties.VariableNames

string_xlabel = strcat(extractAfter(xdata,'.')); % Assumes the data comes from a table
string_ylabel = strcat(extractAfter(ydata,'.')); % Assumes the data comes from a table

%string_title=strcat(xdata,'_.versus_.',ydata);
string_titleFront = {'SOCEM 2021, Wheat, '};
string_title=strcat(string_titleFront,string_xlabel,'_.versus_.',string_ylabel);
title(string_title)

for column = 1:numel(eval(string_table).Properties.VariableNames)
    if string(eval(string_table).Properties.VariableNames(column)) == string_xlabel
       string_xlabel = string(strcat(string_xlabel,'_.(',eval(string_table).Properties.VariableUnits(column),')'));
    elseif string(eval(string_table).Properties.VariableNames(column)) == string_ylabel
       string_ylabel = string(strcat(string_ylabel,'_.(',eval(string_table).Properties.VariableUnits(column),')'));
    end
end

% HOW DO I ADD A SPACE IN TEXT? Instead of an underscore and a period, which works well enough.

xlabel(string_xlabel)
ylabel(string_ylabel)

% This doesn't help me, because I can manually list the name, though it
% does make it easier to read and is a candidate.
handle_xlabel = get(gca,'XLabel');
handle_ylabel = get(gca,'YLabel');

fig = gcf;
filenametext =  string(strcat(erase(string_title,'.'),'.png'));

% Sometimes, you might not want to save the image to a file.
if toggle_save == 'yes' | toggle_save == 1 
    exportgraphics(fig, filenametext,'Resolution',300)
end

cd(directory_processingCode) % To return to the directory where this script lives.

%% Individual Instron graphs, with raw data and Load Deflection slope.
% Is T.Modulus from the overview files valid? It should be. Plot it.
% T.LoadDeflectionSlope from the overview files is not trusted and has been
%   replaced.
% Plot the new T.LoadDelfectionSlope (N/mm), which is a function of
% T.Modulus (MPa)
% Don't use this.
directory_saveGraphs = strcat(directory,'MATLABGraphs\');
cd(directory_saveGraphs) % To control where the graphs are saved.
for t=1:height(T)
    %plot(cell2mat(T.Time(t)),cell2mat(T.Force(t)))
    plot(cell2mat(T.Displacement(t)),cell2mat(T.Force(t)));
    hold on
    plot([0,T.DisplacementAtMaxLoad(t)],[0,T.LoadDeflectionSlope(t)*T.DisplacementAtMaxLoad(t)],'r-')
    title(strcat('Plot:',T.Plot(t),',Stem:',string(T.Stem(t)),',Run:',string(T.Run(t))));
    xlabel('Deflection (mm)');
    ylabel('Force (N)');
    fig =  gcf;
    filename_plot = strcat(string(T.Plot(t)),'_stem',string(T.Stem(t)),'_run',string(T.Run(t)),'.png');
    exportgraphics(fig, filename_plot,'Resolution',300)

    filename_plot
    
    hold off
end
cd(directory_processingCode) % To return to the directory where this script lives.
%% Plot  raw data from each Plot
directory_processingCode = ('D:\Instron Wheat Testing 2021\MatlabCode\'); % not thoroughly modular, if the script location changes.
directory_saveGraphs = ('D:\Instron Wheat Testing 2021\SAVED_DATA_2021\graphs\'); %modular
cd(directory_saveGraphs) % To control where the graphs are saved.


string_titleFront = {'SOCEM 2021, Wheat, EI for each run, +24hour'};
string_exportfilenamedetail = {'raw_peaks_Aug5_+24hour'};
%legendString = {'Raw Data', 'Peak Selection'};
legendString = {};
peakxlist=[];
peakforcelist=[];
    for t=1:height(T)
        %plot(cell2mat(T.Time(t)),cell2mat(T.Force(t)))
        if T.Analysis(t)=="TIME BASED"
            plot(cell2mat(T.Time(t)),cell2mat(T.ForcePerRow(t)),'-');
            xlabel('Time (sec)');
        else
            plot(cell2mat(T.Distance(t)),cell2mat(T.ForcePerRow(t)),'-');
            xlabel('Travel distance (in)');
        end
        % add in legend, inidividual numbers, and averages
        peakxlist(end+1:end+length(cell2mat(T.PeaksX(t)))) = cell2mat(T.PeaksX(t));
        peakforcelist(end+1:end+length(cell2mat(T.PeaksForce(t)))) = cell2mat(T.PeaksForce(t));
        if t == height(T) % final pass, where t+1 > height(t)
            title(strcat('Plot:',T.Plot(t)));
            %xlabel('Deflection (in)');
            ylabel('Force (pounds)');
            plot(peakxlist,peakforcelist,'k*');
            runsInGraph = sum(T.Plot(t)==T.Plot);
            legendString{end+1} = T.TestDetail(t);
            legendString{end+1} = 'Peak';
            handle_legend = legend(legendString,'Location','best');
%             if T.Plot(t)=={'CF246','CF341','CF349','CF444','CF447'}
%                 handle_legend = legend(legendString,'Location','North');
%             elseif T.Plot(t)=={'CF246'}
%                 handle_legend = legend(legendString,'Location','North');
%             end
            fig =  gcf;
            exportgraphics(fig, strcat(string(T.Plot(t)),'.png'),'Resolution',300)
            hold off
            
        elseif T.Plot(t) == T.Plot(t+1)
            hold on
            legendString{end+1} = T.TestDetail(t);
            
            %string_textbox = sprintf(append(string_textbox,'\n',string(T.Stem(t)),',',sprintf('%4.2f',T.LoadDeflectionSlope(t)),',',sprintf('%4.2f',T.EI(t))));
        elseif T.Plot(t) ~= T.Plot(t+1)
            title(strcat('Plot:',T.Plot(t)));
            %xlabel('Deflection (in)');
            %ylabel('Force (lbs)');
            plot(peakxlist,peakforcelist,'k*');
            runsInGraph = sum(T.Plot(t)==T.Plot);
            legendString{end+1} = T.TestDetail(t);
            legendString{end+1} = 'Peak';
            handle_legend = legend(legendString,'Location','best');
            legendString = {};%cell(runsInGraph,1);
            peakxlist=[];
            peakforcelist=[];
            %handle_legend = legend(); % How do I accumulate each Stem?
            %dim_textbox = [.2 .7 .3 .2];
            %string_textbox = sprintf(append(string_textbox,'\n',string(T.Stem(t)),',',sprintf('%4.2f',T.LoadDeflectionSlope(t)),',',sprintf('%4.2f',T.EI(t))));
            %handle_textbox = annotation('textbox',dim_textbox,'String',string_textbox);
            % CONTINUE WORKING HERE
            fig =  gcf;
            exportgraphics(fig, strcat(string(T.Plot(t)),'.png'),'Resolution',300)

            hold off
            %close gcf
            %dim_textbox = [.2 .7 .3 .2];
            %string_textbox = sprintf('Stem, LoadDeflectionSlope, EI');
            %clear handle_textbox
            
        end
    end
cd(directory_processingCode) % To return to the directory where this script lives.
%% Plot EIM ratio values from each plot, showing repeat hits, and exponentially fit the curve
directory_processingCode = ('D:\Instron Wheat Testing 2021\MatlabCode\'); % not thoroughly modular, if the script location changes.
directory_saveGraphs = ('D:\Instron Wheat Testing 2021\SAVED_DATA_2021\graphs\'); %modular
%cd(directory_saveGraphs) % To control where the graphs are saved.
cd(directory_processingCode)

xdata = T.j;
ydata = T.EIM;
string_xdata = 'T.j';
string_ydata = 'T.EIM';
string_table = 'T';

string_xlabel = strcat(extractAfter(string_xdata,'.')); % Assumes the data comes from a table
string_ylabel = strcat(extractAfter(string_ydata,'.')); % Assumes the data comes from a table

string_titleFront = {'SOCEM 2021, Wheat, EI_n/EI_1 for each run'};
string_exportfilenamedetail = {'powerFitABC_EIratio'};
legendString = {'EIM/EIM_1, from Bebee assesment tool', 'Power fit: y=a+b*x^c'};
%[abc,a,b,c,rsq,rmse,sse]=exponentialFitting(xdata,ydata,1,1,1);


for column = 1:numel(eval(string_table).Properties.VariableNames)
    if string(eval(string_table).Properties.VariableNames(column)) == string_xlabel
       string_xlabel = string(strcat(string_xlabel,'_.(',eval(string_table).Properties.VariableUnits(column),')'));
    elseif string(eval(string_table).Properties.VariableNames(column)) == string_ylabel
       string_ylabel = string(strcat(string_ylabel,'_.(',eval(string_table).Properties.VariableUnits(column),')'));
    end
end
string_ylabel = 'EI_n/EI_1 (ratio)';
%legendString = {};%cell(runsInGraph,1);
xlist = [];
ylist = [];
            
    for t=1:height(T)
        %plot(cell2mat(T.Time(t)),cell2mat(T.Force(t)))
%         try
%             plot(cell2mat(xdata(t)),cell2mat(ydata(t)),'o');
%         catch
%             plot(xdata(t),ydata(t),'o');
%         end
        % add in legend, inidividual numbers, and averages
        
        if t == height(T) % final pass, where t+1 > height(t)
            title(strcat(string_titleFront, 'Plot:',T.Plot(t)));
            xlabel(string_xlabel);
            ylabel(string_ylabel);
            
            %legendString{end+1} = T.TestDetail(t);
            
            %legendString = {'EI, Bebee algorithm result', 'Power fit'};
            xlist(end+1) = xdata(t);
            ylist(end+1) = ydata(t);
            xlist = xlist';
            ylist = ylist';
            ylist = ylist./ylist(1); % ratio
            [abc,a,b,c,rsq,rmse,sse]=powerFitting(xlist,ylist,1,1,1);
            axis([0, max(xlist)+1, min(ylist)-.2*(max(ylist)-min(ylist)), max(ylist)+.1*(max(ylist)-min(ylist))]);
            %legendString = {'EI, Bebee algorithm result', 'Power fit'};
            
            handle_legend = legend(legendString);
            title(strcat(string_titleFront, ', Plot:',T.Plot(t),{', '}));
            xlabel(string_xlabel);
            ylabel(string_ylabel);
            fig =  gcf;
            exportgraphics(fig, strcat(string(T.Plot(t)),string_exportfilenamedetail,'.png'),'Resolution',300)
            hold off
            
        elseif T.Plot(t) == T.Plot(t+1)
            %hold on
            %legendString{end+1} = T.TestDetail(t);
            xlist(end+1) = xdata(t);
            ylist(end+1) = ydata(t);
            %string_textbox = sprintf(append(string_textbox,'\n',string(T.Stem(t)),',',sprintf('%4.2f',T.LoadDeflectionSlope(t)),',',sprintf('%4.2f',T.EI(t))));
        elseif T.Plot(t) ~= T.Plot(t+1)
            
            xlist(end+1) = xdata(t);
            ylist(end+1) = ydata(t);
            %runsInGraph = sum(T.Plot(t)==T.Plot);
            %legendString{end+1} = T.TestDetail(t);
            
            xlist = xlist';
            ylist = ylist';
            ylist = ylist./ylist(1); % ratio
            [abc,a,b,c,rsq,rmse,sse]=powerFitting(xlist,ylist,1,1,1);
            
            %title(strcat('Plot:',T.Plot(t)));
            title(strcat(string_titleFront, ', Plot:',T.Plot(t),{', '}));
            xlabel(string_xlabel);
            ylabel(string_ylabel);
            axis([0, max(xlist)+1, min(ylist)-1, max(ylist)+1]);
            axis([0, max(xlist)+1, min(ylist)-.2*(max(ylist)-min(ylist)), max(ylist)+.1*(max(ylist)-min(ylist))]);
            %legendString = {'EI, Bebee algorithm result', 'Power fit'};
            handle_legend = legend(legendString);
            xlist = [];
            ylist = [];
            fig =  gcf;
            cd(directory_saveGraphs)
            exportgraphics(fig, strcat(string(T.Plot(t)),string_exportfilenamedetail,'.png'),'Resolution',300)
            cd(directory_processingCode)
            hold off
            %close gcf
            
        end
    end
%end
cd(directory_processingCode) % To return to the directory where this script lives.
%% Plot EIM or AUC values from each plot, showing repeat hits, and exponentially fit the curve
directory_processingCode = ('D:\Instron Wheat Testing 2021\MatlabCode\'); % not thoroughly modular, if the script location changes.
directory_saveGraphs = ('D:\Instron Wheat Testing 2021\SAVED_DATA_2021\graphs\'); %modular
%cd(directory_saveGraphs) % To control where the graphs are saved.
cd(directory_processingCode)

xdata = T.j;
ydata = T.EIM;
%ydata = T.AreaUnderCurve;
string_xdata = 'T.j';
string_ydata = 'T.EIM';
%string_ydata = 'T.AreaUnderCurve';
string_table = 'T';

string_xlabel = strcat(extractAfter(string_xdata,'.')); % Assumes the data comes from a table
string_ylabel = strcat(extractAfter(string_ydata,'.')); % Assumes the data comes from a table

string_titleFront = {'SOCEM 2021, Wheat, EI for each run, 1 hour'};
string_exportfilenamedetail = {'powerFitABC_EI_1hour'};
legendString = {'EIM, from Bebee assesment tool', 'Power fit: y=a+b*x^c'};
%legendString = {'Area Under Curve', 'Power fit: y=a+b*x^c'};
%[abc,a,b,c,rsq,rmse,sse]=exponentialFitting(xdata,ydata,1,1,1);


for column = 1:numel(eval(string_table).Properties.VariableNames)
    if string(eval(string_table).Properties.VariableNames(column)) == string_xlabel
       string_xlabel = string(strcat(string_xlabel,'_.(',eval(string_table).Properties.VariableUnits(column),')'));
    elseif string(eval(string_table).Properties.VariableNames(column)) == string_ylabel
       string_ylabel = string(strcat(string_ylabel,'_.(',eval(string_table).Properties.VariableUnits(column),')'));
    end
end
%legendString = {};%cell(runsInGraph,1);
xlist = [];
ylist = [];
            
    for t=1:height(T)
        %plot(cell2mat(T.Time(t)),cell2mat(T.Force(t)))
%         try
%             plot(cell2mat(xdata(t)),cell2mat(ydata(t)),'o');
%         catch
%             plot(xdata(t),ydata(t),'o');
%         end
        % add in legend, inidividual numbers, and averages
        
        if t == height(T) % final pass, where t+1 > height(t)
            title(strcat(string_titleFront, 'Plot:',T.Plot(t)));
            xlabel(string_xlabel);
            ylabel(string_ylabel);
            
            %legendString{end+1} = T.TestDetail(t);
            
            %legendString = {'EI, Bebee algorithm result', 'Power fit'};
            xlist(end+1) = xdata(t);
            ylist(end+1) = ydata(t);
            xlist = xlist';
            ylist = ylist';
            cd(directory_processingCode)
            [abc,a,b,c,rsq,rmse,sse]=powerFitting(xlist,ylist,1,1,1);
            axis([0, max(xlist)+1, min(ylist)-.2*(max(ylist)-min(ylist)), max(ylist)+.1*(max(ylist)-min(ylist))]);
            %legendString = {'EI, Bebee algorithm result', 'Power fit'};
            
            handle_legend = legend(legendString);
            title(strcat(string_titleFront, ', Plot:',T.Plot(t),{', '}));
            xlabel(string_xlabel);
            ylabel(string_ylabel);
            fig =  gcf;
            filename_plot =  strcat(string(T.Plot(t)),string_exportfilenamedetail,'.png');
            cd(directory_saveGraphs)
            exportgraphics(fig,filename_plot,'Resolution',300)
            hold off
            
        elseif T.Plot(t) == T.Plot(t+1)
            %hold on
            %legendString{end+1} = T.TestDetail(t);
            xlist(end+1) = xdata(t);
            ylist(end+1) = ydata(t);
            %string_textbox = sprintf(append(string_textbox,'\n',string(T.Stem(t)),',',sprintf('%4.2f',T.LoadDeflectionSlope(t)),',',sprintf('%4.2f',T.EI(t))));
        elseif T.Plot(t) ~= T.Plot(t+1)
            
            xlist(end+1) = xdata(t);
            ylist(end+1) = ydata(t);
            %runsInGraph = sum(T.Plot(t)==T.Plot);
            %legendString{end+1} = T.TestDetail(t);
            
            xlist = xlist';
            ylist = ylist';
            cd(directory_processingCode)
            [abc,a,b,c,rsq,rmse,sse]=powerFitting(xlist,ylist,1,1,1);
            
            %title(strcat('Plot:',T.Plot(t)));
            title(strcat(string_titleFront, ', Plot:',T.Plot(t),{', '}));
            xlabel(string_xlabel);
            ylabel(string_ylabel);
            axis([0, max(xlist)+1, min(ylist)-1, max(ylist)+1]);
            axis([0, max(xlist)+1, min(ylist)-.2*(max(ylist)-min(ylist)), max(ylist)+.1*(max(ylist)-min(ylist))]);
            %legendString = {'EI, Bebee algorithm result', 'Power fit'};
            handle_legend = legend(legendString);
            xlist = [];
            ylist = [];
            fig =  gcf;
            cd(directory_saveGraphs)
            exportgraphics(fig, strcat(string(T.Plot(t)),string_exportfilenamedetail,'.png'),'Resolution',300)
            hold off
            %close gcf
            
        end
    end
%end
cd(directory_processingCode) % To return to the directory where this script lives.
%% Plot EIM values vs Area Under Curve from each plot, showing repeat hits, and exponentially fit the curve
directory_processingCode = ('D:\Instron Wheat Testing 2021\MatlabCode\'); % not thoroughly modular, if the script location changes.
directory_saveGraphs = ('D:\Instron Wheat Testing 2021\SAVED_DATA_2021\graphs\'); %modular
%cd(directory_saveGraphs) % To control where the graphs are saved.
cd(directory_processingCode)


string_xdata = 'T.AreaUnderCurve';
string_ydata = 'T.EIM';
string_table = 'T';
xdata = eval(string_xdata);
ydata = eval(string_ydata);

string_titleFront = {'SOCEM 2021, Wheat, EIM vs AUC for each run'};
string_exportfilenamedetail = {'linearFitABC_EIvsAUC'};
legendString = {'Each test', 'Linear fit: y=a+b*x'};

string_xlabel = strcat(extractAfter(string_xdata,'.')); % Assumes the data comes from a table
string_ylabel = strcat(extractAfter(string_ydata,'.')); % Assumes the data comes from a table
%[abc,a,b,c,rsq,rmse,sse]=exponentialFitting(xdata,ydata,1,1,1);


for column = 1:numel(eval(string_table).Properties.VariableNames)
    if string(eval(string_table).Properties.VariableNames(column)) == string_xlabel
       string_xlabel = string(strcat(string_xlabel,'_.(',eval(string_table).Properties.VariableUnits(column),')'));
    elseif string(eval(string_table).Properties.VariableNames(column)) == string_ylabel
       string_ylabel = string(strcat(string_ylabel,'_.(',eval(string_table).Properties.VariableUnits(column),')'));
    end
end

%legendString = {};%cell(runsInGraph,1);
xlist = [];
ylist = [];
            
    for t=1:height(T)
        %plot(cell2mat(T.Time(t)),cell2mat(T.Force(t)))
%         try
%             plot(cell2mat(xdata(t)),cell2mat(ydata(t)),'o');
%         catch
%             plot(xdata(t),ydata(t),'o');
%         end
        % add in legend, inidividual numbers, and averages
        
        if t == height(T) % final pass, where t+1 > height(t)

            
            %legendString{end+1} = T.TestDetail(t);
            
            %legendString = {'EI, Bebee algorithm result', 'Power fit'};
            xlist(end+1) = xdata(t);
            ylist(end+1) = ydata(t);
            xlist = xlist';
            ylist = ylist';
            %ylist = ylist./ylist(1); % ratio
            [abc,a,b,c,rsq,rmse,sse,lm,f0,string1]=linearFitting(xlist,ylist,1,1,1);
            ha=annotation(gcf,'textbox',[0.121,0.78,1,1],'String',string1,'EdgeColor','none','FitBoxToText','on','verticalalignment', 'bottom', 'color','k');
    
            %axis([0, max(xlist)+1, min(ylist)-.2*(max(ylist)-min(ylist)), max(ylist)+.1*(max(ylist)-min(ylist))]);
            %legendString = {'EI, Bebee algorithm result', 'Power fit'};
            
            handle_legend = legend(legendString, 'Location','best');
            title(strcat(string_titleFront, ', Plot:',T.Plot(t),{', '}));
            xlabel(string_xlabel);
            ylabel(string_ylabel);
            
            fig =  gcf;
            cd(directory_saveGraphs)
            filename_plot = strcat(string(T.Plot(t)),string_exportfilenamedetail,'.png');
            exportgraphics(fig, filename_plot,'Resolution',300)
            
            hold off
            
        elseif T.Plot(t) == T.Plot(t+1)
            %hold on
            %legendString{end+1} = T.TestDetail(t);
            xlist(end+1) = xdata(t);
            ylist(end+1) = ydata(t);
            %string_textbox = sprintf(append(string_textbox,'\n',string(T.Stem(t)),',',sprintf('%4.2f',T.LoadDeflectionSlope(t)),',',sprintf('%4.2f',T.EI(t))));
        elseif T.Plot(t) ~= T.Plot(t+1)
            xlist(end+1) = xdata(t);
            ylist(end+1) = ydata(t);
            %runsInGraph = sum(T.Plot(t)==T.Plot);
            %legendString{end+1} = T.TestDetail(t);
            
            xlist = xlist';
            ylist = ylist';
            %ylist = ylist./ylist(1); % ratio
            [abc,a,b,c,rsq,rmse,sse,lm,f0,string1]=linearFitting(xlist,ylist,1,1,1);
            ha=annotation(gcf,'textbox',[0.121,0.78,1,1],'String',string1,'EdgeColor', 'none','FitBoxToText','on',  'verticalalignment', 'bottom', 'color','k');
    
            %title(strcat('Plot:',T.Plot(t)));
            title(strcat(string_titleFront, ', Plot:',T.Plot(t),{', '}));
            xlabel(string_xlabel);
            ylabel(string_ylabel);
            %axis([0, max(xlist)+1, min(ylist)-1, max(ylist)+1]);
            %axis([0, max(xlist)+1, min(ylist)-.2*(max(ylist)-min(ylist)), max(ylist)+.1*(max(ylist)-min(ylist))]);
            %legendString = {'EI, Bebee algorithm result', 'Power fit'};
            handle_legend = legend(legendString, 'Location','best');
            xlist = [];
            ylist = [];
            fig =  gcf;
            cd(directory_saveGraphs)
            filename_plot = strcat(string(T.Plot(t)),string_exportfilenamedetail,'.png');
            exportgraphics(fig, filename_plot,'Resolution',300)
            cd(directory_processingCode)
            close(fig)
            hold off
            
            
        end
    end
%end
cd(directory_processingCode) % To return to the directory where this script lives.
%% Whole Stem graphs, with repated runs, for cyclic tests
for t=1:height(T)
    %plot(cell2mat(T.Time(t)),cell2mat(T.Force(t)))
    plot(cell2mat(T.Displacement(t)),cell2mat(T.Force(t)));
    if T.Stem(t) == T.Stem(t+1)
        hold on
    elseif T.Stem(t) ~= T.Stem(t+1)
        title(strcat('Plot:',T.Plot(t),',Stem:',string(T.Stem(t))));
        xlabel('Deflection (mm)');
        ylabel('Force (N)');
        fig =  gcf;
        exportgraphics(fig, strcat(string(T.Plot(t)),'_stem',string(T.Stem(t)),'.png'),'Resolution',300)
        directory_saveGraphs = strcat(directory,'individualGraphs\');
        hold off
    end
end
%% All data in directory overview
% Different colors for differnt variety types