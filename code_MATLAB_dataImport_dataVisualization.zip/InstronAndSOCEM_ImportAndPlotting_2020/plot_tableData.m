% I want to autpomatically generate the title, axis labels, and filename.

%function [handle_plot_tableData,filenametext] = plot_tableData(xdata,ydata,toggle_save,directory_saveGraphs,S)%,directory_processingCode
function [handle_plot_tableData,filenametext] = plot_tableData(xdata,ydata,toggle_save,directory_saveGraphs,T,I)%,directory_processingCode)
        % %% Edit these things:
        %xdata=string(inputname(1))
        %ydata=string(inputname(2))
        %xdata='I.AveDisplacementAtMaxLoad'; % Making it a string is necessary.
        %ydata='I.AveMaxLoad';
        %I.AveMaxLoad
        %toggle_save = 1;
        % %%%

% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %%


cd(directory_saveGraphs) % To control where the graphs are saved.
% Use eval() to pull in whichever X and Y was listed above. YES!!
handle_plot_tableData= plot(eval(xdata),eval(ydata),'b+');

set(handle_plot_tableData,'XDataSource',xdata)
set(handle_plot_tableData,'YDataSource',ydata)

string_title=strcat(xdata,'_.versus_.',ydata);
title(string_title)

string_xlabel = strcat(extractAfter(xdata,'.')); % Assumes the data comes from a table
string_ylabel = strcat(extractAfter(ydata,'.')); % Assumes the data comes from a table

string_table = extractBefore(xdata,'.');

for column = 1:numel(eval(string_table).Properties.VariableNames)
    if string(eval(string_table).Properties.VariableNames(column)) == string_xlabel
       string_xlabel = string(strcat(string_xlabel,'_.(',eval(string_table).Properties.VariableUnits(column),')'));
    elseif string(eval(string_table).Properties.VariableNames(column)) == string_ylabel
       string_ylabel = string(strcat(string_ylabel,'_.(',eval(string_table).Properties.VariableUnits(column),')'));
    end
end

% HOW DO I ADD A SPACE IN TEXT? Instead of an underscore and a period, which works well enough.

xlabel(string_xlabel)
ylabel(string_ylabel)

% This doesn't help me, because I can manually list the name, though it
% does make it easier to read and is a candidate.
%handle_xlabel = get(gca,'XLabel');
%handle_ylabel = get(gca,'YLabel');

fig = gcf;
filenametext = strcat(erase(string_title,'.'),'.png');

% Sometimes, you might not want to save the image to a file.
if toggle_save == 'yes' | toggle_save == 1 
    exportgraphics(fig, filenametext,'Resolution',300)
end

%cd(directory_processingCode) % To return to the directory where this script lives.
end