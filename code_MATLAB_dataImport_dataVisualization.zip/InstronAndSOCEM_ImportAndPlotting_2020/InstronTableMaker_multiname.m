function[T]=InstronTableMaker_multiname(directory, individualFileNameList,overviewFileNameList,cyclic)

% To input multiple expected names, use a list: T = InstronTableMaker({'hardwinterwheat*.csv','clearfield*.csv','softwinterwheat*.csv'},0SBF*.csv,cyclic) 

% Run InstronTableMaker() for each item in the list, generate separate
% tables, then combine them into one table T.
% individualFileNameList and overviewFileNameList must match in length.
n=numel(individualFileNameList);
T_save = [];

for i=1:n
T=(InstronTableMaker(directory,string(individualFileNameList(i)),string(overviewFileNameList(i)),cyclic));
if i == 1
    %T = T;
    T_save = T;
    else
    indexOffset = height(T_save);
    T = [T_save; T];
    for k = (indexOffset+1):height(T)
        T.i(k)=indexOffset+T.i(k);
    end
end
T_save = T;
%fprintf('%c', string(individualFileNameList(i)))
end