3D print with nylon filament.
Use brass inserts.
The current lid differs from the DARLING lid in that it allows for both types of screens to be used.