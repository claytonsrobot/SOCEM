% name: InstronColumnMagic_3.m
% author: Clayton Bennett
% created: 15 July 2021
% last edited: 15 July 2021

% Necessary vars: T; % as T_barely or T_wheat
% This script reorders columns, calculates EI, and generally preps it to be
% compared to SOCEM data
%% PREPARE TABLE FOR MORE VALUES FOR CALCULATIONS
T.MaxMoment = nan(height(T),1);
T.EI = nan(height(T),1);
T.LoadDeflectionSlope = nan(height(T),1);
%% vars to create and calculate:
%    T.MaxMoment(i)% Nmm, failure moment
%    T.EI(i) % Nmm^2 % EI=(F/y)*L^3/48=(loadDeflectionSlope)*L^3/48;
%    T.LoadDeflectionSlope(i) % N/mm, slope of load, =48/(80^3))*T.Modulus*(5^4)
%    1.2732e+03=48/(80^3)*T.Modulus(j)*(5^4)/(wheatInstron2020_IndividualAndOverview.LoadDeflectionSlope(j))
% EDIT CONSTANT 1.2732e+03 
T.MaxMoment=T.MaxLoad.*20.000000; %  PRECISION ERROR
T.LoadDeflectionSlope=48/(80^3)*T.Modulus*(5^4)/1273.23954473516; % where does 1273.23954473516 come from? 80=L
T.EI=T.LoadDeflectionSlope/48*(80^3); %PRECISION ERROR, probably resolved one T.LoadDeflectionSlope is fixed
T.EI=T.EI./1.00003105932702; % why? Who knows. To make T match existing wheatInstron2020_IndividualAndOverview table
T.LoadDeflectionSlope=T.LoadDeflectionSlope/1.00003105932702; % why? Who knows. ^^
% given numbers: Modulus
% Load Deflection Slope is manually replaced and not trusted

%% vars to replace: 
%    T.MaxLoad(i) with T.MaxLoad_calculated(i) 
%    T.DisplacementAtMaxLoad(i) with T.DisplacementAtMaxLoad_calculated(i)
%% vars to delete:
T.Modulus=[];
T.LoadDeflection=[];
T.DisplacementAtMaxLoad=[];
T.MaxLoad=[];
T = renamevars(T,["DisplacementAtMaxLoad_calculated","MaxLoad_calculated"], ...
                 ["DisplacementAtMaxLoad","MaxLoad"]);
%% Reorder vars
T = movevars(T,'LoadDeflectionSlope','After','BreakType');
T = movevars(T,'BreakType','After','EI');
T = movevars(T,'Notes','After','BreakType');

%% Units and descriptions
T.Properties.VariableUnits = {'','','', '', '','','', 's', 'mm', 'N', 'N/mm', 'N', 'mm', 'N*mm', 'N*mm^2', '', ''};
T.Properties.VariableDescriptions{'MaxMoment'} = '';
T.Properties.VariableDescriptions{'EI'} = '';
T.Properties.VariableDescriptions{'LoadDeflectionSlope'} = '';

%% Save name
% T_wheat=T;
%T_barley=T;



