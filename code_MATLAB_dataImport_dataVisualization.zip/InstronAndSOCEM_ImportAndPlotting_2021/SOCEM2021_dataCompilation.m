% Title: SOCEM2021_dataCompilation.m
% Author: Clayton Bennett
% Created: 17 February 2022
% Last edited: 17 February 2022
%
% Purpose: 
% - Pull in data from analyzed SOCEM files, in "EI, Analyzed" and "EI,
%      Analyzed_timebased" folders.

format compact
%% Import data

directory_script = 'D:\Instron Wheat Testing 2021\MatlabCode';
directory_data = 'D:\Instron Wheat Testing 2021\SAVED_DATA_2021\'; % overview files and height data lives here
level1names = {'August5','August6','August10','August13','August16','August18','August23','August23b - cellularDensity','August28','August28b - cellularDensity','August29','August29b'};
level2names = {'EI_outputFiles','EI_outputFiles_timebased'};

i=5; %6
j=1;
activefolder = strcat(directory_data,level1names{i},'\',level2names{j},'\');
cd(activefolder)

list_csvfiles = dir('*.xlsx');
n_files = numel(list_csvfiles)'; 


% If '\' is not input by the user as the final character in the directory
% assignment, add  it.
% 
if (directory_data(end)~='\')
    directory_data = strcat(directory_data,'\');
end

if (directory_script(end)~='\')
    directory_script = strcat(directory_script,'\');
end
% %%
%% Prepare the table, T
varnames = {'i','j','Run','Hour','Analysis','Variety','Plot','TestDetail','FilenameRaw','Rows','ForceBarHeight',...
    'AvgHeight','AvgStemCount','SampleDistance','Spacing','AvgForcePeak',...
    'AvgForce','AreaUnderCurve',...
    'EII','EIN','EIM','AvgEI_Is','StdEI_Is','AvgEI_Ns','StdEI_Ns','AvgEI_Ms','StdEI_Ms',...
    'xCut','tCut','HorzX','StemHeightsX','PeaksX','PeaksForce','AssumedHeight',...
    'EI_Is','EI_Ns','EI_Ms','Time','Distance','ForcePerRow','Notes'};
vartypes = {'int64','int64','string','int64','string','string','string','string','string'...
    ,'int64','double','double','double','double','double','double','double','double','double'...
    ,'double','double','double','double','double','double','double','double'...
    ,'cell','cell','cell','cell','cell','cell','cell','cell','cell','cell','cell','cell','cell'...
    ,'string'};
%n_nodes_guess = 28;
T = table('Size',[n_files,numel(varnames)],'VariableNames',varnames,'VariableTypes',vartypes);

%% Import overview data, and populate stem, overviewfile, and plot


%%
% n_nodes_guess = n_files*10;
idxs_names = zeros(n_files,1);

for i=1:n_files
    idxs_names(i)=i*6+1-6;
end
tc=struct2cell(list_csvfiles);
names_analyzedfiles = tc(idxs_names');


handle_waitbar_overviewFiles=waitbar(0,strcat('Data is being imported from ',string(n_files),' overview Instron files. Computer speed, go!'));

idx=1;
%%
for i=1:n_files
    
    filename = strcat(activefolder,string(names_analyzedfiles(i)));
    [ndata_notUsed, text_notUsed, c_sheet1DataPullIn] = xlsread(strcat(activefolder,string(names_analyzedfiles(i))),'EI_Computations'); %c is of class cell
    [ndata_notUsed, text_notUsed, c_sheet1bDataPullIn] = xlsread(strcat(activefolder,string(names_analyzedfiles(i))),'EI_Computations','AB1:AG12'); %c is of class cell
    [ndata_notUsed, text_notUsed, c_sheet2DataPullIn] = xlsread(strcat(activefolder,string(names_analyzedfiles(i))),'Details'); %c is of class cell
    %%
    sheetname1 = 'EI_Computations';
    sheetname2 = 'Details';
    opts1 = detectImportOptions(strfile,'Sheet',sheetname1);
    opts1b = detectImportOptions(strfile,'Sheet',sheetname1,"PreserveVariableNames",1);
    opts2 = detectImportOptions(strfile,'Sheet',sheetname2);
    opts2b = detectImportOptions(strfile,'Sheet',sheetname2,"PreserveVariableNames",1);
    colrangeOneTallSheet1=[];
    colrangeTwoTallSheet1=[];
    colrangeNotVeryTallSheet1=[];
    colrangeNumberOfClicksTallSheet1=[];
    colrangeOneTallSheet2=[];
    colrangeTwoTallSheet2=[];
    colrangeNotVeryTallSheet2=[];
    colrangeSuperTallSheet2 = [];
    
    headersOneTallSheet1 = {'Analysis description','Variety','Plot','Test description','Filename','Rows'...
        ,'Force bar height (in)','Avg height (in)','Avg stem count','Sample distance (in)','Spacing (in)'...
        ,'Avg force peak (lbs)','Avg force (lbs), =(Area under curve)/(xCut[1]-xCut[0])','Area under curve (lbs*in)'...
        ,'EI-I (lbs*in^2)','EI-N (lbs*in^2)'...
        ,'EI-M (lbs*in^2)','Avg EI-Is (lbs*in^2)','Std. EI-Is (lbs*in^2)','Avg EI-Ns (lbs*in^2)','Std. EI-Ns (lbs*in^2)'...
        ,'Avg EI-Ms (lbs*in^2)','Std. EI-Ms (lbs*in^2)'};
    headersTwoTallSheet1={'xCut (in), Distance, analysis range','tCut (sec), Time, analysis range'};
    headersNotVeryTallSheet1={'Horizontal point of vertical height measurement (in.)','Stem heights at x (in.)'};
    headersNumberOfClicksTallSheet1={'x of force peak (in.)','Force peaks at x (lbs.)'...
        ,'Assumed height (in.), hatPeaks','EI-Is (lbs*in^2)','EI-Ns(lbs*in^2)','EI-Ms (lbs*in^2)'};
    headersOneTallSheet2={'Rows','Avg stem count','Sample distance (in)','Filename'};
    headersSuperTallSheet2 = {'Time (s)','Distance (in)','Force/row (lbs)'}; % a list of all variables that are super long, i.e. raw data
    
    for j=1:numel(headersOneTallSheet1)
        colrangeOneTallSheet1(end+1)=find(string(opts1b.VariableNames)==headersOneTallSheet1{j});
    end
    
    for j=1:numel(headersTwoTallSheet1)
        colrangeTwoTallSheet1(end+1)=find(string(opts1b.VariableNames)==headersTwoTallSheet1{j});
    end
    for j=1:numel(headersNotVeryTallSheet1)
        colrangeNotVeryTallSheet1(end+1)=find(string(opts1b.VariableNames)==headersNotVeryTallSheet1{j});
    end
    for j=1:numel(headersNumberOfClicksTallSheet1)
        colrangeNumberOfClicksTallSheet1(end+1)=find(string(opts1b.VariableNames)==headersNumberOfClicksTallSheet1{j});
    end
    for j=1:numel(headersOneTallSheet2)
        colrangeOneTallSheet2(end+1)=find(string(opts2b.VariableNames)==headersOneTallSheet2{j});
    end
    for j=1:numel(headersSuperTallSheet2)
        colrangeSuperTallSheet2(end+1)=find(string(opts2b.VariableNames)==headersSuperTallSheet2{j});
    end
    
    Alphabet = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AF','AG','AH','AI','AJ','AK','AL','AM','AN','AO','AP','AQ'};
    colrangeAlphaOneTallSheet1=string({Alphabet{colrangeOneTallSheet1}});
    colrangeAlphaTwoTallSheet1=string({Alphabet{colrangeTwoTallSheet1}});
    colrangeAlphaNotVeryTallSheet1=string({Alphabet{colrangeNotVeryTallSheet1}});
    colrangeAlphaNumberOfClicksTallSheet1=string({Alphabet{colrangeNumberOfClicksTallSheet1}});
    colrangeAlphaOneTallSheet2=string({Alphabet{colrangeOneTallSheet2}});
    colrangeAlphaSuperTallSheet2=string({Alphabet{colrangeSuperTallSheet2}});
   
    rangeOneTallSheet1 = strcat(colrangeAlphaOneTallSheet1(1),"1:",colrangeAlphaOneTallSheet1(end),"2"); % Assumes they're all together in a group, and that no columns are skipped
    rangeTwoTallSheet1 = strcat(colrangeAlphaTwoTallSheet1(1),"1:",colrangeAlphaTwoTallSheet1(end),"3");
    rangeNotVeryTallSheet1 = strcat(colrangeAlphaNotVeryTallSheet1(1),":",colrangeAlphaNotVeryTallSheet1(end));
    rangeNumberOfClicksTallSheet1 = strcat(colrangeAlphaNumberOfClicksTallSheet1(1),":",colrangeAlphaNumberOfClicksTallSheet1(end));
    rangeOneTallSheet2 = strcat(colrangeAlphaOneTallSheet2(1),"1:",colrangeAlphaOneTallSheet2(end),"2");
    rangeSuperTallSheet2 = strcat(colrangeAlphaSuperTallSheet2(1),":",colrangeAlphaSuperTallSheet2(end));
    %% other way: Import each column individually, the n trim nans, then count lengths
    % package any longer than 1
    % 1. Read, 2. Trim, 3. Package as cell is length > 1
    % do this for every column from column #1 for last column, which  # =
    % numel(opts.VariableNames)
    %%
    t_sheet1aDataPullIn=readtable(filename,'Sheet',sheetname1,'Range','A1:W2','FileType','spreadsheet','ReadVariableNames',true,'PreserveVariableNames',true); 
    t_sheet1bDataPullIn=readtable(filename,'Sheet',sheetname1,'Range','X1:Y3','FileType','spreadsheet','ReadVariableNames',true,'PreserveVariableNames',true); 
    t_sheet1cDataPullIn=readtable(filename,'Sheet',sheetname1,'Range','Z:AA','FileType','spreadsheet','ReadVariableNames',true,'PreserveVariableNames',true); 
    t_sheet1dDataPullIn=readtable(filename,'Sheet',sheetname1,'Range','AB:AG','FileType','spreadsheet','ReadVariableNames',true,'PreserveVariableNames',true); 
    t_sheet2DataPullIn=readtable(filename,'Sheet',sheetname2,'Range','A:C','FileType','spreadsheet','ReadVariableNames',true,'PreserveVariableNames',true); 

    
    
    nan=1;
    while nan<=height(t_sheet1dDataPullIn)
        if isnan(table2array(t_sheet1dDataPullIn(nan,1)))
            %c_sheet1bDataPullIn(nan,:)={};
            t_sheet1dDataPullIn = t_sheet1dDataPullIn([1:(nan-1)],:);
        else
            nan=nan+1;
        end
    end
    fprintf('%d.', i)
    waitbar(i/n_files,handle_waitbar_overviewFiles)
    
    t_sheet1d = table('Size',[height(t_sheet1dDataPullIn),numel(t_sheet1dDataPullIn.Properties.VariableNames)],'VariableNames',t_sheet1dDataPullIn.Properties.VariableNames,'VariableTypes',{'double','double','double','double','double','double'});
    
    t_sheet1d(:,[1]) = t_sheet1dDataPullIn(:,[1]);
    try
        t_sheet1d(:,[2]) = t_sheet1dDataPullIn(:,[2]);
    catch
        try
            t_sheet1d(:,[2])=array2table(str2num(cell2mat(table2array(t_sheet1dDataPullIn(:,[2])))),'VariableNames',t_sheet1dDataPullIn.Properties.VariableNames(2));
        catch
            for r=1:height(t_sheet1dDataPullIn(:,[2]))
                t_sheet1d(r,[2])=array2table(str2num(cell2mat(table2array(t_sheet1dDataPullIn(r,[2])))),'VariableNames',t_sheet1dDataPullIn.Properties.VariableNames(2));
            end
        end
    end
    
    try
        t_sheet1d(:,[3]) = t_sheet1dDataPullIn(:,[3]);
    catch
        try
            t_sheet1d(:,[3])=array2table(str2num(cell2mat(table2array(t_sheet1dDataPullIn(:,[3])))),'VariableNames',t_sheet1dDataPullIn.Properties.VariableNames(3));
        catch
            for r=1:height(t_sheet1dDataPullIn(:,[3]))
                t_sheet1d(r,[3])=array2table(str2num(cell2mat(table2array(t_sheet1dDataPullIn(r,[3])))),'VariableNames',t_sheet1dDataPullIn.Properties.VariableNames(3));
            end
        end
    end
    try
        t_sheet1d(:,[4]) = t_sheet1dDataPullIn(:,[4]);
    catch
        try
            t_sheet1d(:,[4])=array2table(str2num(cell2mat(table2array(t_sheet1dDataPullIn(:,[4])))),'VariableNames',t_sheet1dDataPullIn.Properties.VariableNames(4));
        catch
            for r=1:height(t_sheet1dDataPullIn(:,[4]))
                t_sheet1d(r,[4])=array2table(str2num(cell2mat(table2array(t_sheet1dDataPullIn(r,[4])))),'VariableNames',t_sheet1dDataPullIn.Properties.VariableNames(4));
            end
        end
    end
    
    try
        t_sheet1d(:,[5]) = t_sheet1dDataPullIn(:,[5]);
    catch
        try
            t_sheet1d(:,[5])=array2table(str2num(cell2mat(table2array(t_sheet1dDataPullIn(:,[5])))),'VariableNames',t_sheet1dDataPullIn.Properties.VariableNames(5));
        catch
            for r=1:height(t_sheet1dDataPullIn(:,[5]))
                t_sheet1d(r,[5])=array2table(str2num(cell2mat(table2array(t_sheet1dDataPullIn(r,[5])))),'VariableNames',t_sheet1dDataPullIn.Properties.VariableNames(5));
            end
        end
    end
    t_sheet1d(:,[6]) = t_sheet1dDataPullIn(:,[6]);
    %
            

            clear StiffnessChoicesArray StiffnessSlopesArray
            set1varnames = cell2mat(c_sheet1DataPullIn(1,1:5));
            %set1 = cell2mat(c_sheet1DataPullIn(2,1:5));
            set1bvarnames = cell2mat(c_sheet1DataPullIn(1,6:23));
            %set1b = cell2mat(c_sheet1DataPullIn(2,6:23));
            set2varnames = cell2mat(c_sheet1DataPullIn(1,24:33));
            %set2 = cell2mat(c_sheet1DataPullIn(2:end,24:33));
            set3varnames = cell2mat(c_sheet2DataPullIn(1,1:3));
            set3 = cell2mat(c_sheet2DataPullIn(2:end,1:3));


T.Analysis(i) = string(cell2mat(c_sheet1DataPullIn(2,1)));
T.Variety(i) = string(cell2mat(c_sheet1DataPullIn(2,2)));
T.Plot(i) = string(cell2mat(c_sheet1DataPullIn(2,3)));
T.TestDetail(i) = string(cell2mat(c_sheet1DataPullIn(2,4)));
T.FilenameRaw(i) = string(cell2mat(c_sheet1DataPullIn(2,5)));
T.Rows(i) = cell2mat(c_sheet1DataPullIn(2,6));
T.ForceBarHeight(i) = cell2mat(c_sheet1DataPullIn(2,7));
T.AvgHeight(i) = cell2mat(c_sheet1DataPullIn(2,8));
T.AvgStemCount(i) = cell2mat(c_sheet1DataPullIn(2,9));
T.SampleDistance(i) = cell2mat(c_sheet1DataPullIn(2,10));

% This won't work for all dates, but it works for August 6
    T.i(i) = i;
    try
        T.j(i) = str2num(T.TestDetail(i));
        T.Run(i) = str2num(T.TestDetail(i));
        T.Hour(i) = 0;
    catch
        try
            detail = T.TestDetail(i);
            T.j(i) = str2num(extractAfter(detail,'_'));
            T.Run(i) = (T.TestDetail(i));
            T.Hour(i) = str2num(extractBefore(detail,'+hour'));
        catch
                detail = T.TestDetail(i);
                if isempty(str2num(extractAfter(detail,'_')))
                    T.j(i) = 1;
                elseif contains(detail,'Aug16')
                    T.j(i) = str2num(extractAfter(extractAfter(detail,'_'),'_'));
                else
                    T.j(i) = str2num(extractAfter(detail,'_'));
                end
                T.Run(i) = (T.TestDetail(i));
                
                if contains(detail,'Aug16') || contains(detail,'Aug18')
                    T.Hour(i)=0;
                else
                    T.Hour(i) = str2num(extractBefore(detail,'hour'));
                end
            
        end
    end


if isnumeric(cell2mat(c_sheet1DataPullIn(2,11)))
    T.Spacing(i) = cell2mat(c_sheet1DataPullIn(2,11));
else
    T.Spacing(i) = str2num(cell2mat(c_sheet1DataPullIn(2,11)));
end

if isnumeric(cell2mat(c_sheet1DataPullIn(2,12)))
    T.AvgForcePeak(i) = cell2mat(c_sheet1DataPullIn(2,12));
else
    T.AvgForcePeak(i) = str2num(cell2mat(c_sheet1DataPullIn(2,12)));
end

if isnumeric(cell2mat(c_sheet1DataPullIn(2,13)))
    T.AvgForce(i) = cell2mat(c_sheet1DataPullIn(2,13));
else
    T.AvgForce(i) = str2num(cell2mat(c_sheet1DataPullIn(2,13)));
end

if isnumeric(cell2mat(c_sheet1DataPullIn(2,14)))
    T.AreaUnderCurve(i) = cell2mat(c_sheet1DataPullIn(2,14));
else
    T.AreaUnderCurve(i) = str2num(cell2mat(c_sheet1DataPullIn(2,14)));
end

if isnumeric(cell2mat(c_sheet1DataPullIn(2,15)))
    T.EII(i) = cell2mat(c_sheet1DataPullIn(2,15));
else
    T.EII(i) = str2num(cell2mat(c_sheet1DataPullIn(2,15)));
end

if isnumeric(cell2mat(c_sheet1DataPullIn(2,16)))
    T.EIN(i) = cell2mat(c_sheet1DataPullIn(2,16));
else
    T.EIN(i) = str2num(cell2mat(c_sheet1DataPullIn(2,16)));
end

if isnumeric(cell2mat(c_sheet1DataPullIn(2,17)))
    T.EIM(i) = cell2mat(c_sheet1DataPullIn(2,17));
else
    T.EIM(i) = str2num(cell2mat(c_sheet1DataPullIn(2,17)));
end

if isnumeric(cell2mat(c_sheet1DataPullIn(2,18)))
    T.AvgEI_Is(i) = cell2mat(c_sheet1DataPullIn(2,18));
else
    T.AvgEI_Is(i) = str2num(cell2mat(c_sheet1DataPullIn(2,18)));
end

if isnumeric(cell2mat(c_sheet1DataPullIn(2,19)))
    T.StdEI_Is(i) = cell2mat(c_sheet1DataPullIn(2,19));
else
    T.StdEI_Is(i) = str2num(cell2mat(c_sheet1DataPullIn(2,19)));
end

if isnumeric(cell2mat(c_sheet1DataPullIn(2,20)))
    T.AvgEI_Ns(i) = cell2mat(c_sheet1DataPullIn(2,20));
else
    T.AvgEI_Ns(i) = str2num(cell2mat(c_sheet1DataPullIn(2,20)));
end

if isnumeric(cell2mat(c_sheet1DataPullIn(2,21)))
    T.StdEI_Ns(i) = cell2mat(c_sheet1DataPullIn(2,21));
else
    T.StdEI_Ns(i) = str2num(cell2mat(c_sheet1DataPullIn(2,21)));
end

if isnumeric(cell2mat(c_sheet1DataPullIn(2,22)))
    T.AvgEI_Ms(i) = cell2mat(c_sheet1DataPullIn(2,22));
else
    T.AvgEI_Ms(i) = str2num(cell2mat(c_sheet1DataPullIn(2,22)));
end

if isnumeric(cell2mat(c_sheet1DataPullIn(2,23)))
    T.StdEI_Ms(i) = cell2mat(c_sheet1DataPullIn(2,23));
else
    T.StdEI_Ms(i) = str2num(cell2mat(c_sheet1DataPullIn(2,23)));
end


T.xCut(i) = mat2cell(table2array(t_sheet1bDataPullIn(:,1)),height(t_sheet1bDataPullIn));
T.tCut(i) = mat2cell(table2array(t_sheet1bDataPullIn(:,2)),height(t_sheet1bDataPullIn));
T.HorzX(i) = mat2cell(table2array(t_sheet1cDataPullIn(:,1)),height(t_sheet1cDataPullIn));
T.StemHeightsX(i) = mat2cell(table2array(t_sheet1cDataPullIn(:,2)),height(t_sheet1cDataPullIn));

T.PeaksX(i) = mat2cell(table2array(t_sheet1d(:,1)),height(t_sheet1d));
T.PeaksForce(i) = mat2cell(table2array(t_sheet1d(:,2)),height(t_sheet1d));
T.AssumedHeight(i) = mat2cell(table2array(t_sheet1d(:,3)),height(t_sheet1d));
T.EI_Is(i) = mat2cell(table2array(t_sheet1d(:,4)),height(t_sheet1d));
T.EI_Ns(i) = mat2cell(table2array(t_sheet1d(:,5)),height(t_sheet1d));
T.EI_Ms(i) = mat2cell(table2array(t_sheet1d(:,6)),height(t_sheet1d));

T.Time(i) = mat2cell(table2array(t_sheet2DataPullIn(:,1)),height(t_sheet2DataPullIn));
T.Distance(i) = mat2cell(table2array(t_sheet2DataPullIn(:,2)),height(t_sheet2DataPullIn));
T.ForcePerRow(i) = mat2cell(table2array(t_sheet2DataPullIn(:,3)),height(t_sheet2DataPullIn));

end
close(handle_waitbar_overviewFiles)
%% Descriptions and units, table T
T.Properties.VariableUnits = {'','Run #','Run #','hours','','', '', '','.xlsx','rows of wheat','inches','inches','stems'...
    ,'inches','stems/inch','pounds','pounds','pounds*inches'...
    ,'pounds*inches^2','pounds*inches^2','pounds*inches^2'...
    ,'pounds*inches^2','pounds*inches^2','pounds*inches^2'...
    ,'pounds*inches^2','pounds*inches^2','pounds*inches^2'...
    ,'inches','seconds','inches','inches','seconds','inches','inches'...
    ,'pounds*inches^2','pounds*inches^2','pounds*inches^2'...
    ,'seconds','inches','pounds',''};
T.Properties.VariableDescriptions{'i'} = '';
T.Properties.VariableDescriptions{'j'} = '';
T.Properties.VariableDescriptions{'Run'} = '';
T.Properties.VariableDescriptions{'Hour'} = 'Hours after inital test';
T.Properties.VariableDescriptions{'Analysis'} = '';
T.Properties.VariableDescriptions{'Variety'} = 'Array of displacement values during INSTRON test.';
T.Properties.VariableDescriptions{'Plot'} = 'Array of force values during INSTRON test.';
T.Properties.VariableDescriptions{'TestDetail'} = 'Slopes were carefully chosen from assessment of 9 linear elastic region fits. Generally the Auto slope was used.';
T.Properties.VariableDescriptions{'FilenameRaw'} = 'Automatically generated overview value based on INSTRON method. This number requires an input for cross sectional area of the plant, which was not measured. Hypothetically, a coefficient can be discovered for adjustment, based on the span of the INSTRON at the time of testing.';
T.Properties.VariableDescriptions{'Rows'} = 'Max load.';
T.Properties.VariableDescriptions{'ForceBarHeight'} = 'EI=Stiffness*(TestSpan^3)/48, where Testspan = 80 mm.';
T.Properties.VariableDescriptions{'AvgHeight'} = 'Displacement at max load.';
T.Properties.VariableDescriptions{'AvgStemCount'} = 'Choices: CRUSHED, SNAPPED, or SPLINTERED.';

T.Properties.VariableDescriptions{'SampleDistance'} = 'Genetic variety. 4 plots per variety were tested when possible, in 2021.';
T.Properties.VariableDescriptions{'Spacing'} = 'Indicates reference location of experimental plot within the Baldus Rd field, 2021.';
T.Properties.VariableDescriptions{'AvgForcePeak'} = 'Node diameter in direction of Instron travel.';
T.Properties.VariableDescriptions{'AvgForce'} = 'Node diameter in direction perpindicular to Instron travel.';
T.Properties.VariableDescriptions{'AreaUnderCurve'} = 'Internode diameter in direction of Instron travel.';
T.Properties.VariableDescriptions{'EII'} = 'Internode diameter in direction perpindicular to Instron travel.';
T.Properties.VariableDescriptions{'EIN'} = 'Elliptical area for Node, if not hollow';
T.Properties.VariableDescriptions{'EIM'} = 'Elliptical area for Internode, if not hollow';
T.Properties.VariableDescriptions{'AvgEI_Is'} = '';
T.Properties.VariableDescriptions{'AvgEI_Ns'} = '';
T.Properties.VariableDescriptions{'AvgEI_Ms'} = '';
T.Properties.VariableDescriptions{'StdEI_Is'} = '';
T.Properties.VariableDescriptions{'StdEI_Ns'} = '';
T.Properties.VariableDescriptions{'StdEI_Ms'} = '';
T.Properties.VariableDescriptions{'AvgEI_Ns'} = '';
T.Properties.VariableDescriptions{'xCut'} = '';
T.Properties.VariableDescriptions{'tCut'} = '';
T.Properties.VariableDescriptions{'HorzX'} = '';
T.Properties.VariableDescriptions{'StemHeightsX'} = '';
T.Properties.VariableDescriptions{'PeaksX'} = '';
T.Properties.VariableDescriptions{'PeaksForce'} = '';
T.Properties.VariableDescriptions{'AssumedHeight'} = '';

T.Properties.VariableDescriptions{'EI_Is'} = '';
T.Properties.VariableDescriptions{'EI_Ns'} = '';
T.Properties.VariableDescriptions{'EI_Ms'} = '';
T.Properties.VariableDescriptions{'Time'} = '';
T.Properties.VariableDescriptions{'Distance'} = '';
T.Properties.VariableDescriptions{'ForcePerRow'} = '';
T.Properties.VariableDescriptions{'Notes'} = '';



cd(directory_script)

%% plotting
idx4th = (T.j==1).*T.i;
idxNot4th = (T.j~=1).*T.i;
k=1;
while k<=length(idxNot4th)
    if idxNot4th(k)==0
        idxNot4th(k)=[];
        
    else
        k=k+1;
    end
end
T_copy=T;
T_copy(idxNot4th,:)=[];
%%

plot(T_copy.AvgForce,T_copy.AvgForce.*T_copy.AvgHeight,'o')

title('August 6th data, with Hit 1')

%ylabel('Area under the curve (lbs*in)')
ylabel('AvgForce*AveHeight (lbs*in)')
xlabel('EI, 50% interaction (lbs*in^2)')


