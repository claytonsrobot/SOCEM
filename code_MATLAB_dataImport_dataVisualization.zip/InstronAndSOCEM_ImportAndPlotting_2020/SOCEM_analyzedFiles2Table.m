% SOCEM_analyzedFiles2Table
% Author: Clayton Bennett
% Last edit: June 29, 2021

% Purpose: Identify files in analyzed directory (processed by Austin's
% SOCEM_Data_Analysis.py). Access data and pull it into a table.

% Future work: Import time vs travel vs force data as arrays

%% Identify files
%directory=('C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\SOCEM Script Testing\EI_analysis_2020_Barley\');
directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Patent\Visco Comparison 70 vs 90 percent\EI, Process Done\';
filelist = dir(directory);
filename = {filelist.name};
filename = filename(3:numel(filelist)); % non-modular code, but works for this specific instance to remove  {'.'}    {'..'} as the first two plotnames

%% Create table for analyzed SOCEM data
% make length of table (# of rows) equal to number of files in directory
n = numel(filename); %

varnames = {'Name', 'Plot','spacing','forceBarHeight','aveHeight','aveForcePeak','EI_I','EI_N','EI_M','AveEI_Is','StdEI_Is','AveEI_Ns','StdEI_Ns','AveEI_Ms','StdEI_Ms','Time', 'Distance','ForcePerRow'};
S = cell2table(cell(n,18), 'VariableNames', varnames);%, 'RowNames', rownames);
S.Name = strings([height(S),1]);
S.Plot = strings([height(S),1]);
S.spacing = nan(height(S),1);
S.forceBarHeight = nan(height(S),1);
S.aveHeight = nan(height(S),1);
S.aveForcePeak = nan(height(S),1);
S.EI_I = nan(height(S),1);
S.EI_N = nan(height(S),1);
S.EI_M = nan(height(S),1);
S.AveEI_Is = nan(height(S),1);
S.StdEI_Is = nan(height(S),1);
S.AveEI_Ns = nan(height(S),1);
S.StdEI_Ns = nan(height(S),1);
S.AveEI_Ms = nan(height(S),1);
S.StdEI_Ms = nan(height(S),1);

%% Cycle through files and add data to table
for j=1:n
    % pull data out of single file
    Si=readtable(strcat(directory,filename{j}),'Range','A2:O2','VariableNamesRange','A1:O1','PreserveVariableNames',true);
    
    %route data into "So" table for compilation
    S.Name(j)=Si.Name;
    S.Plot(j)=Si.Plot;
    S.spacing(j)=str2num(cell2mat(table2array(Si(1,3)))); % So.spacing(j)=Si.("Spacing (in.)");
    S.forceBarHeight(j)=table2array(Si(1,4)); %Si.("Force bar (in)")
    S.aveHeight(j) = table2array(Si(1,5)); %Si.("Ave. height (in.)")
    S.aveForcePeak(j) = str2num(cell2mat(table2array(Si(1,6))));% Si.("Ave. force peak (lbs.)");
    S.EI_I(j) = str2num(cell2mat(table2array(Si(1,7))));%Si.("EI-I (lbs*in^2)");
    S.EI_N(j) = str2num(cell2mat(table2array(Si(1,8))));%Si.("EI-N (lbs*in^2)");
    S.EI_M(j) = str2num(cell2mat(table2array(Si(1,9))));%Si.("EI-M (lbs*in^2)");
    S.AveEI_Is(j) = str2num(cell2mat(table2array(Si(1,10))));%Si.("Ave. EI-Is (lbs*in^2)");
    S.StdEI_Is(j) = str2num(cell2mat(table2array(Si(1,11))));%Si.("Std. EI-Is (lbs*in^2)");
    S.AveEI_Ns(j) = str2num(cell2mat(table2array(Si(1,12))));%Si.("Ave. EI-Ns (lbs*in^2)");
    S.StdEI_Ns(j) = str2num(cell2mat(table2array(Si(1,13))));%Si.("Std. EI-Ns (lbs*in^2)");
    S.AveEI_Ms(j) = str2num(cell2mat(table2array(Si(1,14))));%Si.("Ave. EI-Ms (lbs*in^2)");
    S.StdEI_Ms(j) = str2num(cell2mat(table2array(Si(1,15))));%Si.("Std. EI-Ms (lbs*in^2)");
    
    Si_details=readtable(strcat(directory,filename{j}),'Sheet','Details','Range','B2:D4000','VariableNamesRange','B1:D1','PreserveVariableNames',true); %4000 is more data point than all files; most cap at 2200. Some are as low as 900.
    Si_details=Si_details(~any(ismissing(Si_details),2),:); %remove empty (NAN) rows, because all test have less than 4000 data points
    Time=Si_details.("Time (s)");
    Distance=Si_details.("Distance (in.)");
    ForcePerRow=Si_details.("Force/row (lbs.)");
    S.Time(j)=mat2cell(Time, length(Time));
    S.Distance(j)=mat2cell(Distance, length(Time));
    S.ForcePerRow(j)=mat2cell(ForcePerRow, length(Time));
end
%% Add columns of calculated values
%Area under curve 1 and curve 2 FIX THIS JUNT
S.areaUnderCurve = nan(height(S),1);
for i=1:height(S)
    S.areaUnderCurve(i) = trapz(cell2mat(S.ForcePerRow(i)));
end

%SoB_2020.areaUnderCurve_diff=trapz(cell2mat(SoB_2020.ForcePerRow))-trapz(cell2mat(SoB_2020.ForcePerRow));
% optimize deltaX change for second curve based on minimal area areaUnderCurve_diff
%% Units and descriptions
S.Properties.VariableUnits = {'', '','in', 'in', 'in', 'lbs', 'lbs*in^2', 'lbs*in^2', 'lbs*in^2', 'lbs*in^2', 'lbs*in^2', 'lbs*in^2', 'lbs*in^2', 'lbs*in^2', 'lbs*in^2', 'sec', 'in', 'lbs','?'};

%% Create two new tables, one to save the imperial values and one to prepare for calculations to metric values
S_imperial = S;
S_metric = S;
%% convert to metric units
for j = 1:n
    S_metric.spacing(j) = S.spacing(j)*25.4; %% in to mm
    S_metric.forceBarHeight(j) = S.forceBarHeight(j)*25.4; %% in to mm
    S_metric.aveHeight(j) = S.aveHeight(j)*25.4; %% in to mm
    S_metric.aveForcePeak(j) = S.aveForcePeak(j)*4.4482216153; %% lbs to N
    S_metric.EI_I(j) = S.EI_I(j)*4.4482216153*(25.4^2);%% lbs*in^2 to N*mm^2
    S_metric.EI_N(j) = S.EI_N(j)*4.4482216153*(25.4^2);%% lbs*in^2 to N*mm^2
    S_metric.EI_M(j) = S.EI_M(j)*4.4482216153*(25.4^2);%% lbs*in^2 to N*mm^2
    S_metric.AveEI_Is(j) = S.AveEI_Is(j)*4.4482216153*(25.4^2);%% lbs*in^2 to N*mm^2
    S_metric.StdEI_Is(j) = S.StdEI_Is(j)*4.4482216153*(25.4^2);%% lbs*in^2 to N*mm^2
    S_metric.AveEI_Ns(j) = S.AveEI_Ns(j)*4.4482216153*(25.4^2);%% lbs*in^2 to N*mm^2
    S_metric.StdEI_Ns(j) = S.StdEI_Ns(j)*4.4482216153*(25.4^2);%% lbs*in^2 to N*mm^2
    S_metric.AveEI_Ms(j) = S.AveEI_Ms(j)*4.4482216153*(25.4^2);%% lbs*in^2 to N*mm^2
    S_metric.StdEI_Ms(j) = S.StdEI_Ms(j)*4.4482216153*(25.4^2);%% lbs*in^2 to N*mm^2
    S_metric.Distance(j) = mat2cell(cell2mat(S.Distance(j))*25.4,length(cell2mat(S.Distance(j)))); %% in to mm
    S_metric.ForcePerRow(j) = mat2cell(cell2mat(S.ForcePerRow(j))*4.4482216153,length(cell2mat(S.ForcePerRow(j)))); %% lbs to N
    S_metric.areaUnderCurve(j) = S.areaUnderCurve(j)*4.4482216153*(25.4);%% lbs*in^2 to N*mm
end
%% label metric units for So_metric table
S_metric.Properties.VariableUnits = {'', '','mm', 'mm', 'mm', 'N', 'N*mm^2', 'N*mm^2', 'N*mm^2', 'N*mm^2', 'N*mm^2', 'N*mm^2', 'N*mm^2', 'N*mm^2', 'N*mm^2', 'sec', 'mm', 'N','N*mm'};

%% Save Name
S=S_metric;
