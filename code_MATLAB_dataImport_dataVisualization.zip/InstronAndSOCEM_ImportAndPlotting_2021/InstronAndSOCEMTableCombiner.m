%% dualTable_allColumns.m
directory_code = 'D:\Instron Wheat Testing 2021\MatlabCode\';
cd(directory_code)
importKeyVariables % runs script in directory_code that imports saved 2021 Instron and SOCEM tables.

Ts; %Socem data from the base experiment
Ti; %Socem data from the base experiment

%% Change SI units to American Units



%%

%Tboth=Ti; %prepare to add Ts10 contents to new columns, in additon to Ti columns. Repear values for each instron stem.
% add all Ts10 columns except for i, Run, Variety, Plot.
sizeTs10 = size(Ts10);

Ts10_plotlist = Ts10.Plot;

includeTs10=Ts10;
excludeTs10 = {"i", "j","Run","Plot", "Variety","Notes"};
excludeTs10_columnIdxList = [];
includeTs10_columnIdxList = 1:1:sizeTs10(2);
for i=1:numel(excludeTs10)
    %excludeTs10_columnIdxList(i) = find(Ts10.Properties.VariableNames==excludeTs10{i});
    %includeTs10(:,excludeTs10_columnIdxList(i))=[];
    includeTs10.(excludeTs10{i})=[];
end


Ts10_ready=includeTs10;
sizeTs10_ready = size(Ts10_ready);
%%
Tboth=Ti;
sizeTi = size(Ti);
columnIdx=sizeTi(2)+1;
endIdx = columnIdx+sizeTs10_ready(2)-1;
classes={};
for i=1:sizeTs10_ready(2)
   classes{i}= class(Ts10_ready.(i));
end
%doubleClasses = ["double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double","double"];
%nanClasses=["nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","na","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan","nan"];
emptyT=table('Size',[1,sizeTs10_ready(2)],'VariableTypes',classes,'VariableNames',Ts10_ready.Properties.VariableNames);
emptyT.Properties.VariableUnits=Ts10_ready.Properties.VariableUnits;
Tboth(:,[columnIdx:endIdx])=table('Size',[height(Ti),sizeTs10_ready(2)],'VariableTypes',classes,'VariableNames',Ts10_ready.Properties.VariableNames);
Tboth.Properties.VariableUnits([columnIdx:endIdx])=Ts10_ready.Properties.VariableUnits;
missingplots = {};


for i=1:height(Tboth)
    if height(Ts10_ready(Tboth.Plot(i)==Ts10_plotlist,:))==0
        Tboth(i,[columnIdx:endIdx])=emptyT;
        %sprintf('%s not included in data', Tboth.Plot(i))
        missingplots{end+1}=Tboth.Plot(i);
        
    else
        
    Tboth(i,[columnIdx:endIdx])=Ts10_ready(Tboth.Plot(i)==Ts10_plotlist,:); 
    end
end

missingplots=unique(string(missingplots));
sizeTbothBefore=size(Tboth);
% i=1;
% while i<= height(Tboth)
%     if sum(Tboth.Plot(i)==missingplots)>0
%         Tboth(:,i)=[];
%     else
%         i=i+1;
%     end
% end
for i=1:numel(missingplots)
    Tboth(Tboth.Plot==missingplots{i},:)=[];
    
end
sizeTbothAfter=size(Tboth);

varnamesSOCEM=Ts10_ready.Properties.VariableNames;
varnamesInstron=Ti.Properties.VariableNames;
varnamesBoth=[string(varnamesInstron),string(varnamesSOCEM)];
Tboth.Properties.VariableNames=varnamesBoth;
%%
width = numel(Tboth.Properties.VariableNames);
Tboth.Properties.VariableNames{find(Tboth.Properties.VariableNames=="Notes")} = 'InstronNotes';
notesColumnNumber = find(Tboth.Properties.VariableNames=="InstronNotes");
%%
if not(notesColumnNumber ==width)
    copyOfNotesColumn = Tboth.InstronNotes;
    Tboth.(notesColumnNumber)=[];
    Tboth.(width) = copyOfNotesColumn;
    Tboth.Properties.VariableNames{width} = 'InstronNotes';
end
    


%% Unit changes
useUnits = "SIunits"; % use "americanUnits" or "SIUNits"

if useUnits == "SIunits"
     columnsToChangeFromNmmsqr2Ncmsqr = [find(Tboth.Properties.VariableUnits=="N*mm^2")];
     %columnsToChangeFromNmmsqr2Ncmsqr = [11];
     for i = 1:numel(columnsToChangeFromNmmsqr2Ncmsqr)
         if Tboth.Properties.VariableUnits{columnsToChangeFromNmmsqr2Ncmsqr(i)} == "N*mm^2";
            for row=1:height(Tboth)
                Tboth(row,columnsToChangeFromNmmsqr2Ncmsqr(i))=array2table(table2array(Tboth(row,columnsToChangeFromNmmsqr2Ncmsqr(i)))./100);
            end
            Tboth.Properties.VariableUnits{columnsToChangeFromNmmsqr2Ncmsqr(i)} = 'N*cm^2';
         elseif Tboth.Properties.VariableUnits{columnsToChangeFromNmmsqr2Ncmsqr(i)} == "N*mm^2";
             % good
         else
             msg=(strcat("Unexpected unit in Tboth column # ", string(columnsToChangeFromNmmsqr2Ncmsqr(i))));
             disp(msg)
         end
     end
    
    columnsToChangeFromLbInSqrToNcmSqr = [find(Tboth.Properties.VariableUnits=="pounds*inches^2")];
    %columnsToChangeFromLbInSqr2Ncmsqr = [35:43];%
    for i=1:numel(columnsToChangeFromLbInSqrToNcmSqr)
        if Tboth.Properties.VariableUnits{columnsToChangeFromLbInSqrToNcmSqr(i)} == "pounds*inches^2" && not(class(Tboth.(columnsToChangeFromLbInSqrToNcmSqr(i)))=="cell");
            for row=1:height(Tboth)
               Tboth(row,columnsToChangeFromLbInSqrToNcmSqr(i))=array2table(table2array(Tboth(row,columnsToChangeFromLbInSqrToNcmSqr(i)))./Newtons2Pounds./mmsqr2insqr./100);
            end
            Tboth.Properties.VariableUnits{columnsToChangeFromLbInSqrToNcmSqr(i)} = 'N*cm^2';
        end
    end
    
    columnsToChangeFromLb2N = [find(Tboth.Properties.VariableUnits=="pounds")];% 
    for i=1:numel(columnsToChangeFromLb2N)
        if Tboth.Properties.VariableUnits{columnsToChangeFromLb2N(i)} == "pounds" && not(class(Tboth.(columnsToChangeFromLb2N(i)))=="cell");
            for row=1:height(Tboth)
               Tboth(row,columnsToChangeFromLb2N(i))=array2table(table2array(Tboth(row,columnsToChangeFromLb2N(i)))./Newtons2Pounds);
            end
            Tboth.Properties.VariableUnits{columnsToChangeFromLb2N(i)} = 'N';
        end
    end
    
    columnsToChangeFromLbInches2NM = [find(Tboth.Properties.VariableUnits=="pounds*inches")];% ,51,52,53];
    for i=1:numel(columnsToChangeFromLbInches2NM)
        if Tboth.Properties.VariableUnits{columnsToChangeFromLbInches2NM(i)} == "pounds*inches";
            for row=1:height(Tboth)
               Tboth(row,columnsToChangeFromLbInches2NM(i))=array2table(table2array(Tboth(row,columnsToChangeFromLbInches2NM(i)))./Newtons2Pounds.*(2.54)./100);
            end
            Tboth.Properties.VariableUnits{columnsToChangeFromLbInches2NM(i)} = 'N*m';
        end
    end
    
    columnsToChangeFromInches2Cm = [find(Tboth.Properties.VariableUnits=="inches")];% ,51,52,53];
    for i=1:numel(columnsToChangeFromInches2Cm)
        if Tboth.Properties.VariableUnits{columnsToChangeFromInches2Cm(i)} == "inches" && not(class(Tboth.(columnsToChangeFromInches2Cm(i)))=="cell");
            for row=1:height(Tboth)
               Tboth(row,columnsToChangeFromInches2Cm(i))=array2table(table2array(Tboth(row,columnsToChangeFromInches2Cm(i)))*(2.54));
            end
            Tboth.Properties.VariableUnits{columnsToChangeFromInches2Cm(i)} = 'cm';
        end
    end
    
%     columnsToChangeFromNperMm2NperCm = [find(Tboth.Properties.VariableUnits=="N/mm")];% ,51,52,53];
%     for i=1:numel(columnsToChangeFromNperMm2NperCm)
%         if Tboth.Properties.VariableUnits{columnsToChangeFromNperMm2NperCm(i)} == "N/mm";
%             for row=1:height(Tboth)
%                Tboth(row,columnsToChangeFromNperMm2NperCm(i))=array2table(table2array(Tboth(row,columnsToChangeFromNperMm2NperCm(i))).*10);
%             end
%             Tboth.Properties.VariableUnits{columnsToChangeFromNperMm2NperCm(i)} = 'N/cm';
%         end
%     end
    
elseif useUnits == "AmericanUnits"
    
    
end

%% prep for CSV, remove columns with cells
TbothCSV=Tboth;
[rows,cols]=size(Tboth);
c=1;
while c<=cols
    if string(class(TbothCSV.(c)))==string('cell')
        TbothCSV.(c)=[];
    else
        c=c+1;
        
    end
    [rows,cols]=size(TbothCSV);
end
%%
cd(directory_compiledData)
writecell(TbothCSV.Properties.VariableNames,'T_wheat2021_.csv','FileType','Text','Range','A1')
writecell(TbothCSV.Properties.VariableUnits,'T_wheat2021_.csv','FileType','Text','Range','A2')
writetable(TbothCSV,'T_wheat2021_.csv','FileType','Text','WriteVariableNames',0)
cd(directory_code)

%%
filenameCSV = strcat('T_wheat2021_',useUnits,'.xlsx');
cd(directory_compiledData)
writecell(TbothCSV.Properties.VariableNames,filenameCSV,'FileType','Spreadsheet','Range','A1')
writecell(TbothCSV.Properties.VariableUnits,filenameCSV,'FileType','Spreadsheet','Range','A2')
writetable(TbothCSV,filenameCSV,'FileType','Spreadsheet','WriteVariableNames',0,'Range','A3')
cd(directory_code)

%%
%Tboth=Tboth;
% T=Tboth;
% 
% 
% plot(T.EI,T.EIM,'o');
% xlabel('Instron EI (N*cm^2)')
% ylabel('SOCEM EI (N*cm^2)')
% title('EI Correlation, All Stems, Wheat 2021')







