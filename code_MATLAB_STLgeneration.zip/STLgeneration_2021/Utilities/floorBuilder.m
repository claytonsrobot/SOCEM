function [mat3D_out,X_out,Y_out] = floorBuilder(mat3D,X,Y,option1,option2)

for n_row = 2:(length(mat3D)-1)
    reprow = mat3D(n_row,:);
    dir_tools_homemade = 'E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\Code - Matlab, Python, etc\Code - Matlab - Data Compilation\Utilities\';
    cd(dir_tools_homemade);
    iL1=1;
    iR1=findiR(reprow,iL1);
    iL2=findiL(reprow,iR1);
    iR2=findiR(reprow,iL2);
    iL3=findiL(reprow,iR2);
    iR3=findiR(reprow,iL3);
    
    reprow(reprow==0)=NaN;
    reprow([iL1,iR1,iL2,iR2,iL3,iR3])=0;
    reprow_zeros = reprow;
    reprow_zeros([iL3:iR3])=0;
    reprow([iR1+1:iL2-1,iR2+1:iL3-1])=NaN; % new test CB
    mat3D(n_row,:) = reprow;
    mat3D(1,[iR1+1:iL2-1,iR2+1:iL3-1,iR3+1:end]) = NaN; % clean up extra zeros in the null space
    mat3D(end,[iR1+1:iL2-1,iR2+1:iL3-1,iR3+1:end]) = NaN; % clean up extra zeros in the null space
    
end

% retain endcaps while removing interrow floor
mat3D(logical([mat3D<.000001].*[mat3D>-1]))=0; % uncomment this to hide 0 ground values
mat3D(mat3D<0)=0; % uncomment this to hide 0 ground values

if string(option1) == 'squareup' || string(option2) == 'squareup'
    X(:,[iL1,iR1,iL2,iR2,iL3,iR3]) = X(:,[iL1+1,iR1-1,iL2+1,iR2-1,iL3+1,iR3-1]);
end


if string(option1) == 'addfloor' || string(option2) == 'addfloor'
mat3D_floor = mat3D;
[r,c]=size(mat3D_floor);
for col=1:c
    for row=1:r
        if not(isnan(mat3D_floor(row,col)))
            option1 = "floor";
            
            if option1 == "floor"
                mat3D_floor(row,col) = 0; % build the floor
            elseif option1 == "nofloor"
                mat3D_floor(row,col) = NaN; % kill the floor
            end
            %else
            %mat3D_cell_floor(row,col) = NaN;
        end
    end
end

% make combination matrix, for both surface and floor panels
mat_nan_combo = NaN.*ones(length(X),length(X));
X_combo = [[X,X];[mat_nan_combo,mat_nan_combo]];
Y_combo = [[Y,Y];[mat_nan_combo,mat_nan_combo]];
mat3D_combo = [[mat3D,mat3D_floor];[mat_nan_combo,mat_nan_combo]];

X_out = X_combo;
Y_out = Y_combo;
mat3D_out = mat3D_combo;

else
    X_out = X;
    Y_out = Y;
    mat3D_out = mat3D;
end

end
%% metadata
% author: Clayton Bennett
% created: 05/02/2022
% Description: for 3D plots, remove excess flor from interrow and add floor
% to bottom of 3D form

