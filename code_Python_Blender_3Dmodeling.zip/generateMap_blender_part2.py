# there are still some things that need to be done manually

import bpy
#import sys 
#import os
def parttwo(bpy, savepngname, exportfilename):

    obj = bpy.data.objects['joinedObjects']
    obj.select_set(True)
    # bake!
    #bpy.ops.object.bake(type='DIFFUSE') 

    # save image
    #bpy.ops.image.save_as(save_as_render=False, filepath="E:\\Backups\\GoogleDrive_AgMEQ_03312022\\SOCEM\\CAD Drawings - Clayton\\FieldMap\\bake_joined.png", relative_path=True, show_multiview=False, use_multiview=False)
    #bpy.ops.image.save_as(save_as_render=False, filepath=savepngname, relative_path=True, show_multiview=False, use_multiview=False)
    #bpy.ops.image.save_all_modified

    # change back to EEVEE
    bpy.context.scene.render.engine = 'BLENDER_EEVEE'
    # clarify material reference jargon
    mat = bpy.data.materials.get('colorGradient')
    links = mat.node_tree.links
    nodes = mat.node_tree.nodes
    shader_image = nodes["Principled BSDF"]
    materialoutput = nodes["Material Output"]
    # change link to show baked texture, instead of procedural texture
    links.new(shader_image.outputs[0], materialoutput.inputs[0])
    # pack image
    bpy.ops.file.pack_all()

    # export
    # exportfilename # generated at top of script based on user inputs
    bpy.ops.export_scene.fbx(filepath=exportfilename, check_existing=True, filter_glob="*.fbx", use_selection=False, use_active_collection=False, global_scale=1, apply_unit_scale=True, apply_scale_options='FBX_SCALE_NONE', use_space_transform=True, bake_space_transform=False, object_types={'EMPTY', 'CAMERA', 'LIGHT', 'ARMATURE', 'MESH', 'OTHER'}, use_mesh_modifiers=True, use_mesh_modifiers_render=True, mesh_smooth_type='OFF', use_subsurf=False, use_mesh_edges=False, use_tspace=False, use_custom_props=False, add_leaf_bones=True, primary_bone_axis='Y', secondary_bone_axis='X', use_armature_deform_only=False, armature_nodetype='NULL', bake_anim=True, bake_anim_use_all_bones=True, bake_anim_use_nla_strips=True, bake_anim_use_all_actions=True, bake_anim_force_startend_keying=True, bake_anim_step=1, bake_anim_simplify_factor=1, path_mode='COPY', embed_textures=True, batch_mode='OFF', use_batch_own_dir=True, use_metadata=True, axis_forward='Y', axis_up='Z')

