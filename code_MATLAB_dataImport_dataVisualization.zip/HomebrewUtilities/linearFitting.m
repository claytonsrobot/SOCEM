% Author: Clayton Bennett
% Title: powerFitting.m
% Date: 10 February 2022
% Last edited: 10 February 2022


function [bmc,m,b,c,Rsq,RMSE,SSE,lm,f0,string1] = linearFitting(x,y,displayplot,displayline,displayrawdata,command1,input1)
% Inputs:
%     1. X
%     2. Y
%     3. displayplot (1 or 0) % must be 1 for remaining options to be 1
%     4. displayline (1 or 0)
%     5. displayrawdata (1 or 0)
%Example: exponentialFitting(T.NodeMajorDiameter,T.NodeMajorDiameter)
%x = T.NodeMajorDiameter;
%y = T.Stiffness;


% x and y must be verical single column!!
size_x=size(x);
size_y=size(y);
if size_x(1)==1 && size_y(1)==1
    x=x';
    y=y';
end

g = fittype('b+m*x');
beta = [60; -0.1];
beta = [300; -1];
beta = [300; 10];
f0 = fit(x,y,g,'StartPoint',beta);
%f0 = fit(x,y,g,'StartPoint',[[ones(size(x)), -exp(-x)]\y]);

try
    myfun = 'y~b+m*x';
    beta0 = beta';
    lm = fitlm(x,y);
    Rsq=lm.Rsquared.Ordinary;
    RMSE=lm.RMSE;
    SSE=lm.SSE;
    
    [bmc]=[lm.Coefficients.Estimate]';
    m = bmc(2);
    %a = 0;
    b = bmc(1);
    c = 0;
    % [yy,I] = sortrows(yy);
    % xx = x(I);
    string1 = {strcat('Linear Fit, f(x) = m*x + b');...
        strcat('m = ',{' '},string(sprintf('%7.2f ',m)),', b = ',{' '},string(sprintf('%7.2f ',b)));...%,', 95% confidence');...
        strcat('R-squared = ',{' '},string(sprintf('%7.3f ',lm.Rsquared.Ordinary)),{', '},' RMSE = ',{' '},string(sprintf('%7.3f ',lm.RMSE)),{', '},' SSE = ',{' '},string(sprintf('%7.3f ',lm.SSE)))};
        
catch
    g = fittype('b+m*x');
    %g = fittype('b*x');
    %iniitialGuess = [[ones(size(x)), -exp(-x)]\y; 1];
    %beta0 = [200; -200; 0.01];
    f0 = fit(x,y,g,'StartPoint',beta);
    %f0 = fit(x,y,g,'StartPoint',[[ones(size(x)), -exp(-x)]\y]);
    m = f0.m;
    %a = 0;
    b = f0.b;
    c = 0;
    string1 = {strcat('Linear Fit, f(x) = m*x + b');...
        strcat({'m = '},string(sprintf('%7.2f ',m)),{', b = '},string(sprintf('%7.2f ',b)));... %,{', 95% confidence'});...
        %strcat('R-squared = ',{' '},string(nlm.Rsquared.Ordinary),{', '},' RMSE = ',{' '},string(nlm.RMSE),{', '},' SSE = ',{' '},string(nlm.SSE),{', '})};
        };
    bmc = [b,m,c];
    Rsq = NaN;
    RMSE = NaN;
    SSE = NaN;
    lm = NaN;
end

xx = linspace(min(x),max(x),100);
f = @(x) b+m.*x;
yy = f(xx);

if displayplot == 1
    %hf=figure;
    if displayrawdata == 1
        plot(x,y,'*',command1,input1)
        hold on
        
    end
    if displayline == 1
        plot(xx,yy,'-',command1,input1)
        
        
        %xloc = (max(xx)-min(xx))*0.02+min(xx); %upper left corner
        %yloc = (max(yy)-min(yy))*0.95+min(yy); %upper left corner
        %xloc = 0+ 0.02;
        %yloc = min(ylist)-.2*(max(ylist)-min(ylist));
        %axis([0, max(xlist)+1, min(ylist)-.2*(max(ylist)-min(ylist)), max(ylist)+.1*(max(ylist)-min(ylist))]);

        %stringline1 = {strcat('a + b*exp(c*x)');strcat('a, b, c = ',string(abc),', 95% confidence');strcat('R-squared = ',string(nlm.Rsquared.Ordinary),{', '},' RMSE = ',string(nlm.RMSE),{', '},' SSE = ',string(nlm.SSE),{', '})};
%         string1 = {strcat('Exponential Fit, f(x) = a + b*exp(c*x)');...
%             strcat('a = ',{' '},string(abc(1)),' b = ',{' '},string(abc(2)),' c = ',{' '},string(abc(3)),', 95% confidence');...
%             strcat('R-squared = ',{' '},string(nlm.Rsquared.Ordinary),{', '},' RMSE = ',{' '},string(nlm.RMSE),{', '},' SSE = ',{' '},string(nlm.SSE),{', '})};
%         
        
        %ha=annotation(hf,'textbox',[0.121,0.11,1,1],'String',string1,'EdgeColor', 'none','FitBoxToText','on',  'verticalalignment', 'bottom', 'color','k');
    
    end
    
end
%f0;
%nlm; %compare results
%hold off
end