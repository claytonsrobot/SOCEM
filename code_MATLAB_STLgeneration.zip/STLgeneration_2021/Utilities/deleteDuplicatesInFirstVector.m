function [vectornewA,vectornewB]=deleteDuplicatesInFirstVector(vectorA,vectorB);
        [U, I] = unique(vectorA, 'first');
        x = 1:length(vectorA);
        x(I) = [];
        vectorA(x)=[];
        vectorB(x)=[];
        vectornewA=vectorA;
        
        vectornewB=vectorB;

%         [U, I] = unique(vectorB, 'first');
%         x = 1:length(vectorB);
%         x(I) = [];
%         vectorB(x)=[];
%         vectornewA(x)=[];
%         vectornewB=vectorB;
%         if not(numel(vector)==numel(unique(vector)))
%             display([numel(vector),numel(unique(vector))])
%             [vectornew]=deleteDuplicates(vectornew);
%         end
end
