'''
correctHeights.py
Author: Clayton Bennett
Last edited: 03/17/2022, by Clayton Bennett

Description:
    - Loops through folder containing clean SOCEM Excel data
    - Open each file, add 0.466 to the force bar height, save and close the file
'''


# Fb Bottom Height (in.)


# needed libraries
import math
import pandas as pd
from pandas import ExcelFile
from pandas import ExcelWriter
import numpy as np
import os
import xlsxwriter

topFolder = r'D:\Instron Wheat Testing 2021\SAVED_DATA_2021'
topFolder = r'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\SAVED_DATA_2020_Barley'
analysisDirectory =  '\\firstHits\\' # EDIT HERE
folderToProcess = topFolder + analysisDirectory + 'cleanRaw' # moved out
targetFolder = topFolder + analysisDirectory + 'cleanRaw_washedInTheBlood'



def Excel(*args):
#def Excel(filename, name, plotname, time, dis, rows, fpr, fb_bottom, stems, sampDis, spacing, x, heights, xPeaks, peaks, avgPeak, EI, EIs):

    # Create Lists to provide labels
    timeL = ['Time (s)']
    disL = ['Distance (in.)']
    forceL = ['Force (lbs.)']
    rowsL = ['Rows']
    fb_bottomL = ['Fb Bottom height (in.)']
    aveHeightL = ['Height (in)']
    stemsL = ['Avg Stem Count']
    sampDisL = ['Sample distance (in.)']

    timeL.extend(list(time))
    disL.extend(list(dis))
    forceL.extend(list(force))
    rowsL.append(rows)
    fb_bottomL.append(fb_bottom)
    aveHeightL.append(height)
    stemsL.append(stems)
    sampDisL.append(sampDis)

    saveAt = targetFolder+ '\\'+ filename # address + filename
    workbook = xlsxwriter.Workbook(saveAt)
    worksheet = workbook.add_worksheet('Sheet1')

    worksheet.set_column('A:H', 12)

    worksheet.write_column('A1', timeL)
    worksheet.write_column('B1', disL)
    worksheet.write_column('C1', forceL)
    worksheet.write_column('D1', aveHeightL)
    worksheet.write_column('E1', fb_bottomL)
    worksheet.write_column('F1', rowsL)
    worksheet.write_column('G1', stemsL)
    worksheet.write_column('H1', sampDisL)
    
    workbook.close()

# MAIN FUNCTION    
for filename in os.listdir(folderToProcess): # loop through files in folder

    file = str(folderToProcess+'/'+filename)
    print('\n' + 'NEXT!' + '\n' + file)    
    
    df = pd.read_excel(file) # convert Excel into pandas df

    time = np.array(df['Time (s)'])
    dis = np.array(df['Distance (in.)'])
    force = np.array(df['Force (lbs.)'])
    try:
        height = df['Height(in.)'].iloc[0]
    except:
        height = df['Height (in.)'].iloc[0]
    fb_bottom = df['Fb Bottom Height (in.)'].iloc[0]
    fb_bottom = fb_bottom++0.466 # CB EDIT THIS DO NOT LEAVE THIS HERE FUCKKKKK 
    rows = df['Rows'].iloc[0]
    stems = df['Ave Stem Count'].iloc[0]
    try:
        sampDis = df['Sample distance (in.)'].iloc[0]
    except:
        sampDis = df['Sample Distance (in.)'].iloc[0]

    
    Excel(filename, time, dis, rows, force, fb_bottom, stems, sampDis)

    print('\n' + 'DOVE DELIEVERED!') # Dove = data, duh.

