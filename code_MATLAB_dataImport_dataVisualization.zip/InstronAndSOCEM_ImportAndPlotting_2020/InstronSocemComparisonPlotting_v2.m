% InstronSocemComparisonPlotting
%% header
% Author: Clayton Bennett
% Last update: 3/25/2021
% Purpose: plots, by section, various overview plots for Socem and Instron
%   data comparison
% User notes: 
%   - Tables S and I must already be loaded into the MATLAB workspace.
%   - Table S comes from "wheatSocem2020_matchedIndices.mat"
%   - Table I comes from "wheatInstron2020_matchedIndices.mat"
%
% Future work: Adsign different color values to each hybrid, for quick
%   visual comparison.
%% plotting Instron.AveEI
% compare Instron.AveEI to all six different SOCEM EI values

cd(directory_code)
subplot(1,3,1)
[abc,a,b,c,Rsq,RMSE,SSE,lm,f0,string1] = linearFitting(S.EI_I,I.AveEI,1,1,1)
ylabel('Instron.AveEI, (N*mm^2)')
xlabel('SOCEM.EI_I, (N*mm^2)')

%
subplot(1,3,2)
[abc,a,b,c,Rsq,RMSE,SSE,lm,f0,string2] = linearFitting(S.EI_M,I.AveEI,1,1,1)
ylabel('Instron.AveEI, (N*mm^2)')
xlabel('SOCEM.EI_M, (N*mm^2)')
%
subplot(1,3,3)
[abc,a,b,c,Rsq,RMSE,SSE,lm,f0,string3] = linearFitting(S.EI_N,I.AveEI,1,1,1)
ylabel('Instron.AveEI, (N*mm^2)')
xlabel('SOCEM.EI_N, (N*mm^2)')
%


%% plotting Instron.MaxMoment
% compare Instron.MaxMoment to all six different SOCEM EI values
subplot(2,3,1)
plot(S.EI_I,I.AveMaxMoment,'o')
ylabel('Instron.AveMaxMoment, (N*mm)')
xlabel('SOCEM.EI__I, (N*mm^2)')

subplot(2,3,2)
plot(S.EI_M,I.AveMaxMoment,'o')
ylabel('Instron.AveMaxMoment, (N*mm)')
xlabel('SOCEM.EI__M, (N*mm^2)')

subplot(2,3,3)
plot(S.EI_N,I.AveMaxMoment,'o')
ylabel('Instron.AveMaxMoment, (N*mm)')
xlabel('SOCEM.EI__N, (N*mm^2)')

subplot(2,3,4)
plot(S.AveEI_Is,I.AveMaxMoment,'o')
ylabel('Instron.AveMaxMoment, (N*mm)')
xlabel('SOCEM.AveEI__Is, (N*mm^2)')

subplot(2,3,5)
plot(S.AveEI_Ms,I.AveMaxMoment,'o')
ylabel('Instron.AveMaxMoment, (N*mm)')
xlabel('SOCEM.AveEI__Ms, (N*mm^2)')

subplot(2,3,6)
plot(S.AveEI_Ns,I.AveMaxMoment,'o')
ylabel('Instron.AveMaxMoment, (N*mm)')
xlabel('SOCEM.AveEI__Ns, (N*mm^2)')

%% Plotting for SOCEM avg Force vs Instron EI
clf % clears figure
plot(S.aveForcePeak,I.AveEI,'o')
ylabel('Instron.AveEI, (N*mm^2)')
xlabel('SOCEM.aveForcePeak, (N)')
%% Plotting for SOCEM avg Force vs Instron MaxMoment
clf % clears figure
plot(S.aveForcePeak,I.AveMaxMoment,'o')
ylabel('Instron.AveMaxMoment, (N*mm)')
xlabel('SOCEM.aveForcePeak, (N)')

%% Next steps
% assign colors to different varieties (so that the data point from each
% plot can be compared with the variety as a grouping)

%% Correlation R^2 values
rsq_I=corr(I.AveEI,S.EI_I)^2;
rsq_N=corr(I.AveEI,S.EI_N)^2;
rsq_M=corr(I.AveEI,S.EI_M)^2;
rsq_Is=corr(I.AveEI,S.AveEI_Is)^2;
rsq_Ns=corr(I.AveEI,S.AveEI_Ns)^2;
rsq_Ms=corr(I.AveEI,S.AveEI_Ms)^2;

%%

%% comparison table creation
varnames = {'Name','Plot','index','EI_Iratio','EI_Nratio','EI_Mratio','EI_Isratio','EI_Nsratio','EI_Msratio'};

coeffAn = cell2table(cell(57,9), 'VariableNames', varnames);%, 'RowNames', rownames);
coeffAn.Name=S.Name;
coeffAn.Plot=S.Plot;
coeffAn.EI_Iratio=S.EI_I/I.AveEI;
coeffAn.EI_Iratio=S.EI_I./I.AveEI;
coeffAn.EI_Nratio=S.EI_N./I.AveEI;
coeffAn.EI_Mratio=S.EI_M./I.AveEI;
coeffAn.EI_Isratio=S.AveEI_Is./I.AveEI;
coeffAn.EI_Isratio=S.AveEI_Is./I.AveEI;
coeffAn.EI_Nsratio=S.AveEI_Ns./I.AveEI;
coeffAn.EI_Msratio=S.AveEI_Ms./I.AveEI;
coeffAn.InstronAveEI=I.AveEI;

for k=1:height(coeffAn)
    coeffAn.index{k}=k;
end
%% Color assignment % still testing
% colorlist = {[0,0,1],
%     [0.301, 0.7450, 0.933],
%     [0, .5, 0], 
%     [0.466,.6740,.188],
%     [.929,.694,.125],
%     [.85,.325,.098],
%     [1,0,0],
%     [.25,.25,.25],
%     [.635,.078,0.183], 
%     [0.494,.184,.556]}; %15 different colors
% coeffA.color = [];
% i = 1:1:10;
% %% color plot test
% for k = 1:10
%     scatter(i,i,'*','MarkerEdgeColor',colorlist{k},'MarkerFaceColor',colorlist{k});
%     k
% end