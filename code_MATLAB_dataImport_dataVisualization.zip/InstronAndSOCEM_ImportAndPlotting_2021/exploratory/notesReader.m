% notesReader.m
% clayton bennett
% 3/18/22

fileInstron2021 = 'D:\Instron Wheat Testing 2021\CompiledData\T_InstronWheat2021_stemByStem.mat';
load(fileInstron2021);
T21Instron=T;

fileInstron2020 = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\T_wheat2020_Instron.mat';
load(fileInstron2020);
T20Instron=T;

fileBarley2020_5 = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\T_barley5_run1s.mat';
fileBarley2020_15 = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\T_barley15_run1s.mat';
fileBarley2020_99 = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\T_barley_99percentDecrease_11282021.mat';
load(fileBarley2020_5);
T5=T;
load(fileBarley2020_15);
T15=T;
load(fileBarley2020_99);
T99=T;
T99.('i')=[];
T20Instron_barley=[T5;T15;T99];
T=T20Instron_barley;

n20b=T(not(ismissing(T.Notes)),find(string(T.Properties.VariableNames)=="Notes"));
n20=table2array(T20Instron(not(ismissing(T20Instron.Notes)),find(string(T20Instron.Properties.VariableNames)=="Notes")));
n21=table2array(T21Instron(not(ismissing(T21Instron.Notes)),find(string(T21Instron.Properties.VariableNames)=="Notes")));


