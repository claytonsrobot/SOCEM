% title: plotEIclicked.m
% author: Clayton Bennett
% Created: 04/30/2022
% last edited: 05/07/2022

% Description:
% plot EI-Ms values
% Plot EI, from all assessed clicked points.

% Show average line.

% first and last point, set to average
% Interpolate linear between points.

format compact
dir_compiledData = 'E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\Data - Instron and SOCEM\Compiled Data, Backups 2021 - mat, csv, xlsx, txt\';
dir_code = 'E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\Code - Matlab, Python, etc\Code - Matlab - Data Compilation\';
dir_saveImages = 'E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\Images, Figures, Graphs, Plots, Charts\Wheat 2021\SOCEM\August23_SideHits_PostRainSW\';
file_data  = 'T_S_SOCEM_Wheat2021_August23_S_versus_August13_T.mat';
dir_tools_downloaded = 'E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\Code - Matlab, Python, etc\Code - Matlab - Data Compilation\DownloadedUtilites\';
dir_utilities = 'E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\Code - Matlab, Python, etc\Code - Matlab - Data Compilation\Utilities\';

cd(dir_compiledData)
load(file_data) % import data
load('colormat.mat')
cd(dir_code)

%%

overwritestuff = 'n';
filename_description = '_EI_nearest_sideHitExperiment';

%%
try
    close gcf
end
i=1;
%hold off
%for i = 1:height(T)
    if not(T.("Analysis description")(i)=="TIME BASED")
        clickedEI = T.("EI-Ms (lbs*in^2)"){i};
        clickedDist = T.("x of force peak (in.)"){i};
        clickedHeight = T.("Assumed height (in.), hatPeaks"){i};
        clickedForce = T.("Force peaks at x (lbs.)"){i};
        aveEI = T.("EI-M (lbs*in^2)")(i);
        xCut = T.("xCut (in), Distance, analysis range"){i};
        
        EI_list = [aveEI;clickedEI; aveEI];
        x_list = [xCut(1);clickedDist;xCut(2)];
        %plot(x_list,EI_list,'-*')
        plot(clickedDist,clickedEI,'-*')
        hold on
        
        dim = 50;
        distance_xi=linspace(min(x_list),max(x_list),dim); % attempt to add same distance to ends
        EI_xi=linspace(min(EI_list),max(EI_list),dim); % attempt to add 0 force to ends
        EI_interp_linear=interp1(x_list,EI_list,distance_xi,'linear');
        EI_interp_nearest=interp1(x_list,EI_list,distance_xi,'nearest');
        EI_interp_pchip=interp1(x_list,EI_list,distance_xi,'pchip');
        %EI_interp = EI_interp_linear;
        EI_interp = EI_interp_nearest;
        
        plot(distance_xi,EI_interp_linear,'--')
        plot(distance_xi,EI_interp_nearest)
        plot(distance_xi,EI_interp_pchip)
        plot([xCut],[aveEI;aveEI],':k')
        title(strcat({'EI, from Clicked Points';'Various Interpolations for Presenting the Data in 3D'}))
        xlabel('Distance (in)')
        ylabel('EI (lbs*in^2)')
        %legend('Raw data','linear interpolation','nearest interpolation','pchip interpolation','Average EI','location','north')
        legend('Clicks','linear interpolation','nearest interpolation','pchip interpolation','Average EI','location','north')
        
        note1 = "Extreme ends of data show the average EI";
        %%
        dir_utilities = 'E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\Code - Matlab, Python, etc\Code - Matlab - Data Compilation\Utilities\';
        cd(dir_utilities)
        
        %standardSideHitTemplate function: import standard side hit template
        [sideDistance_squareForm_template,sideForce_squareForm_template] = standardSideHitTemplate();
        
        
        %%% REPLACE this with EI multiplied times side hits times sum of
        %%% side hits. keep each EI within ranges of side hits. what if
        %%% they fall out?
        % enhanceSideHitData function:
        % Increase size of side hit data vectors to match forward hit data interpolation
        [sideDistance_interp, sideForce_interp] = enhanceSideHitData(sideDistance_squareForm_template,sideForce_squareForm_template,dim);
        
        forwardDistance_interp = linspace(xCut(1),xCut(2),dim);
        % capBuilder function: elongate vectors and add caps at Y-axis extemities, for start and end walls of plots
        [sideDistance_interp,forwardDistance_interp,sideForce_interp,EI_interp] = capBuilder(sideDistance_interp,forwardDistance_interp,sideForce_interp,EI_interp);
        
        % create 3D matrix and X and Y matrices
        mat3D_template=EI_interp'.*sideForce_interp;
        [X_template,Y_template]=meshgrid([sideDistance_interp],[forwardDistance_interp]);
        
        % Build walls
        mat3D_template = wallBuilder(mat3D_template);
        
        % Definitely remove bad floor, maybe build good floor, maybe square up
        % sides, depending on option1 and option2:  'squareup','addfloor'
        [mat3D_template,X_template,Y_template] = floorBuilder(mat3D_template,X_template,Y_template,'dontsquareup','dontaddfloor');
        
        % plot 3D EI vs distance
        close(gcf)
        s = mesh(X_template,Y_template,mat3D_template);
        axis equal
        xlabel('Side Distance (in)')
        ylabel('Forward Distance (in)')
        zlabel('EI (lbs*in^2)')
        titletext = strcat(T.("Variety")(i),",",T.("Plot")(i));
        title(titletext)
        %title('EI, 3D')
        
        
        zlim([0 10])
        
        v = [1 -2 0.5];
        %v = [-1 0 0]; % side view
        [caz,cel] = view(v);
        %filename_description = '_EI_linear_noFloor';
        filename_fig = strcat(titletext,filename_description,'.fig');
        filename_png = strcat(titletext,filename_description,'.png');
        sizestr = string(dim);
        filename_stl = strcat(titletext,'_',sizestr,'x',sizestr,filename_description,'.stl');
        dir_CAD = 'E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\CAD Drawings - Clayton\FieldMap\';
        filename_stl_long = strcat(dir_CAD,filename_stl);
        
        complete3DSurface_EI.XX=X_template; complete3DSurface_EI.YY=Y_template; complete3DSurface_EI.ZZ=mat3D_template;
        
        if overwritestuff == 'y'
            T.("EI 3D Matrix Cells")(i)=complete3DSurface_EI; %CB % does include endcaps
            dir_images = 'E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\Images, Figures, Graphs, Plots, Charts\Wheat 2021\Images - SOCEM\3D Imaging\';
            cd(dir_images)
            saveas(s,filename_png)
            saveas(s,filename_fig)
            cd(dir_tools_downloaded)
            surf2stl(char(filename_stl_long),X_template, Y_template, mat3D_template);
            %vrml(gcf,filename_wrl)
        end
        dir_images = 'E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\Images, Figures, Graphs, Plots, Charts\Wheat 2021\Images - SOCEM\3D Imaging\';
        cd(dir_images)
        %saveas(s,filename_png)
        %saveas(s,filename_fig)
        cd(dir_tools_downloaded)
        % surf2stl(char(filename_stl_long),X_append_combo, Y_append_combo, mat3D_append_combo);
        %vrml(gcf,filename_wrl)
        xlim;
        ylim;
        cd(dir_code);
    end
    
%end