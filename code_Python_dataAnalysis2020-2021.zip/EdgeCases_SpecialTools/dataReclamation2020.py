'''
Title: dataReclamation2020.py
Author: Clayton Bennett
Created: 13 March 2022
Updated: 13 March 2022
Purpose: Popoulate missing data in plotHeights2020.xlsx with data from SOCEM_vs_lodging.xlsx.


'''
# needed libraries
import pandas as pd
from pandas import ExcelFile
from pandas import ExcelWriter
import numpy as np
import os
import xlsxwriter
import math

# Import data from both spreadsheet
socemData = r'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron and Socem Comparison 2020\SOCEM_vs_lodging.xlsx'
plotHeights = r'C:\Users\clayton\Google Drive\School\University of Idaho\AgMEQ\SOCEM\SAVE_DATA_2020\August20\Documentation\plotHeights2020 - Copy.xlsx'

df1 = pd.read_excel(socemData)
plot1 = df1['plot']
plot1=plot1.to_numpy().tolist()
stemCount1=df1['# stems']
stemCount1=stemCount1.to_numpy().tolist()
forcebar1 = df1['force bar (in.)']
forcebar1 = forcebar1.to_numpy().tolist()
heightAvg1 = df1['ave. height (in.)']
heightAvg1 = heightAvg1.to_numpy().tolist()


df2 = pd.read_excel(plotHeights)
varietyList = df2.iloc[0]
varietyList = varietyList.to_numpy().tolist()
varietyList = varietyList[1:-2]
plot2 = df2.iloc[1]
plot2 = plot2.to_numpy().tolist()
plot2 = plot2[1:-2]
heightsArray = df2.iloc[2:10]
heightsArray = df2.iloc[2:10,1:-2]
heightsArray = heightsArray.to_numpy()
heightAvg2 = df2.iloc[10]
heightAvg2 = heightAvg2.to_numpy()
heightAvg2 = heightAvg2[1:-2]
forcebar2 = df2.iloc[12]
forcebar2 = forcebar2.to_numpy()
forcebar2 = forcebar2[1:-2]
avgCount2 = df2.iloc[15]
avgCount2 = avgCount2.to_numpy()
avgCount2 = avgCount2[1:-2]

# Fix names: SWW --> SW, HWW --> HW
plot1 = [sub.replace('HWW', 'HW') for sub in plot1]
plot1 = [sub.replace('SWW', 'SW') for sub in plot1]


# If data is missing from in df2 column, apply data from df1 row to df2 column
print("Austin's source first")
for plot in plot2:
    if plot in plot1:
        if math.isnan(heightAvg2[plot2.index(plot)]):
            heightAvg2[plot2.index(plot)]=heightAvg1[plot1.index(plot)]

        else:
            print(plot, ": AvgHeight: ",  \
                  str(heightAvg1[plot1.index(plot)]), " vs ", heightAvg2[plot2.index(plot)], \
                  ", FbHeight: ",  str(forcebar1[plot1.index(plot)]+0.786), " vs ", forcebar2[plot2.index(plot)], \
                  ", Stem Count: ",  str(stemCount1[plot1.index(plot)]), " vs ", avgCount2[plot2.index(plot)])


# save new copy of plotHeights.xlsx
