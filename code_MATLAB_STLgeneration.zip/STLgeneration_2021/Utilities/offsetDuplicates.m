function [vectornew]=offsetDuplicates(vector,add);
        [U, I] = unique(vector, 'first');
        x = 1:length(vector);
        x(I) = [];
        add=rand(1,90).*0.001;
        add=add(1);
        vector(x)=vector(x)+add;
        vectornew=vector;
        if not(numel(vector)==numel(unique(vector)))
            display([numel(vector),numel(unique(vector))])
            [vectornew]=offsetDuplicates(vectornew,add);
        end
end
