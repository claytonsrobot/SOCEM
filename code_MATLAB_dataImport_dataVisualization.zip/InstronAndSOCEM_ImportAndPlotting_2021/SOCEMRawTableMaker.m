%function[S]=SOCEMRawTableMaker(directory)
% Purpose: Import every raw SOCEM file in a folder.
% For each file, reate scatter plots for  Force vs Distance and Force vs Time.
% Two plots will contain all of the data for the included files.
% The name of each file, possibly altered, will be used in the legend for
% each curve.

dir_code = 'D:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\Code - Matlab, Python, etc\';
dir_data = 'D:\Instron Wheat Testing 2021\SOCEM_DATA_2021\August23\encoderWorkedYes\';
directory = dir_data;
directory_saveGraphs = 'D:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\Images, Figures, Graphs, Plots, Charts\Wheat 2021\SOCEM\August23_SideHits_PostRainSW\';


%directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\SAVED_DATA_2021\Day D - Research Camp Echo\';
%directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\SAVED_DATA_2021\Research Camp Echo Day 2\';
%directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\SAVED_DATA_2021\Research Camp Echo Day 2\Homogenous Stretch Cross Examination\';

%directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\SAVED_DATA_2021\Research Camp Echo Day 2\Homogenous Stretch Cross Examination\Ruler8,75_Measured8,1\';
%S_east_cell6=S;

%directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\SAVED_DATA_2021\Research Camp Echo Day 2\Homogenous Stretch Cross Examination\Ruler9_Measured8,1\';
%S_northCell78_southCell5=S;

%directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\SAVED_DATA_2021\Research Camp Echo Day 2\Homogenous Stretch Cross Examination\Ruler9,875_MeasuredGreaterThan8,1\';
%S_southCell34_eastCell12910_higher=S;


%directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\SAVED_DATA_2021\August23';
%directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\SAVED_DATA_2021\August23\cellularDensity\';

%directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\SAVED_DATA_2021\Day A\';
%function[S]=SOCEMRawTableMaker(directory)
% %%
% title: InstronTableMaker.m
% author: Clayton Bennett
% created: August 18, 2021
% last edits: Augus 18, 2021
% %%%


clear S % The output table will be replaced when this script/function is run.

%% Save raw text for typical directories in use.

% %%
% If '\' is not input by the user as the final character in the directory
% assignment, add  it.
% 
if (directory(end)~='\')
    directory = strcat(directory,'\');
end
% %%%
%% Identify Instron files that have individual test arrays for Time, Displacement, and Force.
individualFileNameXLSX = strcat('RAW','*.xlsx'); % Ensure that only CSV files are looked for.
filelist_individual = dir(strcat(directory,individualFileNameXLSX)); % INPUT OPPORTUNITY.
files_individual = {filelist_individual.name};
% 
% "files_indvidual" is a list of CSV files that start with
% "individualFileName". This name will be tranlated to the expected
% overview filename for each instance.
% %%%

%% PREPARE THE TABLE
n = numel(files_individual)'; % How many indivdual files are there in the directory?

varnames = {'i','File','Time', 'Distance','Force','AverageForce'};
S = cell2table(cell(n,numel(varnames)), 'VariableNames', varnames); % Create table T.
S.i = nan(height(S),1); % Prepare column "i" to be numbers.
%S.Plot = strings([height(S),1]); % Prepare column "Plot" to be strings.
%S.Run = nan(height(S),1); % Prepare column "Run" to be numbers.
S.File = strings([height(S),1]); % Prepare column "File" to be strings.
S.AverageForce = nan(height(S),1); % Prepare column "Run" to be numbers.
section1of7 = "The table S has been prepped, with index, name, and array variables initialized." % Output message.
 %% Naming Interpretation, if the name refers to sample numbers, notes, etc.
% % %% Variables that are managed here:
% % %    Filename
% % %        Referred to as:
% % %            File
% % %            T.File(j)
% % %            file_individual(j)
% % % 
% % %    Plotname
% % %        Referred to as:
% % %            Plot
% % %            T.Plot(j)
% % % 
% % % 
% % %    Run number
% % %        Referred to as:
% % %            Run
% % %            T.Run(j)
% % %        Based on how many repeated tests were run on each stem.
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %
% %  All of this information comes directly from the filename for each
% % %%      indivdual test.
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
 for j=1:n
%     
%     % Identify each file name, one at a time.
    File = string(files_individual(j)); 
%     
%     % %% Store active variables, pulled from each file name, into row j of table T.
     S.i(j)=j;
     S.File(j)=File;
%     
 end
% 
 section2of7 = "File names have been interpretted." % Output message.

%% Display first five rows of the table T, so that you know what it looks like.

    headT_preDataImport = head(S,5) % Display.
        
section3of7 = "Sample view of table S has been displayed."
%% IMPORT ARRAYS FROM INDIVIDUAL FILES
% This is slow, because each file must be opened, recorded, and closed. That's okay.
% This import method should work for all individual Instron files.

heightS=height(S);
handle_waitbar_individualFiles=waitbar(0,strcat('Arrays are being imported from ',string(heightS),'individual SOCEM files. It is slow. But it is probably faster than you.')); % develop this more

for j = 1:height(S)
    %fprintf('%d,', j); % As a functinal loading bar, this will print j, the index
    %   number of the row.
    waitbar(j/height(S),handle_waitbar_individualFiles)
    %j
    %S.File(j)
    filename = strcat(directory,S.File(j));
    c=readtable(filename,'Filetype','spreadsheet', 'Range','A:C','PreserveVariableNames',1);
    %[Time, Distance,Force]=csvimport(strcat(directory, S.File{j}),'columns',[1,2,3],'noHeader', true);
    Time = c(1:end,1);
    Distance = c(1:end,2);
    Force = c(1:end,3);
    
    hopeArray = find(table2array(Time)<0.0005);
    if numel(hopeArray)>=2
        hopeIndex = hopeArray(2)-1;
        Time = Time(1:hopeIndex,1);
        Distance = Distance(1:hopeIndex,1);
        Force = Force(1:hopeIndex,1);
        % column is often messed up and (way) larger than 0
    end
    
    Time = table2array(Time);
    Distance = table2array(Distance);
    Force = table2array(Force);
    % %% Remove first value from each imported column.
    Time=Time(2:end);
    Distance=Distance(2:end);
    Force=Force(2:end);
    
    % %% Store entire arrays for each Instron test into each row j of table T.
    S.Time(j)=mat2cell(Time,numel(Time),1);
    S.Distance(j)=mat2cell(Distance,numel(Distance),1);
    S.Force(j)=mat2cell(Force,numel(Force),1);
    S.AverageForce(j)=mean(Force);
    
end

close(handle_waitbar_individualFiles)

%  Up to this point, most things apply to importing only individual
% %%      files.
section4of7 = "Arrays have been imported from individual files."
%% Prepare the table S, by adding more columns, to import numerical and text data from overview files.
% %% This section is possibly too custom to scale, because different


%S.LoadDeflection = nan(height(S),1); % Prepare column "LoadDeflection" to be numbers.
%S.Notes = strings([height(S),1]);

% section5of7 = "The table is prepared for overview values."
%% Go through each line in table and assign loadDeflection, Modulus, MaxLoad, DisplacementAtMaxLoad, Notes, BreakType

%% Descriptions and units
% %% Is scalable only if in metric and these are the expected variables. +*#*#*#*#*#*+
S.Properties.VariableUnits = {'','', 's', 'in', 'lb', 'lb'}; 
S.Properties.VariableDescriptions{'Time'} = 'Array of time values during SOCEM test.';
S.Properties.VariableDescriptions{'Distance'} = 'Array of distance values during SOCEM test.';
S.Properties.VariableDescriptions{'Force'} = 'Array of force values during SOCEM test.';
S.Properties.VariableDescriptions{'AverageForce'} = 'Average from array of force values';

section7of7 = "Descriptions and units have been added to the table. The function is complete."
%% Graph
%directory_saveGraphs =strcat(directory,'Graphs\');
%directory_saveGraphs = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\SAVED_DATA_2021\Research Camp Echo Day 2\Graphs\';

cd(directory_saveGraphs)
for j=1:height(S)

    %[handle_plot_tableData,filenametext] = plot_tableData(xdata,ydata,toggle_save,directory_saveGraphs,S);
    plot(cell2mat(S.Time(j)),cell2mat(S.Force(j)),'b-');
    hold on
    plot(cell2mat(S.Time(j)),ones(numel(cell2mat(S.Time(j))),1)*S.AverageForce(j),'r-')
    plot(cell2mat(S.Time(j)),ones(numel(cell2mat(S.Time(j))),1)*min(cell2mat(S.Force(j))),'c-')
    plot(cell2mat(S.Time(j)),ones(numel(cell2mat(S.Time(j))),1)*max(cell2mat(S.Force(j))),'m-')
    
    string_title=erase(strcat('Time_.vs_.Force',strrep(S.File(j),'_','_.')),'.xlsx');
    title(string_title)
    
    xlabel('Time (sec)')
    ylabel('Force (lbs)')
    fig = gcf;
    
    filenametext = strcat(erase(string_title,'.'),'.png');
    exportgraphics(fig, filenametext,'Resolution',300)
    hold off
end
%% Distance vs Force
for j=1:height(S)
    if max(cell2mat(S.Distance(j)))>0
    %[handle_plot_tableData,filenametext] = plot_tableData(xdata,ydata,toggle_save,directory_saveGraphs,S);
    plot(cell2mat(S.Distance(j)),cell2mat(S.Force(j)));
    hold on
    plot(cell2mat(S.Distance(j)),ones(numel(cell2mat(S.Distance(j))),1)*S.AverageForce(j),'r-')
    plot(cell2mat(S.Distance(j)),ones(numel(cell2mat(S.Distance(j))),1)*min(cell2mat(S.Force(j))),'c-')
    plot(cell2mat(S.Distance(j)),ones(numel(cell2mat(S.Distance(j))),1)*max(cell2mat(S.Force(j))),'m-')
    
    string_title=erase(strcat('Distance_.vs_.Force',strrep(S.File(j),'_','_.')),'.xlsx');
    title(string_title)
    
    xlabel('Distance (in)')
    ylabel('Force (lbs)')
    fig = gcf;
    
    filenametext = strcat(erase(string_title,'.'),'.png');
    exportgraphics(fig, filenametext,'Resolution',300)
    hold off
    end
end

%%  Common issues and solutions.
% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %%
% 1) Open T and look for NaN values in the Modulus, MaxLoad, and
%       DisplacementAtMaxLoad columns.
%
%       NaN values in these columns indicates that a text note was written
%       too lengthy in the Instron interface, and so the overview file
%       contains that text in unexpected places. This commonly results in
%       other columns being disturbed. 
%
%       If this is an issue, the relevant overview file needs opened and 
%       manually edited. If there is test that needs to be removed from a
%       cell, it should be able to be pasted at the end of the text within
%       the cell to its left, where the entire statement should be
%       contained.



%end

%% Change back to script directory
cd(dir_code)
% %% Comparison 1 - Visco Cycled Cell 6
% 
% for j=1:4
%     plot(cell2mat(S_east_cell6.Distance(j)),cell2mat(S_east_cell6.Force(j)))
%     hold on
% end
% title('Cross Examination, Cell 6, East, Cycled')
% xlabel('Distance (inches)')
% ylabel('Force (pounds)')
% fig = gcf;
% 
% string_title = 'Cell6CycledVisco';
% filenametext = strcat(erase(string_title,'.'),'.png');
% exportgraphics(fig, filenametext,'Resolution',300)
% hold off
% 
% %% Comparison 2 - North (Cell 7, 8) compared to South (Cell 5)
% S_northCell78_southCell5;
% for j=1:3
%     plot(cell2mat(S_northCell78_southCell5.Distance(j)),cell2mat(S_northCell78_southCell5.Force(j)))
% 
%     string_title=erase(strcat('Distance_.vs_.Force',strrep(S_northCell78_southCell5.File(j),'_','_.')),'.xlsx');
%     title(string_title)
%     
%     xlabel('Distance (inches)')
%     ylabel('Force (lbs)')
%     fig = gcf;
%     
%     filenametext = strcat(erase(string_title,'.'),'.png');
%     %exportgraphics(fig, filenametext,'Resolution',300)
%     hold off
%         pause(5)
% %plot3
% end
% %% Comparison 2 - 3D for Comparable Cross Examination Cells
% 
% % East and South: Cell 10 vs Cell 3 ~~~~~ i=1 vs i=4
% % East and South: Cell 1 vs Cell 3 ~~~~~ i=2 vs i=4
% % East and South: Cell 2 vs Cell 3 ~~~~~ i=3 vs i=4
% % East and South: Cell 9 vs Cell 3 ~~~~~ i=6 vs i=4
% 
% % East and South: Cell 10 vs Cell 4 ~~~~~ i=1 vs i=5
% % East and South: Cell 1 vs Cell 4 ~~~~~ i=2 vs i=5
% % East and South: Cell 2 vs Cell 4 ~~~~~ i=3 vs i=5
% % East and South: Cell 9 vs Cell 4 ~~~~~ i=6 vs i=5
% 
% % indexes:
% % Cell 10: i=1
% % Cell 1: i=2
% % Cell 2: i=3
% % Cell 3: i=4
% % Cell 4: i=5
% % Cell 9: i=6
% 
% % Distance arrays are X and Y. Z needs to be the two force arrays
% % multiplied together; 
% 
% S_current = S_southCell34_eastCell12910_higher;
% % from folder:
% % directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\SAVED_DATA_2021\Research Camp Echo Day 2\Homogenous Stretch Cross Examination\Ruler9,875_MeasuredGreaterThan8,1\';
% 
% % % 3D attempt!!
% % East and South: Cell 10 vs Cell 3 ~~~~~ i=1 vs i=4
% indexMatrix = [1 4;
%     2 4;
%     3 4;
%     6 4;
%     1 5;
%     2 5;
%     3 5;
%     6 5];
% for j=1:length(indexMatrix)
%                 
%     index1 = indexMatrix(j,1); %east
%     index2 = indexMatrix(j,2); %south
% 
%     %index1 = 1;%east
%     %index2 = 4;%south
%     
%     X1 = cell2mat(S_current.Distance(index1));
%     Y1 = cell2mat(S_current.Force(index1));
%     X2 = cell2mat(S_current.Distance(index2));
%     Y2 = cell2mat(S_current.Force(index2));
% 
% 
%             if length(Y1) < length(Y2)
%                 Yshorter = Y1;
%                 Ylonger =  Y2;
%                 Xshorter = X1;
%                 Xlonger =  X2;    
%             elseif length(Y1) > length(Y2)
%                 Yshorter = Y2;
%                 Ylonger =  Y1;
%                 Xshorter = X2;
%                 Xlonger =  X1;
%             end
%             Yshorter_length = length(Yshorter);
%             Ylonger_length = length(Ylonger);
%             lengthDifference = Ylonger_length-Yshorter_length;
%             Ylonger_clipped = Ylonger((lengthDifference/2):(end-lengthDifference/2-1));
%             Xlonger_clipped = Xlonger((lengthDifference/2):(end-lengthDifference/2-1));
%             %Z = Yshorter.*Ylonger_clipped; % results in a single-column vector =  times(Yshorter,Ylonger_clipped)
%             Z1 = mtimes(Ylonger_clipped, Yshorter'); % Correct!
%             %Z2 = mtimes(Yshorter,Ylonger_clipped'); %Not correct!
%             
%             % filtering
%             %threadsholdForce=20; %lbs^2
%             %matZ1=Z1>threadsholdForce;
%             %z1 = matZ1.*Z1;
%             
%             %make a list of all nonzero values, and use this to find
%             %standard deviation and average
%             %includedZ1=append(includedZ1);
% 
% 
%     
%     mesh(Xshorter,Xlonger_clipped,Z1); % 'Z must be a matrix, not a scalar or vector.'
%     %mesh(Xshorter,Xlonger_clipped,Z2); % 
%     
%     string1 = str2mat(S_current.File(index1));
%     string2 = str2mat(S_current.File(index2));
% 
%     string_cellindex1 = strfind(string1,'cell');
%     string_cellindex2 = strfind(string2,'cell');
%     string_hyphenindex1 = strfind(string1,'_');
%     string_hyphenindex2 = strfind(string2,'_');
%     
%     string_cellnum1 = string1(string_cellindex1+4:string_hyphenindex1(2)-1);
%     string_cellnum2 = string2(string_cellindex2+4:string_hyphenindex2(2)-1);
%     
%     
%     string_title=strcat('Mesh_.Cell ',string_cellnum1,'East_.vs_.Cell ',string_cellnum2,'South');
%     
%     hold on
%     title(string_title)
%     xlabel('Distance South (inches)')
%     ylabel('Distance East (inches)')
%     zlabel('Force, squared (lbs^2)')
%     fig = gcf;
%     filenametext = strcat(erase(string_title,'.'),'.png');
%     exportgraphics(fig, filenametext,'Resolution',300)
%     hold off
% end
% %% Filtered Mesh Plotting
% for j=1:length(indexMatrix)
%                 
%     index1 = indexMatrix(j,1); %east
%     index2 = indexMatrix(j,2); %south
% 
%     %index1 = 1;%east
%     %index2 = 4;%south
%     
%     X1 = cell2mat(S_current.Distance(index1));
%     Y1 = cell2mat(S_current.Force(index1));
%     X2 = cell2mat(S_current.Distance(index2));
%     Y2 = cell2mat(S_current.Force(index2));
% 
% 
%             if length(Y1) < length(Y2)
%                 Yshorter = Y1;
%                 Ylonger =  Y2;
%                 Xshorter = X1;
%                 Xlonger =  X2;    
%             elseif length(Y1) > length(Y2)
%                 Yshorter = Y2;
%                 Ylonger =  Y1;
%                 Xshorter = X2;
%                 Xlonger =  X1;
%             end
%             Yshorter_length = length(Yshorter);
%             Ylonger_length = length(Ylonger);
%             lengthDifference = Ylonger_length-Yshorter_length;
%             Ylonger_clipped = Ylonger((lengthDifference/2):(end-lengthDifference/2-1));
%             Xlonger_clipped = Xlonger((lengthDifference/2):(end-lengthDifference/2-1));
%             %Z = Yshorter.*Ylonger_clipped; % results in a single-column vector =  times(Yshorter,Ylonger_clipped)
%             
%             if length(Y1) < length(Y2)
%                 X1 = Xshorter;
%                 X2 = Xlonger_clipped;
%                 Y1 = Yshorter; % not necessary, already true
%                 Y2 = Ylonger_clipped;
%             elseif length(Y1) > length(Y2)
%                 X2 = Xshorter;
%                 X1 = Xlonger_clipped;
%                 Y2 = Yshorter; % not necessary, already true
%                 Y1 = Ylonger_clipped;
%             end
%             
%             %Z1 = mtimes(Ylonger_clipped, Yshorter'); % Correct!
%             Z1 = mtimes(Y1,Y2');
%             %Z2 = mtimes(Yshorter,Ylonger_clipped'); %Not correct!
%             
%             % filtering
%             thresholdForce=25; %lbs^2
%             matZ1=Z1>thresholdForce;
%             z1 = matZ1.*Z1;
%             
%             %make a list of all nonzero values, and use this to find
%             %standard deviation and average
%             z1nums = [];
%             for irow = 1:length(z1)
%                 for icolumn = 1:length(z1)
%                     if z1(irow,icolumn)<thresholdForce
%                         z1(irow,icolumn)=0;
%                     else
%                         z1nums(end+1)=z1(irow,icolumn);
%                     end
%                 end
%             end
% 
%             averageZ1 = mean(z1nums);
%             stdevZ1 = std(z1nums);
%             quantilesZ1 = quantile(z1nums,[.025 .25 .50 .75 .975]);
% 
%         
%             
% 
% 
% 
%     
%     %handle_mesh=mesh(Xshorter,Xlonger_clipped,z1); % 'Z must be a matrix, not a scalar or vector.'
%     %handle_mesh=mesh(X1,X2,z1); % 'Z must be a matrix, not a scalar or vector.'
%     handle_mesh=mesh(X2,X1,z1); % 'Z must be a matrix, not a scalar or vector.'
%     xMax=max(handle_mesh.Parent.XLim);
%     yMax=max(handle_mesh.Parent.YLim);
%     %mesh(Xshorter,Xlonger_clipped,Z2); % 
%     hold on 
%     %plot3(Xshorter,yMax.*ones(length(Xshorter),1),averageZ1.*ones(length(Xshorter),1))
%     plot3([0,xMax],[yMax,yMax],[averageZ1,averageZ1])
%     for j=1:length(quantilesZ1)
%         plot3([xMax, xMax],[0,yMax],quantilesZ1(j).*[1,1])
%     end
%     
%     string1 = str2mat(S_current.File(index1));
%     string2 = str2mat(S_current.File(index2));
% 
%     string_cellindex1 = strfind(string1,'cell');
%     string_cellindex2 = strfind(string2,'cell');
%     string_hyphenindex1 = strfind(string1,'_');
%     string_hyphenindex2 = strfind(string2,'_');
%     
%     string_cellnum1 = string1(string_cellindex1+4:string_hyphenindex1(2)-1);
%     string_cellnum2 = string2(string_cellindex2+4:string_hyphenindex2(2)-1);
%     
%     
%     string_title=strcat('Mesh_.Cell ',string_cellnum1,'East_.vs_.Cell ',string_cellnum2,'South, Filtered above',string(thresholdForce),'lb^2');
%     string_text = strcat('Average: ',string(averageZ1),'lbs^2, Stdev: ',string(stdevZ1)); 
%     
%     hold on
%     title(string_title)
%     xlabel('Distance South (inches)')
%     ylabel('Distance East (inches)')
%     zlabel('Force, squared (lbs^2)')
%     text(max(Xshorter),max(Xlonger_clipped), max(max(z1)),string_text);
%     fig = gcf;
%     filenametext = strcat(erase(string_title,'.'),'.png');
%     exportgraphics(fig, filenametext,'Resolution',300)
%     hold off
% end
% %%
% 
% %plot3
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 