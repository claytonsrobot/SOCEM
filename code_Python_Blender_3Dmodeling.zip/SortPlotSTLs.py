'''
Title: SortPlotSTLs.py
Author: Clayton Bennett
Date created: 6/14/2022

Description: Refernce STL files in a directory based on a text identifier. Pull in name list. Sort names beased on uniqueness, for type (CF, HW, SW) and for genetici variety.

Inputs: Directory, text identifier.
Modifiers: X spacing between plots of the same genetic variety. X spacing between plots of the same type bu different genetic variety. Y spacing between types.
Outputs: X and Y coorinates for each STL origin.

Steps:
1) Make list of each plot, correlated to lists of varieties and types. These will be in alphabetical order by variety, and then by plot number. Each plot (example: SW429) in a given genetic variety (example: Purl) will be of the same type (CF, HW, SW)
2) Identify unique types (CF, HW, SW). For each element in this list, add a unique y coordinate (list name: yType)
3) Identify and count unique varieties in each type. For type with max number of unique varieties, assign that number of xbasecoord entries to be in denomination of xSpacingVarieties (list name: xbasecoord)
4) For each type, look at each variety. For each variety, identify list of plots. For all indicies in a type, apply the yType value to the ycoord list. For the first plot in each variety, assign the xbasecoord value to its index xcoord.
5) At this point, the xcoord list only shows the xbasecoord values, with xSpacingVarities, and all other entries being 0. Look for zeros, and assign to that index the value of xSpacingPlots plus the value of the previous index xcoord.

'''
import sys
#import pandas as pd
import os
import math
#import mathutils
import numpy as np
from plotsnames2021varietynames2021 import plotsnames2021, varietynames2021


def unique(listIn):
    listUnique = []
    for x in listIn:
        if x not in listUnique:
            listUnique.append(x)
    return listUnique


def plotcoordinates(textIdentifier, directory, textIdentifier2):
    
##    textIdentifier = "_50x50_EI_nearest_sideHitExperiment.stl"
##    directory = r'E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\CAD Drawings - Clayton\FieldMap'

    xSpacingPlots = 50
    xSpacingVarieties = 300
    ySpacingTypes = 200

    filelistIdentified = []
    varietylist = []
    plotlist = []
    typelist = []

    xcoord = []
    ycoord = []

    print("\n")
    print("STL files identified:")
    for filename in os.listdir(directory):
        if (textIdentifier in filename) and (textIdentifier2 in filename):
            filelistIdentified.append(filename)
            
            print(filename)
            textParse = filename.replace(textIdentifier,"")
            #print(textParse)
            try:
                plot = textParse.split(",",2)[1]
                varietylist.append(textParse.split(",",2)[0])
            except:
                #varietylist.append("") # rather, go check the  spreadsheet
                plot = textParse.split("_",1)[0]
                plotIdx = plotsnames2021.index(plot) # where does the filename match the concat of 
                variety_ref = varietynames2021[plotIdx] #
                varietylist.append(variety_ref) # rather, go check the  spreadsheet
                
                
            plotlist.append(plot)
            typelist.append(plot[0:2])
            xcoord.append(0) # fill zeros to the same number of the relevant STL files
            ycoord.append(0) # fill zeros to the same number of the relevant STL files

    types = unique(typelist)
    print("\n")
    print("types = " )
    print(types)
    varieties = unique(varietylist)
    print("varieties = ")
    print(varieties)
    print("\n")

    numelTypes = len(types)
    numelVarieties = len(varieties)

    yType=[]
    idx=0
    for typ in types:
        yType.append(idx*ySpacingTypes)
        idx+=1

    # different types will be spread out in the Y coordinate direction
    trackstringY = "abcdefghijklmnopqrstuvwxyz" # this varibale is meant to track the varieties that are in each type
    [a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z] = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0] # [[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],['']]#
    if numelTypes > 26: # extremely unlikely.
        print('The script does not expect more than 26 types of wheat. Clayton does not expect more than 3 types of wheat: CF, HW SW. There is probably an error. If not, please add a sufficient number of tracks.')


    # varieties within a type will be spread out in the X coordinate direction
    trackstringX = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" # this variable reflects the type that correlates with the same lowercase letter
    [A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z] = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    if numelVarieties > 26: # extremely unlikely.
        print('The script does not expect more than 26 genetic varieties of wheat in one sitting. Clayton thinks 26 is a high yet reasonable number, though it is possible you have an error.')


    ##idx=0
    ##locals()[trackstring[idx]]+=1 # add a count to a tracker variable
    ##print(a)
    ##
    ##typelist
    ##varietylist
    ##plotlist
    ##xcoord
    ##ycoord

    ##for typ in typelist:
    ##    idx=types.index(typ)
    ##    ycoord.append(yType[idx])
    ##    locals()[trackstringY[idx]]+=1
        
    #identify starting place x coord for each variety
    #identify a count of plot for each variety (1-4)

    xbasecoord = [0] # initialize
    numelxbasecoord = 1 # initialize
    typesByVariety = [] # reference for type for each unique variety
    for variety in varieties:
        idx = varietylist.index(variety) # brokenb here
        typesByVariety.append(typelist[idx])
        #print("idx=",idx)
        #print("len typelist = ",len(typelist))
        #print("plotlist = ",plotlist)
        #print("typelist = ",typelist)

    #get list of varities in each type: type a (CF), type b (SW), type c (Hw)
    idx = 0
    for typ in types:
        indicies = [jdx for jdx, x in enumerate(typelist) if x==typ]
        allVarietiesInRow = [varietylist[kdx] for kdx in indicies]
        allPlotsInRow = [plotlist[kdx] for kdx in indicies]
        allVarietiesInRow_unique = unique(allVarietiesInRow)
        locals()[trackstringY[idx]] = allVarietiesInRow_unique
        locals()[trackstringY[idx].upper()] = typ # this is a neat trick. 
        numelVarietiesInRow = len(allVarietiesInRow_unique)
        if numelVarietiesInRow > numelxbasecoord:
            numelxbasecoord = numelVarietiesInRow 
        #idx*xSpacingVarieties

        for ldx in indicies: # assign ycoordinates
            ycoord[ldx] = yType[types.index(typ)]
            
        idx +=1

    idx=1
    while numelxbasecoord > len(xbasecoord):
        #print(idx,numelxbasecoord, xbasecoord)
        xbasecoord.append(idx*xSpacingVarieties)
        idx+=1

    for typ in types: # for each unique types 
        indicies_type = [jdx for jdx, ty in enumerate(typelist) if ty==typ]
        allVarietiesInRow = [varietylist[kdx] for kdx in indicies_type]
        allPlotsInRow = [plotlist[kdx] for kdx in indicies_type]
        allVarietiesInRow_unique = unique(allVarietiesInRow)
        numelVarietiesInRow = len(allVarietiesInRow_unique)
        vdx=0
        for variety in allVarietiesInRow_unique:
            indicies_variety = [ldx for ldx, vari in enumerate(varietylist) if vari==variety]
            allPlotsInVariety = [plotlist[mdx] for mdx in indicies_variety]
            #print(allPlotsInVariety)
            ndx=0
            for mdx in indicies_variety:
                if ndx==0:
                    xcoord[mdx] = xbasecoord[vdx]
                    baseref = mdx
                    ndx+=1
                else:
                    xcoord[mdx] = xcoord[baseref]+ndx*xSpacingPlots
                    ndx+=1
            vdx+=1

    

    return xcoord, ycoord, plotlist, varietylist, filelistIdentified
                








