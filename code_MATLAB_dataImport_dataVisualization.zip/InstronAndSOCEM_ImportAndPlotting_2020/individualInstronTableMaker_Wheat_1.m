%% Do spot checks on the data
directory = ('C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\Wheat\August 2020\');

%% IDENTIFY FILENAME PATTERNS
% Look for overview files
filelist_overviews = dir(strcat(directory,'0*.csv'));

plotname = {filelist_overviews.name};
plotname_overviews=plotname;
plotname = erase(plotname,'.csv');
plotname = strrep(plotname,'0CF','clearfield'); 
plotname = strrep(plotname,'0HW','hardwinter');
plotname = strrep(plotname,'0SW','softwinter');
plotname = strrep(plotname,'0SBF','springbarleyfeed');
plotname_repeatedRemoved=plotname;
%%END IDENTIFY FILENAME PATTERNS
%------------------------------------------------------------------------------------------------------------------------------------------------
%% PLOTNAME CHECKER, DUPLICATE REMOVER
% Example: if there exists 0CF115.csv and 0CF115b.csv in the plotname list,
%  remove the second instance, such that searching CF115 will identify both and therefore CF115b will not be identified twice)
cellfind = @(string)(@(cell_contents)(contains(string,cell_contents)));
k=1;
p=1;
repeatedIdx_list=zeros(1,3);
while k <= length(plotname_repeatedRemoved)
    logical_cells = cellfun(cellfind(plotname_repeatedRemoved{k}),plotname_repeatedRemoved);
    summ=sum(logical_cells);
    if summ > 1
        repeatedIdx = find(logical_cells,1,'last');
        plotname_repeatedRemoved(repeatedIdx)=[];
        repeatedIdx_list(p)=repeatedIdx+(p-1);
        k=k+1;
        p=p+1;
    end
    k=k+1;
end
repeatedIdx_list=[2, 5, 7, 51]; %% MANUAL OVERIDE, THE PROGRAM MISSED 5
plotname_repeatedRemoved(5)=[]; %% MANUAL OVERIDE, THE PROGRAM MISSED 5
pre_repeatedIdx_list=repeatedIdx_list-1;
%% INITIALIZE TABLE T
n = numel(plotname_repeatedRemoved); % insuffciient, this junt needs to be as long as the number of individual file, not overview files
n = 536; %jmax, OVERRIDE

varnames = {'Plot','Stem','File','Time', 'Displacement','Force'}; %,'Max Force', 'Displacement at Max Force'};
T = cell2table(cell(n,6), 'VariableNames', varnames);%, 'RowNames', rownames);
T.File = strings([height(T),1]);

%% IMPORT DATA INTO TABLE FROM INDIVIDUAL FILES
j=1;
for k = 1:length(plotname_repeatedRemoved)
    fileMatch = dir(strcat(directory,plotname_repeatedRemoved{k},'*.csv'));
    %sort so that any double digit filefollows single digit files
    for i = 1:length(fileMatch)
        [Time, Displacement,Force]=csvimport(strcat(directory, fileMatch(i).name),'columns',{'Time','Displacement','Force'});
        Plot = plotname_repeatedRemoved{k};
        File = fileMatch(i).name;
        Time=Time(2:end);
        Displacement=Displacement(2:end);
        Force=Force(2:end);
        
        idx_underscore=strfind(fileMatch(i).name,'_');
        idx_filenameEnd=strfind(fileMatch(i).name,'.csv');
        Stem = str2double(extractBetween(fileMatch(i).name,max(idx_underscore)+1,idx_filenameEnd-1));
        %Stem = str2double(extractBetween(fileMatch(i).name,'_','.csv'));
        
        %if k==1
        T.Plot{j}=Plot;
        T.Stem{j}=Stem;
        T.File{j}=fileMatch(i).name;
        T.Time(j)=mat2cell(str2double(erase(Time,'"')),length(Time));
        T.Displacement(j)=mat2cell(str2double(erase(Displacement,'"')),length(Time));
        T.Force(j)=mat2cell(str2double(erase(Force,'"')),length(Time));
        j=j+1;
    end
end
jmax=j-1;
%% Alter class types, selectively
T.Plot=string(T.Plot);
T.Stem=cell2mat(T.Stem);
%% SAVE PROGRESS
T_wheat = T;
%% PREPARE TABLE FOR MORE VALUE FROM OVERVIEW CSV FILES
T.LoadDeflection = nan(height(T),1);
T.Modulus = nan(height(T),1);
T.MaxLoad = nan(height(T),1);
T.DisplacementAtMaxLoad = nan(height(T),1);
T.BreakType = strings([height(T),1]);
T.Notes = strings([height(T),1]);

%% ACCESS WHOLE PLOT FILES %%without using this, filematch gets screwed up
% plotname = {filelist_overviews.name};
% plotname = erase(plotname,'.csv');
% plotname = strrep(plotname,'0CF','clearfield');
% plotname = strrep(plotname,'0HW','hardwinter');
% plotname = strrep(plotname,'0SW','softwinter');
% plotname = strrep(plotname,'0SBF','springbarleyfeed');

%% Go through each line in table and assign loadDeflection, Modulus, MaxLoad, DisplacementAtMaxLoad, Notes, BreakType
% Problems
j=1;
k=1;
while k <= length(plotname)
    [ndata, text, c] = xlsread(strcat(directory,filelist_overviews(k).name)); %c is of type cell
    fileMatch_overview = dir(strcat(directory,plotname{k},'*.csv')); %% differs from the last section (plotname_repeatedRemoved) because mutiple names need to be separated, because they have different overview files, but are grouped together as the same plot
    if sum(k==pre_repeatedIdx_list)
        %please count the number of individuals in the file and save it as
        %preCount
        pre_sampleCount=cell2mat(c(end,1));
        % the 7+i-1 pattern needs be adjusted to look for the Stem number
        % rather than running through the list in order
        % change 7+i-1 to 7+T.Stem(j)-1
        for i = 1:pre_sampleCount
            
            if ischar(cell2mat(c(7+T.Stem(j)-1,2))) 
                T.LoadDeflection(j)=str2double(cell2mat(c(7+T.Stem(j)-1,2)));
            else
                T.LoadDeflection(j)= cell2mat(c(7+T.Stem(j)-1,2));
            end
            
            T.Modulus(j) = cell2mat(c(7+T.Stem(j)-1,3)); %MPa, Young modulus, auto
            T.MaxLoad(j) = cell2mat(c(7+T.Stem(j)-1,4)); %N, max forces from each stalk
            T.DisplacementAtMaxLoad(j) = cell2mat(c(7+T.Stem(j)-1,5)); %mm, displacement at max
            T.Notes(j) = cell2mat(c(7+T.Stem(j)-1,6)); %notes V2
            T.BreakType(j) = cell2mat(c(7+T.Stem(j)-1,7)); %breaktype V2
            j=j+1;
        end
        
    elseif sum(k==repeatedIdx_list)
        repeated_sampleCount=cell2mat(c(end,1));
        %repeated_sampleCount+pre_sampleCount;
        
        for i = 1:repeated_sampleCount
            
            if ischar(cell2mat(c(7+T.Stem(j)-1,2)))
                T.LoadDeflection(j)=str2double(cell2mat(c(7+T.Stem(j)-1,2)));
            else
                T.LoadDeflection(j)= cell2mat(c(7+T.Stem(j)-1,2));
            end
            
            T.Modulus(j) = cell2mat(c(7+T.Stem(j)-1,3)); %MPa, Young modulus, auto
            T.MaxLoad(j) = cell2mat(c(7+T.Stem(j)-1,4)); %N, max forces from each stalk
            T.DisplacementAtMaxLoad(j) = cell2mat(c(7+T.Stem(j)-1,5)); %mm, displacement at max
            T.Notes(j) = cell2mat(c(7+T.Stem(j)-1,6)); %notes V2
            T.BreakType(j) = cell2mat(c(7+T.Stem(j)-1,7)); %breaktype V2
            j=j+1;
        end
        
    else
        
        for i = 1:length(fileMatch_overview)
            
            if ischar(cell2mat(c(7+T.Stem(j)-1,2)))
                T.LoadDeflection(j)=str2double(cell2mat(c(7+T.Stem(j)-1,2))); %% troubleshooting, i=10
            else
                T.LoadDeflection(j)= cell2mat(c(7+T.Stem(j)-1,2));
            end

            T.Modulus(j) = cell2mat(c(7+T.Stem(j)-1,3)); %MPa, Young modulus, auto
            T.MaxLoad(j) = cell2mat(c(7+T.Stem(j)-1,4)); %N, max forces from each stalk
            T.DisplacementAtMaxLoad(j) = cell2mat(c(7+T.Stem(j)-1,5)); %mm, displacement at max
            T.Notes(j) = cell2mat(c(7+T.Stem(j)-1,6)); %notes V2
            T.BreakType(j) = cell2mat(c(7+T.Stem(j)-1,7)); %breaktype V2
            j=j+1;
            %k=k+1; %here to compensate for stuff?
        end
        
    end
    k=k+1;
end

%% Descriptions and units
T.Properties.VariableUnits = {'', '', '', 's', 'mm', 'N', 'N/mm', 'MPa', 'N', 'mm', '', ''};
T.Properties.VariableDescriptions{'Time'} = 'Array of time values during INSTRON test.';
T.Properties.VariableDescriptions{'Displacement'} = 'Array of displacement values during INSTRON test.';
T.Properties.VariableDescriptions{'Force'} = 'Array of force values during INSTRON test.';
T.Properties.VariableDescriptions{'LoadDeflection'} = 'Automatically generated overview value based on INSTRON method. In this case, the slope was taken from the Force data at displacements of 0.8 mm and 1 mm. This number is not to be trusted. In some cases, the number was not generated at all.';
T.Properties.VariableDescriptions{'Modulus'} = 'Automatically generated overview value based on INSTRON method. This number requires an input for cross sectional area of the plant, which was not measured. Hypothetically, a coefficient can be discovered for adjustment, based on the span of the INSTRON at the time of testing.';
T.Properties.VariableDescriptions{'MaxLoad'} = 'Max load, identified automatically. Should be checked for accuracy.';
T.Properties.VariableDescriptions{'DisplacementAtMaxLoad'} = 'Displacement at max load, calculated automatically. Should be checked for accuracy.';
T.Properties.VariableDescriptions{'BreakType'} = 'Choices: CRUSHED, SNAPPED, or SPLINTERED.'; 
%mat file name: wheatInstron2020_IndividualAndOverview
%% COLDPLAY I WANT SOMETHING JUST LIKE THIS
% for j=1:544
%     j
%     stem=T.Stem(j)
%     row=7+T.Stem(j)-1
%     
% end
%% SAVE PROGRESS
T_wheat = T;
