% Author: Clayton Bennett
% Date 17 March 2022
% Title: Instron2021_dataCompilation_stemByStem_v2.m
% Description: Pulls in overview files for stem by stem data analysis.
%   Goal: Box plots to show spread from each variety.
%   Pulls in diameter data for each stem.
format compact
%% Import data

directory_script = 'H:\Instron Wheat Testing 2021\MatlabCode';
directory_data = 'H:\Instron Wheat Testing 2021\SOCEM2021'; % overview files and height data lives here
diameterSpreadsheet = 'H:\Instron Wheat Testing 2021\DiameterMeasurements_01312022.xlsx'; % most recent diameter measurement file
varietyNamesSpreadsheet = 'H:\Instron Wheat Testing 2021\varietyNames2021.xlsx';
plotHeightsSpreadsheet = 'H:\Instron Wheat Testing 2021\plotHeights2021.xlsx';

% If '\' is not input by the user as the final character in the directory
% assignment, add  it.
% 
if (directory_data(end)~='\')
    directory_data = strcat(directory_data,'\');
end

if (directory_script(end)~='\')
    directory_script = strcat(directory_script,'\');
end
% %%

cd(directory_data)

list_csvfiles = dir('*.csv');
n_plots = numel(list_csvfiles)'; % How many overview files are there in the directory?
n_stems = n_plots*10;
idxs_names = zeros(n_plots,1);
for i=1:n_plots
    idxs_names(i)=i*6+1-6;
end
tc=struct2cell(list_csvfiles);
names_overviewfiles = tc(idxs_names');
%% Prepare the table, T
% varnames = {'i','Variety','Plot','Stem','OverviewFile','StiffnessSlope_average','Strength_average','Modulus_average','DisplacementAtMaxLoad','StiffnessChoice','Breaktype','StiffnessChoice','Notes'};
varnames = {'i','j','k','Stem','Variety','Plot','OverviewFile'...
    ,'Stiffness','Strength','Modulus','DisplacementAtMaxLoad'...
    ,'EI','NodeMajorDiameter','NodeMinorDiameter','InternodeMajorDiameter'...
    ,'InternodeMinorDiameter','RawDisplacement','RawForce'...
    ,'PlotHeightArray','BreakType','StiffnessChoice','Notes'};
vartypes = {'int64','int64','int64','int64','int64'...
    ,'string','string','string','int64','int64'...
    ,'int64','int64','int64','int64','int64','int64'...
    ,'cell','cell','cell','int64','string','string','string'};

T = table('Size',[n_stems,numel(varnames)], 'VariableNames', varnames,'VariableTypes',vartypes); % Create table T.
% T.i = nan(height(T),1); % Prepare column "i" to be numbers.
% T.j = nan(height(T),1); % Prepare column to be numbers.
% T.k = nan(height(T),1); % Prepare column to be numbers.
% T.Stem = nan(height(T),1); % Prepare column "Stem" to be numbers.
% T.Variety = strings([height(T),1]);
% T.Plot = strings([height(T),1]); % Prepare column "Plot" to be strings.
% T.OverviewFile = strings([height(T),1]); % Prepare column "OverviewFile" to be strings.
% T.Stiffness = nan(height(T),1); % Prepare column "LoadDeflection" to be numbers.
% T.Strength = nan(height(T),1); % Prepare column "MaxLoad" to be numbers.
% T.Modulus = nan(height(T),1); % Prepare column to be numbers.
% T.DisplacementAtMaxLoad = nan(height(T),1); % Prepare column "DisplacementAtMaxLoad" to be numbers.
% T.NodeMajorDiameter = nan(height(T),1); % mm
% T.NodeMinorDiameter = nan(height(T),1); % mm
% T.InternodeMajorDiameter = nan(height(T),1); % mm
% T.InternodeMinorDiameter = nan(height(T),1); % mm
% %T.RawDisplacement = nan(height(T),1);
% %T.RawForce = nan(height(T),1);
% %T.PlotHeightsArray = nan(height(T),1);
% T.EI = nan(height(T),1);
% T.BreakType = strings([height(T),1]);
% T.StiffnessChoice = strings([height(T),1]);
% T.Notes = strings([height(T),1]);
%% Populate table columns: stem, overviewfile, and plot; based on file names
j=1;
for i=1:n_stems

    n_stem_text = char(string(i)); % assumes each plot overview file has 10 stems in it
    T.Stem(i)=str2double(n_stem_text(end)); % assumes each plot overview file has 10 stems in it
    
    if T.Stem(i)==0
        T.Stem(i)=10;
    end
    
%     if i>=10
%         j = str2num(n_stem_text(1:end-1));
%     else
%         j = 1;
%     end
    
if T.Stem(i)==1 && i>10
    j=j+1;
end

OverviewFile = string(names_overviewfiles(j));
Plot = eraseBetween(OverviewFile,min(strfind(OverviewFile,'_')),strlength(OverviewFile)); %for non-cyclic tests
Plot = extractAfter(Plot,1);
T.Plot(i)=Plot;
T.OverviewFile(i)=OverviewFile;
end
%% Import overview data

handle_waitbar_overviewFiles=waitbar(0,strcat('Data is being imported from ',string(n_plots),' overview Instron files. Computer speed, go!'));


for j=1:n_plots
    
    [ndata_notUsed, text_notUsed, c_overviewDataPullIn] = xlsread(strcat(directory_data,string(names_overviewfiles(j)))); %c is of class cell
    fprintf('%d.', j)
    waitbar(j/n_plots,handle_waitbar_overviewFiles)

    
            clear StiffnessChoicesArray StiffnessSlopesArray
            StiffnessChoicesArray = c_overviewDataPullIn(7:16,18);
            StiffnessSlopesArray = cell2mat(c_overviewDataPullIn(7:16,[3:6,8:11]));
            StiffnessSlopesList = zeros(10,1);
            
            for n_stem=1:10
                if string(StiffnessChoicesArray(n_stem,:))==string('Auto slope')
                    StiffnessSlopesList(n_stem) = StiffnessSlopesArray(n_stem,1);
                elseif StiffnessChoicesArray(n_stem,:)==string('Average all')
                    StiffnessSlopesList(n_stem) = mean(StiffnessSlopesArray(n_stem,:));
                elseif StiffnessChoicesArray(n_stem,:)==string('2nd lowest')
                    StiffnessSlopesList(n_stem) = max(mink(StiffnessSlopesArray(n_stem,:),2));
                else 
                    StiffnessSlopesList(n_stem) = StiffnessSlopesArray(n_stem,1);
                end
            end
            i_rangeStart=(j*10-9);
            i_rangeEnd=(j*10);
            T.Stiffness(i_rangeStart:i_rangeEnd) = StiffnessSlopesList; % N/mm
            T.Strength(i_rangeStart:i_rangeEnd) = cell2mat(c_overviewDataPullIn(7:16,13)); %N, max forces from each stalk
            T.Modulus(i_rangeStart:i_rangeEnd) = T.Stiffness(i_rangeStart:i_rangeEnd).*0.9182; %0.9182 comes from assumptions made about wall thickness and standard diameter, which is not accurate. Diameter measurentsd were recorded.
            T.BreakType(i_rangeStart:i_rangeEnd) = string(c_overviewDataPullIn(7:16,17)); %breaktype
            T.StiffnessChoice(i_rangeStart:i_rangeEnd) = string(c_overviewDataPullIn(7:16,18)); 
            T.Notes(i_rangeStart:i_rangeEnd) = string(c_overviewDataPullIn(7:16,19)); %notes
            
            
end
close(handle_waitbar_overviewFiles)

section6of7 = "Overview values have been imported."
%% Import variety names
[ndata_notUsed, text_notUsed, c_varietyDataPullIn] = xlsread(plotHeightsSpreadsheet); %c is of type cell 
columnIdx = 0;
size_c = size(c_varietyDataPullIn);
for j=1:n_plots
    for k=1:size_c(2)
        if T.Plot(j*10)==string(c_varietyDataPullIn(2,k))
            columnIdx=k;
        end
    end
    i_rangeStart=(j*10-9);
    i_rangeEnd=(j*10);
    T.Variety(i_rangeStart:i_rangeEnd) = cell2mat(c_varietyDataPullIn(1,columnIdx));
    
end
% reorder table to organize by Variety names
T=sortrows(T,find(string(varnames)=='Variety'),'ascend'); %sort by variety name % manual
%% Assign i and j values to i and j columns, after reordering based on variety names
j=1;
for i=1:n_stems
    T.i(i)=i;
    if T.Stem(i)==1 && i>10
        j=j+1;
    end
    T.j(i)=j;
end
%% Import diameter data
 
[ndata_notUsed, text_notUsed, c_diameterDataPullIn] = xlsread(diameterSpreadsheet); %c is of type cell 
cellblock=0;
size_c = size(c_diameterDataPullIn);
for j=1:n_plots
    for k=1:size_c(1)
        if T.Plot(j*10)==string(c_diameterDataPullIn(k,2))
            cellblock=k;
        end
    end
    diameterMat = cell2mat(c_diameterDataPullIn(cellblock:cellblock+9,4:7));
    
    i_rangeStart=(j*10-9);
    i_rangeEnd=(j*10);
    T.NodeMajorDiameter(i_rangeStart:i_rangeEnd) = diameterMat(:,1); %
    T.NodeMinorDiameter(i_rangeStart:i_rangeEnd) = diameterMat(:,2); %
    T.InternodeMajorDiameter(i_rangeStart:i_rangeEnd) = diameterMat(:,3); %
    T.InternodeMinorDiameter(i_rangeStart:i_rangeEnd) = diameterMat(:,4); %
end
%% Modulus of elasticity calculation, based on diameter
% Modulus (Auto Young's) [N/mm^2] is calculated from the Auto Slope [N/mm] and assumed specimen dimensions of 3 mm OD, 0.4 mm wall thickness, 8 mm height/span.

T.EI=T.Stiffness.*(80^3)/48; % N*mm
%% Import plot heights

columnIdx = 0;
size_c = size(c_varietyDataPullIn);
for i=1:height(T)
    for k=1:size_c(2)
        if T.Plot(i)==string(c_varietyDataPullIn(2,k))
            columnIdx=k;
        end
    end
    
    Heights = cell2mat(c_varietyDataPullIn(3:10,columnIdx));
    T.PlotHeightArray(i)=mat2cell(Heights,length(Heights));
    
end
%% Import raw data arrays from individual data files
% This is slow, because each file must be opened, recorded, and closed. That's okay.
% This import method should work for all individual Instron files.

handle_waitbar_individualFiles=waitbar(0,strcat('Arrays are being imported from ',string(height(T)),'individual Instron files. It is slow. But it is probably faster than you.')); % develop this more

for i = 1:height(T)

    waitbar(i/height(T),handle_waitbar_individualFiles)
    individualFileFolder = replace(T.OverviewFile(i),"2.csv","Exports\");
    individualFileName = replace(T.OverviewFile(i),"_2",strcat("_",string(T.Stem(i))));
    stringcatIndividualFileName = strcat(directory_data,individualFileFolder,individualFileName);
    [ndata_notUsed, text_notUsed, c_rawDataPullIn] = xlsread(stringcatIndividualFileName); %c is of type cell 
    
    % %% Remove first value from each imported column.
    Displacement = cell2mat(c_rawDataPullIn(3:end,2));
    Force = cell2mat(c_rawDataPullIn(3:end,3));
    %Time = cell2mat(c_rawDataPullIn(3:end,1)); % Not necessary to pull in time
    
    
    for k=1:length(Force)
        if Force(k)==max(Force)
            rowIdx=k;
        end
    end
    T.DisplacementAtMaxLoad(i)=Displacement(rowIdx);
    
    % %% Store entire arrays for each Instron test into each row j of table T.
    T.RawDisplacement(i)=mat2cell(Displacement,length(Displacement));
    T.RawForce(i)=mat2cell(Force,length(Force));
    %T.Time(i)=mat2cell(Time,length(Time));
    
end

close(handle_waitbar_individualFiles)

%  Up to this point, most things apply to importing only individual
% %%      files.
section4of7 = "Arrays have been imported from individual files."

% %% Find and assign DisplacementAtMaxLoad
% for i = 1:height(T)
%     Force=T.RawForce(i);
%     Displacement = T.RawDisplacement(i);
%     %Force=T.Force(i);
%     %Displacement = T.Displacement(i);
%     for k=1:length(Force)
%         if Force==max(Force)
%             rowIdx=k;
%         end
%     end
%     T.DisplacementAtMaxLoad(i)=Displacement(rowIdx);
% end
T.EI=T.Stiffness.*(80^3)/48; % N*
%% Descriptions and units
% %% Is scalable only if in metric and these are the expected variables. +*#*#*#*#*#*+
T.Properties.VariableUnits = {'','','','', '', '','','N/mm','N','N/mm^2','mm','N*mm','mm','mm','mm','mm','mm','N','mm','','',''};
%T.Properties.VariableDescriptions{'Time'} = 'Array of time values during INSTRON test.';
T.Properties.VariableDescriptions{'RawDisplacement'} = 'Array of displacement values during INSTRON test.';
T.Properties.VariableDescriptions{'RawForce'} = 'Array of force values during INSTRON test.';
T.Properties.VariableDescriptions{'Stiffness'} = 'Slopes were carefully chosen from assessment of 9 linear elastic region fits. Generally the Auto slope was used.';
T.Properties.VariableDescriptions{'Modulus'} = 'Automatically generated overview value based on INSTRON method. This number requires an input for cross sectional area of the plant, which was not measured. Hypothetically, a coefficient can be discovered for adjustment, based on the span of the INSTRON at the time of testing.';
T.Properties.VariableDescriptions{'Strength'} = 'Max load.';
T.Properties.VariableDescriptions{'EI'} = 'EI=Stiffness*(TestSpan^3)/48, where Testspan = 80 mm.';
T.Properties.VariableDescriptions{'DisplacementAtMaxLoad'} = 'Displacement at max load.';
T.Properties.VariableDescriptions{'BreakType'} = 'Choices: CRUSHED, SNAPPED, or SPLINTERED.';
T.Properties.VariableDescriptions{'Variety'} = 'Genetic variety. 4 plots per variety were tested when possible, in 2021.';
T.Properties.VariableDescriptions{'Plot'} = 'Indicates reference location of experimental plot within the Baldus Rd field, 2021.';
T.Properties.VariableDescriptions{'NodeMajorDiameter'} = 'Node diameter in direction of Instron travel.';
T.Properties.VariableDescriptions{'NodeMinorDiameter'} = 'Node diameter in direction perpindicular to Instron travel.';
T.Properties.VariableDescriptions{'InternodeMajorDiameter'} = 'Internode diameter in direction of Instron travel.';
T.Properties.VariableDescriptions{'InternodeMinorDiameter'} = 'Internode diameter in direction perpindicular to Instron travel.';
T.Properties.VariableDescriptions{'StiffnessChoice'} = 'Slopes were carefully chosen from assessment of 9 linear elastic region fits: Average all, 2nd lowest, Auto slope, Max, Min. Generally the Auto slope was used.';
%% Data Processing Above This Line ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
%% Plots Generated Below This Line .......................................
%% Stiffness vs Strength, Scatter, Auto Fit
hold off
x = T.Stiffness;
y = T.Strength;
p = polyfit(x,y,1);
% Evaluate the fitted polynomial p and plot:
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
legend('data','linear fit')
%mslope=p(1);
%yint=p(2);
%yfit=p(1)*x+p(2);
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel('Stiffness [N/mm]')
ylabel('Max Force [N]')
title('Stiffness vs Strength, Wheat 2021, Instron')
string1 = {'10 stem samples each from','52 plots were tested.'};
text(3,5,string1)
%% Stiffness vs DisplacementAtMaxLoad, Scatter, Play with line direction for fun.
% Fit a polynomial p of degree 1 to the (x,y) data:
hold off
title('Max Load vs Displacement at Max Load, Wheat 2021, Instron')
for j=45%1:n_plots
    x = T.DisplacementAtMaxLoad((j*10-9):(j*10));
    y = T.Stiffness((j*10-9):(j*10));
%     [Y,I]=sortrows(y);
%     X=x(I);
    [X,I]=sortrows(x);
    Y=y(I);
% X=x;
% Y=y;
    
    plot(X,Y,'--*')
    hold on
end
%legend({'52 Experimental Wheat Plots'},'Location','Northeast')
xlabel('Displacement at max load [mm]')
ylabel('Stiffness [N/mm]')
%% Stiffness,Strength, Displacement vs DisplacementAtMaxLoad, Scatter, Auto Fit
% Stiffness vs DisplacementAtMaxLoad, Scatter, Auto Fit
% R^2=0.2
hold off
subplot(3,1,1)
x = T.DisplacementAtMaxLoad;
y = T.Stiffness;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Wheat Stems',stringFit},'Location','Northeast')
xlabel('Displacement at max load [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Displacement at Max Load, Wheat 2021, Instron')

% Strength vs DisplacementAtMaxLoad, Scatter, Noisy.
% R^2=0.04. Noise.
hold off
subplot(3,1,2)
x = T.DisplacementAtMaxLoad;
y = T.Strength;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Wheat Stems',stringFit},'Location','Northeast')
xlabel('Displacement at max load [mm]')
ylabel('Max Load [N]')
title('Strength vs Displacement at Max Load, Wheat 2021, Instron')

% Strength vs DisplacementAtMaxLoad, Scatter, Noisy.
% R^2=0.04. Noise.
hold off
subplot(3,1,3)
x = T.DisplacementAtMaxLoad;
y = T.NodeMajorDiameter;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Wheat Stems',stringFit},'Location','Northeast')
xlabel('Displacement at max load [mm]')
ylabel('Diameter [mm]')
title('Diameter (Node Major) vs Displacement at Max Load, Wheat 2021, Instron')
%% Stiffness vs Diameters, Scatter Subplots, Auto Fit
% Stiffness vs Node Major Diameter, Scatter, Auto Fit
hold off
subplot(2,2,1)
x = T.NodeMajorDiameter;
y = T.Stiffness;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel('Node Major Diameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Node Major Diameter, Wheat 2021, Instron')

%%Stiffness vs Node Minor Diameter, Scatter, Auto Fit
hold off
subplot(2,2,2)
x = T.NodeMinorDiameter;
y = T.Stiffness;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel('Node Minor Diameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Node Minor Diameter, Wheat 2021, Instron')

% Stiffness vs Internode Major Diameter, Scatter, Auto Fit
hold off
subplot(2,2,3)
x = T.InternodeMajorDiameter;
y = T.Stiffness;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel(' Internode Major Diameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Internode Major Diameter, Wheat 2021, Instron')

% Stiffness vs Internode Minor Diameter, Scatter, Auto Fit
hold off
subplot(2,2,4)
x = T.InternodeMinorDiameter;
y = T.Stiffness;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel('Internode MinorDiameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Internode Minor Diameter, Wheat 2021, Instron')
%% Stiffness vs Node Major Diameter (>3mm), Scatter, Auto Fit
hold off
NodeMajorDiameter_above3 = [T.NodeMajorDiameter];
StiffnessSlope_some = [T.Stiffness];
i=1;
while i<=length(NodeMajorDiameter_above3)
    if NodeMajorDiameter_above3(i)<3
        NodeMajorDiameter_above3(i)=[];
        StiffnessSlope_some(i)=[];
        i;
    else
        i=i+1;
    end
end

x = NodeMajorDiameter_above3;
y = StiffnessSlope_some;
p = polyfit(x,y,1);
% Evaluate the fitted polynomial p and plot:
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
legend('data','linear fit')
%mslope=p(1);
%yint=p(2);
%yfit=p(1)*x+p(2);
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')

xlabel('Node Major Diameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness and Node Major Diameter Correlation, Wheat 2021, Instron')

string1 = {'Only data from stems with a diameter >3mm included.'};
text(3.1,0.5,string1,'BackgroundColor','w','EdgeColor','k')
%% Stiffness vs Node Major Diameter, through 0, mirrored, Scatter Subplots, parabolic fit
hold off
x1 = T.NodeMajorDiameter;
y = T.Stiffness;
x2= -1.*x1;
%x3 = (linspace(0,0))';
%y3 = (linspace(0,0))';
%X = [x1;x2;x3];
%Y = [y;y;y3];
X = [x1;x2];
Y = [y;y];

%p = polyfit(X,Y,2);
%f = polyval(p,X);
%plot(X,Y,'o',X,f,'-')
plot(X,Y,'o')
%rsq=corr(x,y)^2;
%stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
%legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel('Node Major Diameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Node Major Diameter, Wheat 2021, Instron')

hold on
plot([7,7],[-20,55])
legend('raw data','D=7mm')
axis([-10,10,-2 50])
%% Strength vs Node Major Diameter, through 0, mirrored, Scatter Subplots, parabolic fit
hold off
x1 = T.NodeMajorDiameter;
y = T.Stiffness;
x2= -1.*x1;
%x3 = (linspace(0,0,100))';
%y3 = (linspace(0,0,100))';
%X = [x1;x2;x3];
%Y = [y;y;y3];
X = [x1;x2];
Y = [y;y];
[X,I]=sortrows(X);
Y=Y(I);

p = polyfit(X,Y,4);
f = polyval(p,X);
plot(X,Y,'o',X,f,'-')
%plot(X,Y,'o')
rsq=string('');
%rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel('Node Major Diameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Node Major Diameter, Wheat 2021, Instron')

hold on
plot([7,7],[-20,120])

scatter([0],[0])
%legend('raw data','D=7mm','(0,0)')
axis([1.8,4.7,-0.5,7])
%% Strength vs Diameters, Scatter Subplots, Auto Fit
% Strength vs Node Major Diameter, Scatter, Auto Fit
hold off
subplot(2,2,1)
x = T.NodeMajorDiameter;
y = T.Strength;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel('Node Major Diameter [mm]')
ylabel('Strength [N]')
title('Strength vs Node Major Diameter, Wheat 2021, Instron')

% Strength vs Node Minor Diameter, Scatter, Auto Fit
hold off
subplot(2,2,2)
x = T.NodeMinorDiameter;
y = T.Strength;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel('Node Minor Diameter [mm]')
ylabel('Strength [N]')
title('Strength vs Node Minor Diameter, Wheat 2021, Instron')

% Strength vs Internode Major Diameter, Scatter, Auto Fit
hold off
subplot(2,2,3)
x = T.InternodeMajorDiameter;
y = T.Strength;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel(' Internode Major Diameter [mm]')
ylabel('Strength [N]')
title('Strength vs Internode Major Diameter, Wheat 2021, Instron')

% Strength vs Internode Minor Diameter, Scatter, Auto Fit
hold off
subplot(2,2,4)
x = T.InternodeMinorDiameter;
y = T.Strength;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel('Internode MinorDiameter [mm]')
ylabel('Strength [N]')
title('Strength vs Internode Minor Diameter, Wheat 2021, Instron')
%% Diameters vs Diameter, Scatter, Auto Fit
% Node Major Diam vs Node Minor Diam, Scatter, Auto Fit
hold off
subplot(2,2,1)
x = T.NodeMinorDiameter;
y = T.NodeMajorDiameter;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel('Node Minor Diameter [mm]')
ylabel('Node Major Diameter [mm]')
title('Node Major Diameter vs Node Minor Diameter, Wheat 2021')

% Node Major Diam vs Internode Major Diam, Scatter, Auto Fit
hold off
subplot(2,2,2)
x = T.InternodeMajorDiameter;
y = T.NodeMajorDiameter;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel('Internode Major Diameter [mm]')
ylabel('Node Major Diameter [mm]')
title('Node Major Diameter vs Internode Major Diameter, Wheat 2021')

% Node Major Diam vs Internode Minor Diam, Scatter, Auto Fit
hold off
subplot(2,2,3)
x = T.InternodeMinorDiameter;
y = T.NodeMajorDiameter;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel('Internode Minor Diameter [mm]')
ylabel('Node Major Diameter [mm]')
title('Node Major Diameter vs Internode Minor Diameter, Wheat 2021')

% Internode Major Diam vs Internode Minor Diam, Scatter, Auto Fit
hold off
subplot(2,2,4)
x = T.InternodeMinorDiameter;
y = T.InternodeMajorDiameter;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel('Internode Minor Diameter [mm]')
ylabel('Internode Major Diameter [mm]')
title('Internode Major vs Internode Minor Diameter, Wheat 2021')
%% Stiffness scatterShape
% colors per variey
% connected shape for each plot
% order so that no lines interstect
%close(hf1,hf2)
close gcf
hold on
header2 = string('This is the compiled Instron data for the 2021-2022 SOCEM validation study at the University of Idaho.');
header3 = string('Wheat was tested with both Instron and SOCEM devices.');
header4 = string('14 different genetic varieties are represented.')
header1 = string('10 stems were measured from each of the 52 plots.');
header5 = string('The lowest node possible on each stem was tested for 520 stems.');

TableUnits = string(Table.Properties.VariableUnits)

T_sansSamplingError = T;
T_sansSamplingError(find(T_sansSamplingError.Variety=='Seeding Error'),:) = [];
% T_sansSamplingError = T; % uncomment to include Sampling Error. Should
% probably just throw it away.

varieties = unique(T_sansSamplingError.Variety);
colormat = [77/255 190/255 70/255 % green
0,0.4470,0.7410 % blue
255/255 153/255 200/255 % pink
0.9290,0.6940,0.1250  % yellow
0.4940,0.1840,0.5560 % purple
0.6350,0.0780,0.1840 % crimson
178/255 140/255 0/255 % tan
0/255 0/255 0/255 % black
255/255 155/255 50/255 % orange
75/255 190/255 240/255 % light blue
155/255 155/255 155/255 % gray
150/255 255/255 150/255 % sea green
255/255 255/255 0/255 % ugly bright yellow
255/255 0/255 0/255]; % bright red
%all black override, for scientific journal
colormatblack=colormat;
for k=1:length(colormat)
    colormatblack(k,:)=[0 0 0];
end
%colormat=colormatblack;
r2text = string(0.689); % 0.8049
shapemat = string({'.','o','x','+','*','s','d','v','^','<','>','p','h','h'});
linemat = string({'-.','-.','-.','-.','-.','-.','-.','-','-.','-.','-.','-.','-.','-.'});
stylemat = linemat+shapemat; % shapemat;% linemat+shapemat; % edit line style here
sizemat = 100*ones(numel(varieties),1);
for k=1:numel(varieties)
    %scatter([0,0],[0,0],sizemat(k),colormat(k,:),'filled');
    plot([0,0],[0,0],shapemat(k),'Color',colormatblack(k,:));
end


i=1;
for k = 13%1:numel(varieties) % set k to a value from 0 to 14 to show 
    %T_copy1=T_sansSamplingError(:,[1:12,19]); % only keep presentable columns
    T_copy1=T_sansSamplingError(:,[1:15,19]); % only keep presentable columns
    notK=find(T_copy1.Variety~=varieties(k));
    T_copy1(notK,:)=[];
    plots = unique(T_copy1.Plot);
    variety = varieties(k)
    plots
        for m = 1:numel(plots)
            T_copy2=T_copy1;
            notM=find(T_copy2.Plot~=plots(m));
            T_copy2(notM,:)=[];
            x = T_copy2.InternodeMajorDiameter; %changex and y axis here % R^2 value is hard coded!
            y  = T_copy2.Stiffness;
            i=i+numel(x);
            T_copy3 = T_copy2(:,[3,7:end]);
            Plot = strcat(variety,{', '},plots(m))
            Table=T_copy3
            TableUnits = string(Table.Properties.VariableUnits)
            
            p = polyfit(x,y,1);
            f = polyval(p,x);
            y_above=((y-f)>0).*y;
            y_below=((y-f)<=0).*y;
            x_above=((y-f)>0).*x;
            x_below=((y-f)<=0).*x;
            [y_above,I] = sortrows(y_above,'ascend');
            x_above=x_above(I);
            [y_below,I] = sortrows(y_below,'descend');
            x_below=x_below(I);
            %find median x
%             x_med = median(x);
%             x_left = ((x<=x_med).*x);
%             y_left = ((x<=x_med).*y);
%             x_right = ((x>x_med).*x);
%             y_right = ((x>x_med).*y);
            [y_above,I] = sortrows(y_above,'ascend');
            x_above=x_above(I);
            [y_below,I] = sortrows(y_below,'descend');
            x_below=x_below(I);
            %remove 0's from lists
            izero=find(x_above==0);
            x_above(izero,:)=[];
            izero=find(y_above==0);
            y_above(izero,:)=[];
            izero=find(x_below==0);
            x_below(izero,:)=[];
            izero=find(y_below==0);
            y_below(izero,:)=[];
            
            plot(x_above,y_above,stylemat(k),'Color',colormat(m,:))%,'Marker','.')
            hold on
            plot([x_above(end);x_below;x_above(1)],[y_above(end);y_below;y_above(1)],stylemat(k),'Color',colormat(m,:))%,'Marker','.')
            xtext = 1.68; % 2.
            htextPlots = text(xtext,3.2,{strcat('Green: ',{' '},string(plots(1)));strcat('Blue: ',{' '},string(plots(2)));strcat('Pink: ',{' '},string(plots(3)));strcat('Yellow: ',{' '},string(plots(4)))},'BackgroundColor','w','EdgeColor','k');
            %htextPlots = text(xtext,3.2,{strcat('Green: ',{' '},string(plots(1)));strcat('Blue: ',{' '},string(plots(2)));strcat('Pink: ',{' '},string(plots(3)))},'BackgroundColor','w','EdgeColor','k');
            htextVariety = text(xtext,2.5,{strcat('Variety:',{' '},variety)},'BackgroundColor','w','EdgeColor','k');

        end
end

% best fit line
x=T.InternodeMajorDiameter; % change here
y=T.Stiffness;
p = polyfit(x,y,4);
f = polyval(p,x);
[x,I] = sortrows(x,'ascend');
f=f(I);
plot(x,f,'-k')
% The varieties with the most points, and sum of magnitude, above the line
% are king.


title('Stiffness vs Internode Major Diameter, Wheat 2021, Instron')
axis([2,4.5,0,6])
axis([1.65,3.7,0,6])
xlabel('Diameter (mm)')
ylabel('Stiffness N/mm')
legend(varieties,'Location','southeast')
stringFit = strcat('y=',string(p(1)),'*x^4+',string(p(2)),'*x^3+',string(p(3)),'*x^2+',string(p(4)),'*x+',string(p(5)));
xtext = 1.68; % 2.1
htext=text(xtext,5.8,'10 stems were measured from each of the 52 plots.','BackgroundColor','w','EdgeColor','k'); ;
%htext2=text(2.1,5.3,'Pink is Nixon. Nixon tends to on top of curve and is grouped well.','BackgroundColor','w','EdgeColor','k'); ;
htext3=text(xtext,5,{'13 different genetic varieties are represented,';'with stems collected from 4 plots of each variety.'},'BackgroundColor','w','EdgeColor','k'); ;
htext4=text(xtext,5.55,'The lowest node possible on each stem was tested for 520 stems.','BackgroundColor','w','EdgeColor','k'); ;
r2text = string(0.689); % 0.8049
htextFit = text(xtext,4,{'4th order polynomial fit:';stringFit;strcat('R^2 =',{' '},r2text)},'BackgroundColor','w','EdgeColor','k');
% for values less than average x, make list x_left and make list of correlated y values, y_left
% order list of y_left from least to greatest
% for values greater than average x, make list x_right and make list of
% correlated y values, y_right
% order list of y_right from greatest to least
%% scatterSquare, copied for reference from nodeToNode script
hold off
hf1 = figure(1);
hold off
plot([0 1],[0 0],'-','Color',[0,0.4470,0.7410]) % blue
hold on
plot([0 1],[0 0],'-','Color',[0.6350,0.0780,0.1840]) % crimson
plot([0 1],[0 0],'-','Color',[0.4940,0.1840,0.5560]) % purple
plot([0 1],[0 0],'-','Color',[0.9290,0.6940,0.1250]) % yellow
plot([0 1],[0 0],'-','Color',[255/255 153/255 200/255]) % pink
plot([0 1],[0 0],'-','Color',[77/255 190/255 70/255]) % green

i_purple=[];
i_yellow=[];
i_crimson=[];
i_blue=[];
i_pink=[];
i_green=[];
i_black=[];
hold on
i=1;
k=1;
while i<height(T)
    if T.Node(i)==1 && T.Node(i+1)==2
        Y=[T.Stiffness(i),T.Stiffness(i+1),T.Stiffness(i+1),T.Stiffness(i),T.Stiffness(i)];
        X=[T.NodeMajorDiameter(i+1),T.NodeMajorDiameter(i+1),T.NodeMajorDiameter(i),T.NodeMajorDiameter(i),T.NodeMajorDiameter(i+1)];
        
        % if statement to decide color
        % purple (stiffness down, diameter up), yellow (stiffness up, diameter down), red (both go up), blue (both go down)
        if T.Stiffness(i) > T.Stiffness(i+1) && T.NodeMajorDiameter(i) < T.NodeMajorDiameter(i+1)
            colormat = [0.4940,0.1840,0.5560]; %purple
            i_purple(end+1)=i;
        elseif T.Stiffness(i) < T.Stiffness(i+1) && T.NodeMajorDiameter(i) > T.NodeMajorDiameter(i+1)
            colormat = [0.9290,0.6940,0.1250]; %yellow
            i_yellow(end+1)=i;
        elseif T.Stiffness(i) < T.Stiffness(i+1) && T.NodeMajorDiameter(i) < T.NodeMajorDiameter(i+1)
            colormat = [0.6350,0.0780,0.1840]; %crimson
            i_crimson(end+1)=i;
        elseif T.Stiffness(i) > T.Stiffness(i+1) && T.NodeMajorDiameter(i) > T.NodeMajorDiameter(i+1)
            colormat = [0,0.4470,0.7410]; %blue
            i_blue(end+1)=i;
        elseif T.NodeMajorDiameter(i) == T.NodeMajorDiameter(i+1) && T.Stiffness(i) > T.Stiffness(i+1)
            colormat = [255/255 153/255 200/255]; %pink
            i_pink(end+1)=i;
        elseif T.NodeMajorDiameter(i) == T.NodeMajorDiameter(i+1) && T.Stiffness(i) < T.Stiffness(i+1)
            colormat = [77/255 190/255 70/255]; %green
            i_green(end+1)=i;
        elseif T.Stiffness(i) == T.Stiffness(i+1)
            colormat = [255/255 255/255 255/255]; %black
            i_black(end+1)=i;
        end
        i=i+2;
        k=k+1;
    else
        msg = 'help'
        i=i+1
    end
    
    hold on
    plot(X,Y,'-',X(1),Y(2),'*','Color',colormat)
    %plot(X,Y,'-','Color',colormat)
end
updateLegendVector = zeros(k,1);
updateLegendVector([1,3,5,7])=1;
title('Stiffness Taper and Diameter Taper, Nodes 1 and 2, Wheat 2021, Instron')
xlabel('Diameter (mm)')
ylabel('Stiffness (N/mm)')
axis([1.5,4.5,0,5])
hleg=legend({'Node 1 Stiffer, Node 1 Thicker','Node 2 Stiffer, Node 2 Thicker','Node 1 Stiffer, Node 2 Thicker','Node 2 Stiffer, Node 1 Thicker','Node 1 Stiffer, Same Diameter','Node 2 Stiffer, Same Diameter'},'AutoUpdate','off','Location','west');
hleg.Title.String='Color meaning';
text(1.65,4.5,'Each box represents one stem. The asterisk is the 1st node, and the opposite corner is the 2nd node.','EdgeColor','k')
% add 4th order poly trendlines, two, one for each node

%% Box plots - Diameters, by Plot and Variety
% Attmept to create labels for tight boxplots, to only show one reduntant
% variety label.
labelList=T.Variety;
labelIdx=zeros(length(labelList),1);
k=1;
labelIdx(1)=k;
for i=2:length(labelList)
    if labelList(i-1)==labelList(i)
        labelIdx(i)=0;
    else
        k=k+1;
        labelIdx(i)=k;
    end
end

for i =1:length(labelIdx)
    if labelIdx(i)==0
        labelList(i)=NaN;
    end
end

% Box plot - Node Major Diameters, by Plot and Variety
hold off
subplot(2,2,1)
boxplot(T.NodeMajorDiameter,T.Plot,'labels',T.Variety+','+T.Plot,'labelverbosity','minor')%
%boxplot(T.NodeMajorDiameter,T.Plot,'labels',labelList,'labelverbosity','minor')%
ylabel('Diameter [mm]') % 
title('Node Major Diameters, each Wheat Plot, 2021')
xtickangle(70)
hold on
% show vertical lines to separate variety groups
x1=4.5;
xn=x1;
for k=1:12
    plot([xn,xn],[-100,100],'-k')
    xn=xn+4;
end
htext=text(45,-1,'10 stems were measured from each of the 52 plots.','BackgroundColor','w','EdgeColor','k'); 

% Box plot - Node Minor Diameter, by Plot and Variety
hold off
subplot(2,2,2)
boxplot(T.NodeMinorDiameter,T.Plot,'labels',T.Variety+','+T.Plot,'labelverbosity','major')%
ylabel('Diameter [mm]') % 
title('Node Minor Diameters, each Wheat Plot, 2021')
xtickangle(70)
hold on
% show vertical lines to separate variety groups
x1=4.5;
xn=x1;
for k=1:12
    plot([xn,xn],[-100,100],'-k')
    xn=xn+4;
end
%htext=text(35,4.5,'10 stems were measured from each of the 52 plots.','BackgroundColor','w','EdgeColor','k'); 

% Box plot - Internode Major Diameter, by Plot and Variety
hold off
subplot(2,2,3)
boxplot(T.InternodeMajorDiameter,T.Plot,'labels',T.Variety+','+T.Plot,'labelverbosity','minor')%
ylabel('Diameter [mm]') % 
title('Internode Major Diameters, each Wheat Plot, 2021')
xtickangle(70)
hold on
% show vertical lines to separate variety groups
x1=4.5;
xn=x1;
for k=1:12
    plot([xn,xn],[-100,100],'-k')
    xn=xn+4;
end
%htext=text(35,4.5,'10 stems were measured from each of the 52 plots.','BackgroundColor','w','EdgeColor','k'); 

% Box plot - Internode Minor Diameter, by Plot and Variety
hold off
subplot(2,2,4)
boxplot(T.InternodeMinorDiameter,T.Plot,'labels',T.Variety+','+T.Plot,'labelverbosity','major')%
ylabel('Diameter [mm]') % 
title('Internode Minor Diameters, each Wheat Plot, 2021')
xtickangle(70)
hold on
% show vertical lines to separate variety groups
x1=4.5;
xn=x1;
for k=1:12
    plot([xn,xn],[-100,100],'-k')
    xn=xn+4;
end
%htext=text(35,4.5,'10 stems were measured from each of the 52 plots.','BackgroundColor','w','EdgeColor','k'); 
%% Box plot - Four diameter measurements
hold off
diameterMatrix = zeros(height(T),4);
diameterMatrix(:,1)=[T.NodeMajorDiameter];
diameterMatrix(:,2)=[T.NodeMajorDiameter];
diameterMatrix(:,3)=[T.InternodeMajorDiameter];
diameterMatrix(:,4)=[T.InternodeMinorDiameter];
diameterLabels = {'Node Major','Node Minor','Internode Major','Internode Minor'};
boxplot(diameterMatrix,diameterLabels)
% boxplot(T.NodeMajorDiameter,0)%
% boxplot(T.NodeMinorDiameter,0)
% boxplot(T.InternodeMajorDiameter,0)
% boxplot(T.InternodeMajorDiameter,0)
ylabel('Diameter [mm]') % 
title('Diameter Measurements, for each Wheat Plot, 2021')
%xtickangle(70)
%% Box plot - Stiffness, by Plot
hold off
boxplot(T.Stiffness,T.Plot,'labels',T.Variety+','+T.Plot,'labelverbosity','minor')%,T.InternodeMajorDiameter,T.InternodeMinorDiameter)
ylabel('Stiffness [N/mm]') % 
title('Stiffness, for each Wheat Plot, 2021')
xtickangle(70)

hold on
% show vertical lines to separate variety groups
x1=4.5;
xn=x1;
for k=1:12
    plot([xn,xn],[-100,100],'-k')
    xn=xn+4;
end

htext=text(36,5.9,'10 stems were measured from each of the 52 plots.','BackgroundColor','w','EdgeColor','k');
%% Box plot - Strength, by Plot
hold off
boxplot(T.Strength,T.Plot,'labels',T.Variety+','+T.Plot,'labelverbosity','minor')%,T.InternodeMajorDiameter,T.InternodeMinorDiameter)
ylabel('Strength [N]') % 
title('Max Force, for each Wheat Plot, 2021')
xtickangle(70)

hold on
% show vertical lines to separate variety groups
x1=4.5;
xn=x1;
for k=1:12
    plot([xn,xn],[-100,100],'-k')
    xn=xn+4;
end

htext=text(36,22,'10 stems were measured from each of the 52 plots.','BackgroundColor','w','EdgeColor','k');
%% Box plot - Strength, total
hold off
boxplot(T.Strength,1)
ylabel('Max Force [N]') % 
xlabel('') % 
title('Strength of 520 Stems, from 52 Plots, Wheat 2021, Instron')
%% Box plot - Stiffness, total
hold off
boxplot(T.Stiffness,1)
ylabel('Stiffness [N/mm]') % 
xlabel('') % 
title('Stiffness of 520 Stems, from 52 Plots, Wheat 2021, Instron')
%% End matter
cd(directory_script)


