'''
Title: pushDirection_fileNameScan
Author: Clayton Bennett (version 1)
Last edited: 02/14/2022, by Clayton Bennett (version 1)


Purpose: Assess direction of test from text in filename.

Details:
    Default to forward, if no typical text indicators are found in the filename.
    For August 2021 from Genesee, Baldus Road, directions were:
        - Forward = East
        - Reverse = West
        - rightToLeft = North
        - leftToRight = South

    If the text indicator "side" was used in the August 2021 data, it meant South.

    Import into SOCEM_Data_Analysis.py.
    The returned value {direction} will be used to alter
    how the {heights} variable is used, changing the {heights} values
    apply to the EI calculation.

    This tool was designed as an adaptation of the functionality
    of the SOCEM_Data_Analysis.py script, originally authored by
    Austin Bebee in 

2/15/2022
'''
# Required libraries
import numpy as np
import math
import pandas as pd
import sideHitLengthRange_fileNameScan # not yet in service
from sideHitLengthRange_fileNameScan import sideHitLengthRange

def pushDirection(filename):
    stringsEast = ['forward', 'east']
    stringsSouth = ['side','perpindicular','leftToRight','south']
    stringsWest = ['backwards','reverse','west']
    stringsNorth = ['north', 'rightToLeft']
    if (stringsEast[0] in filename) or (stringsEast[1] in filename):
        direction = 'forward'
        rowsBasedOnDirection = 3
        #heights = heights
        print(direction)
        
    elif (stringsWest[0] in filename) or (stringsWest[1] in filename) or (stringsWest[2] in filename):
        direction = 'reverse'
        rowsBasedOnDirection = 3
        # heights = heights.reverse() # wrong, but indicative of necessary edit
        print(direction)
        
    elif (stringsSouth[0] in filename) or (stringsSouth[1] in filename) or (stringsSouth[2] in filename) or (stringsSouth[3] in filename):
        direction = 'leftToRight'
        #sideHitLengthRange(filename)
        rowsBasedOnDirection = 5
        # heights = heights.leftToRight() # heights will end up with single number, which will be the average of the heights between the horizontal references at each end of the force bar, reference in filename 
        print(direction)

    elif (stringsNorth[0] in filename) or (stringsNorth[1] in filename):
        direction = 'rightToLeft'
        rowsBasedOnDirection = 5
        #heights = heights.rightToLeft() # heights will end up with single number, which will be the average of the heights between the horizontal references at each end of the force bar, reference in filename 
        print(direction)

    else:
        direction = 'forward'
        rowsBasedOnDirection = 3
        #heights = heights
        print(direction)

        return direction #, rowsBasedOnDirection, heights
