% variationfromsuggestedheight.m

Ts10.ForceBarHeight
Ts10.StemHeightsX
Ts10.HorzX
Ts10.HeightRatio=Ts10.ForceBarHeight./Ts10.AvgHeight;
Ts10.AvgHeight

optiH_file='C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\SOCEM_CODE\optiH.py';
system(optiH_file)
step=0.5;

%%

optiHeights = [5.8625, 6.5, 7.425, 6.3325, 7.0075, 4.5, 6.825, 6.6625, 7.0125, 5.5625, 4.975, 7.3625, 6.0, 5.95, 5.625, 8.55, 8.45, 6.475, 5.475, 5.2875, 5.25, 5.3, 5.775, 6.0375, 4.025, 5.6375, 6.5125, 6.0, 4.5, 5.425, 5.65, 5.3, 5.15, 4.95, 5.2625, 5.2625, 6.6625, 6.35, 6.15, 6.0375, 6.175, 7.05, 5.975, 6.3375, 6.325, 4.55, 6.675, 5.95, 4.9375, 6.1625, 6.3, 6.3];
plotList = ["CF141", "CF247", "CF351", "CF352", "CF452", "CF145", "CF147", "CF149", "CF151", "CF244", "CF245", "CF246", "CF249", "CF341", "CF342", "CF349", "CF443", "CF444", "CF447", "HW115", "HW122", "HW202", "HW211", "HW218", "HW221", "HW309", "HW313", "HW318", "HW319", "HW401", "HW402", "HW412", "HW416", "HW418", "HW421", "SW102", "SW104", "SW116", "SW126", "SW201", "SW203", "SW204", "SW226", "SW316", "SW319", "SW332", "SW334", "SW339", "SW416", "SW418", "SW427", "SW429"];
colormat=zeros(height(Ts10),3);
textmat={};
xlist = [];
ylist = [];
x2list = [];
plot2list = {};
variety2list = {};

for i=1:height(Ts10)
Ts10.OptimalHeight(i) = optiHeights(plotList==Ts10.Plot(i));
    if abs(Ts10.OptimalHeight(i)-Ts10.ForceBarHeight(i))>0.1
        colormat(i,:) = [0.6350,0.0780,0.1840]; % crimson
        textmat{end+1}=plotList(plotList==Ts10.Plot(i));
        disp(sprintf('%s, %s, %g inches lower than recommended, %g ratio',Ts10.Variety(i),Ts10.Plot(i),abs(Ts10.OptimalHeight(i)-Ts10.ForceBarHeight(i)),Ts10.HeightRatio(i)))
        xlist(end+1) = Ts10.OptimalHeight(i);
        ylist(end+1) = Ts10.ForceBarHeight(i);
    else
        colormat(i,:)=[0,0.4470,0.7410];   % blue
        textmat{end+1}="";
        x2list(end+1) = Ts10.EIM(i);
        plot2list{end+1} = Ts10.Plot(i);
        variety2list{end+1} = Ts10.Variety(i);
    end
end

%%
hold off

subplot(1,3,1)
plot([0],[0],'*','Color',[0,0.4470,0.7410])
hold on
plot([0],[0],'*','Color',[0.6350,0.0780,0.1840])
plot([0],[0],'*','Color',[0.9290,0.6940,0.1250])


for i=1:height(Ts10)
plot(Ts10.OptimalHeight(i),Ts10.ForceBarHeight(i),'*','Color',colormat(i,:))
text(Ts10.OptimalHeight(i)+0.05,Ts10.ForceBarHeight(i),textmat{i})
plot(Ts10.OptimalHeight(i),Ts10.AvgHeight(i),'*','Color',[0.9290,0.6940,0.1250])
%plot(Ts10.OptimalHeight(i),Ts10.AvgHeight(i),'s','Color',colormat(i,:))
%if abs(Ts10.OptimalHeight(i)-Ts10.ForceBarHeight(i))>0.1
%    plot(Ts10.OptimalHeight(i),max(Ts10.StemHeightsX{i}),'*','Color',[0.9290,0.6940,0.1250])
%    plot(Ts10.OptimalHeight(i),min(Ts10.StemHeightsX{i}),'*','Color',[0.9290,0.6940,0.1250])
%end
end
axis([3.5,9,2,13])

title('SOCEM Forcebar Height vs Suggested Height, Wheat 2021')
xlabel('Suggested Height (inches)')
ylabel('Force Bar Height (inches)')

legend('Suggested Height ~ Force Bar Height','Suggested Height > Force Bar Height','Average Plot Height','Location','Northwest')

subplot(1,3,2)
plot([0],[0],'*','Color',[0,0.4470,0.7410])
hold on
plot([0],[0],'*','Color',[0.6350,0.0780,0.1840])
plot([0],[0],'*','Color',[0.9290,0.6940,0.1250])


for i=1:height(Ts10)
plot(Ts10.OptimalHeight(i),Ts10.ForceBarHeight(i),'*','Color',colormat(i,:))
text(Ts10.OptimalHeight(i)+0.05,Ts10.ForceBarHeight(i),textmat{i})
%plot(Ts10.OptimalHeight(i),Ts10.AvgHeight(i),'*','Color',[0.9290,0.6940,0.1250])
%plot(Ts10.OptimalHeight(i),Ts10.AvgHeight(i),'s','Color',colormat(i,:))
%if abs(Ts10.OptimalHeight(i)-Ts10.ForceBarHeight(i))>0.1
    plot(Ts10.OptimalHeight(i),max(Ts10.StemHeightsX{i}),'*','Color',[0.9290,0.6940,0.1250])
%    plot(Ts10.OptimalHeight(i),min(Ts10.StemHeightsX{i}),'*','Color',[0.9290,0.6940,0.1250])
%end
end
axis([3.5,9,2,13])

title('')
xlabel('Suggested Height (inches)')
ylabel('Force Bar Height (inches)')

legend('Suggested Height ~ Force Bar Height','Suggested Height > Force Bar Height','Max Plot Height','Location','Northwest')


subplot(1,3,3)
plot([0],[0],'*','Color',[0,0.4470,0.7410])
hold on
plot([0],[0],'*','Color',[0.6350,0.0780,0.1840])
plot([0],[0],'*','Color',[0.9290,0.6940,0.1250])


for i=1:height(Ts10)
plot(Ts10.OptimalHeight(i),Ts10.ForceBarHeight(i),'*','Color',colormat(i,:))
text(Ts10.OptimalHeight(i)+0.05,Ts10.ForceBarHeight(i),textmat{i})
%plot(Ts10.OptimalHeight(i),Ts10.AvgHeight(i),'*','Color',[0.9290,0.6940,0.1250])
%plot(Ts10.OptimalHeight(i),Ts10.AvgHeight(i),'s','Color',colormat(i,:))
%if abs(Ts10.OptimalHeight(i)-Ts10.ForceBarHeight(i))>0.1
%    plot(Ts10.OptimalHeight(i),max(Ts10.StemHeightsX{i}),'*','Color',[0.9290,0.6940,0.1250])
    plot(Ts10.OptimalHeight(i),min(Ts10.StemHeightsX{i}),'*','Color',[0.9290,0.6940,0.1250])
%end
end
axis([3.5,9,2,13])

title('')
xlabel('Suggested Height (inches)')
ylabel('Force Bar Height (inches)')

legend('Suggested Height ~ Force Bar Height','Suggested Height > Force Bar Height','Min Plot Height','Location','Northwest')


%% Plot kept values
close(gcf); 

Newtons2Pounds = 0.225;
mmsqr2insqr = 1/645;

x2list;
plot2list;
y2list=[];
for i=1:numel(plot2list)
    y2list(i)=mean(table2array(Ti(Ti.Plot==plot2list{i},find(Ti.Properties.VariableNames=="EI")))).*Newtons2Pounds.*mmsqr2insqr;    
end
[abc,a,b,c,rsq,rmse,sse,lm,f0,string1]=linearFitting(x2list,y2list,1,1,1);
ha1=annotation(gcf,'textbox',[0.13,.74,1,1],'String',string1,'EdgeColor','none','FitBoxToText','on','verticalalignment', 'bottom', 'color','k');
title(strcat('Socem EI vs Instron EI, Not including skewed height settings'))
xlabel('Socem EI, averaged (lbs*in^2)')
ylabel('Instron EI, averaged (lbs*in^2)')

%% Plot kept values sans HW

close(gcf)

x3list=x2list(not(contains(string(plot2list),"HW")));
plot3list=plot2list(not(contains(string(plot2list),"HW")));
y3list=y2list(not(contains(string(plot2list),"HW")));
variety3list=variety2list(not(contains(string(plot2list),"HW")));


[abc,a,b,c,rsq,rmse,sse,lm,f0,string1]=linearFitting(x3list,y3list,1,1,1);
ha1=annotation(gcf,'textbox',[0.13,.80,1,1],'String',string1,'EdgeColor','none','FitBoxToText','on','verticalalignment', 'bottom', 'color','k');
title(strcat('Socem EI vs Instron EI, Not including skewed height settings',string(newline),'nor HW Plots,'));%,string(newline),'Lowest 3 stems of Instron data excluded from each plot.'))
title(strcat('Socem EI vs Instron EI, Wheat 2021.',string(newline),'Sans 14 Improper Height Settings (7 HW, 7 SW, 0 CF). Sans 15 HW Plots. 26 of 48 Remaining Plots.'));%,string(newline),'Lowest 3 stems of Instron data excluded from each plot.'))


xlabel('Socem EIM (lbs*in^2)')
ylabel('Instron EI, averaged (lbs*in^2)')

for i=1:numel(plot3list)
   text(x3list(i)+0.15,y3list(i),strcat(plot3list{i},{', '},variety3list{i})) 
end
text()

%% Plot CF and SW
close(gcf); 

Newtons2Pounds = 0.225;
mmsqr2insqr = 1/645;

Ts10sansHW=Ts10(not(contains(Ts10.Plot,"HW")),:)

x4list=[Ts10sansHW.EIM]';
y4list=[];
for i=1:height(Ts10sansHW)
    y4list(i)=mean(table2array(Ti(Ti.Plot==Ts10sansHW.Plot{i},find(Ti.Properties.VariableNames=="EI")))).*Newtons2Pounds.*mmsqr2insqr;    
end
[abc,a,b,c,rsq,rmse,sse,lm,f0,string1]=linearFitting(x4list,y4list,1,1,1);
ha1=annotation(gcf,'textbox',[0.13,.74,1,1],'String',string1,'EdgeColor','none','FitBoxToText','on','verticalalignment', 'bottom', 'color','k');
title(strcat('Socem EI vs Instron EI, sans HW Plots'))
xlabel('Socem EI, averaged (lbs*in^2)')
ylabel('Instron EI, averaged (lbs*in^2)')
