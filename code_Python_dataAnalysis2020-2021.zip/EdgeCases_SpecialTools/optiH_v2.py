'''
Author: Austin Bebee, 2020
Title: OptiH.py
Updates in this version made by Clayton Bennett, February 2022

Updates:
- Return height data such that it can be stored in the output files from SOCEM tests.
Up until now this tool has served as only a fancy calculator.
- Automatically pass optimal height value to test input field, to save the trouble. Can be altered if a different choice is made.
- A visualization would be nice, to show the range of possibilites and the overlap. i.e. is 90% of 5 inches more than 70% of 7 inches?
'''
import numpy as np
import matplotlib.pyplot as plt

step = 0.5 # defines the step size for generating distance array (for l vs d plots)

# d = horizontal distance
# l = stem height at corresponding horizonal index
def optiH(d, l, step): 
    x = []
    y = []
    
    def X(d, step): # fills in between distacne array by increments (step size)
        #nonlocal x
        j = d[0] # start at first d
        x = []
        for i in range(len(d)-1):
            while j < d[i+1]:
                if abs(j - d[i+1]) <= step: # make sure to keep original d elements
                    j = d[i+1]
                x.append(j)
                j += step

        return x

    def line(d, x, l): # generates the linear line of the plots height (as function of x)
        y = []
        place = 0

        for i in range(len(d)-1):
            m = (l[i+1] - l[i]) / (d[i+1] - d[i]) # determine slope

            index = np.where(x == d[i]) # get index where x == d[i]
            index = index[0]

            v = x[index] # start v at x[index]
            b = l[i] - m*v # determine y-intercept

            while v < d[i+1]: # continue generating height line until next known data point
                pt = m*v + b 
                y.append(float(pt))

                index += 1
                v = x[index]

        return y

    def optiBar(y):
        minL = min(y)
        maxL = max(y)
        # initially set h at 0.7 l_min
        h = .7*minL
        hScore = np.empty((0, 4)) # stores [h, h/l, hScore, h/l variance]
        while h < .9*maxL: # loop until h = 0.9 * maxL
            ha = np.array(y.T)*0+h.T # array of h
            hl = np.array(ha.T)/y.T # array of h/l # ERROR
            hlAve = np.mean(hl.T) # mean h/l

            count = 0
            i = 0
            for v in hl:
                if v >= .7 and v <.9: # optimal h/l range
                    good.append(v) # record if in optimal range

                i += 1

            ratio =  len(good)/len(hl) # ratio to define how much time is spent in h/l. Best when ratio = 1
            var = np.var(good) # determien the variance of h/l within the optimal range (tie breaker method if multiple optimal h)

            hScore = np.append(hScore, [[h, hlAve, ratio, var]], axis=0) # continues the score of h values

            h += (1/16) # increment h by measurement resolution of force bar
            good.clear()
            #xg.clear()

        return hScore

    x = X(d, step) # generate plot distance array (x)
    x = np.array(x) 
    y = line(d, x, l) # generate plot height lines
    y.append(l[-1])  # add skipped final point to y
    
    good = []
    xg = []
    i = 0
    hIter = optiBar(y) # iterate through all possible h values
    hScores = hIter[:, 2] # column of h scores
    maxIndex = np.where(hScores == max(hScores)) # acquire the index w/ the max h score

    if np.size(maxIndex) > 1: # if multiple h/l options, select 1 with lowest variance
        minVar = min(hIter[maxIndex, 3][0]) # determine min variance
        minVarIndex = np.where(hIter[maxIndex, 3][0] == minVar)[0][0] # obtain index of h w/ min variance
        maxIndex = maxIndex[0][minVarIndex]

        optiScore = hIter[maxIndex][2] # optimal h score
        optiH = hIter[maxIndex][0] # optimal h value to set force bar to
        optiRat = hIter[maxIndex][1] # optimal h/l 
        optiVar = hIter[maxIndex][3] # optimal variance of h/l 

    else: # if only one h/l value
        optiScore = hIter[maxIndex][0][2]
        optiH = hIter[maxIndex][0][0]
        optiRat = hIter[maxIndex][0][1]
        optiVar = hIter[maxIndex][0][3]


    return ("%.4f" % optiH), ("%.2f" % optiRat), ("%.2f" % optiScore), optiVar



#d = [20, 40, 60, 80, 100, 120]
#l = [13, 11, 9, 11, 12, 14]
#h = optiH(d, l, step)
#print(" h ", h)
#d = [0, 20, 30, 40, 60, 80]
#l = [13, 11.25, 9, 11.75, 11.25, 15]
#h = optiH(d, l, step)
#print(" h ", h)
#h = optiH
#ha = np.array(y)*0+h # array of h
#hl = np.array(ha)/y # array of h/l

