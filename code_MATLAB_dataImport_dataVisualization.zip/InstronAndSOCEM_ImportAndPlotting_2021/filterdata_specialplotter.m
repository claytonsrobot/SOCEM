% filterdata.m
% Author: Clayton Bennett
% Purpose: View and/or separate out data by heuristic

%% version 3
% Create X and Y plottable values for two different groups. Can nest.
directory_processingCode = ('D:\Instron Wheat Testing 2021\MatlabCode\'); % not thoroughly modular, if the script location changes.
directory_saveGraphs = ('D:\Instron Wheat Testing 2021\SAVED_DATA_2021\graphs\'); %modular
cd(directory_saveGraphs) % To control where the graphs are saved.
cd(directory_processingCode)

% taking a shit on this code
    % T=SoB_2020;
    % T.Variety = T.Name;


for t=1:height(T)
    T.j(t) = str2num(extractAfter(T.Plot(t),'_'));
    T.Plot(t) = extractBefore(T.Plot(t),'_');
    T.Hour(t)=0;
end

varunits = {'','','','in','in','lbs','lb*in^2','lb*in^2','lb*in^2'...
    ,'lb*in^2','lb*in^2','lb*in^2','lb*in^2','lb*in^2','lb*in^2'...
    ,'sec','in','lbs','','',''};
T.Properties.VariableUnits = varunits;
% shit compete

string_table = 'T';
string_xdata = 'T.j';
%string_ydata = 'T.EIM';
string_ydata = 'T.EI_M';
%string_ydata = 'T.AreaUnderCurve';
xdata = eval(string_xdata);
ydata = eval(string_ydata);

string_titleBack = {', EI, SOCEM 2021'};% preceded by variety name
string_titleBack = {', EI, SOCEM 2020, Barley'};% preceded by variety name
string_exportfilenamedetail = {'_varietyEIM'};
string_xlabel = 'Run #';
ymax = max(ydata);
%ymax = 18;
mat_ax = [0.8,8.2,0,ymax];
%mat_ax = [0.8,4.2,0,ymax];

%% label maker
string_xdata = strcat(extractAfter(string_xdata,'.'));
string_ydata = strcat(extractAfter(string_ydata,'.')); %
%string_xlabel = string_xdata; % 
string_ylabel = string_ydata; % 
for column = 1:numel(eval(string_table).Properties.VariableNames)
    if string(eval(string_table).Properties.VariableNames(column)) == string_xlabel
       string_xlabel = string(strcat(string_xlabel,'_.(',eval(string_table).Properties.VariableUnits(column),')'));
    elseif string(eval(string_table).Properties.VariableNames(column)) == string_ylabel
       string_ylabel = string(strcat(string_ylabel,'_.(',eval(string_table).Properties.VariableUnits(column),')'));
    end
end
%% loop, to create cell array of table groups
table_initial = eval(string_table);
varieties = unique(table_initial.Variety);
for i = 1:(numel(varieties))
col1 = "Variety";
%keep1 = "LCS Artdeco";
keep1 = varieties(i);
%kic1 =  "LCS Artdeco";
heur1 = table_initial(keep1 == table_initial.(col1),:);


fic1 = "Plot"; % filtercolumn
groups1 = unique(heur1.(fic1));
ngroups1 = numel(groups1);
msg = sprintf('There were %d %s tested of the %s %s.',ngroups1,fic1,keep1,col1);
disp(msg)

msg = sprintf('%d %s: %s %s %s %s',numel(groups1),fic1,groups1{1:end});
disp(msg)

branch1 = {};
for b = 1:numel(groups1)
    branch1{b} =  heur1(heur1.(fic1)==groups1(b),:);
%     T(T.Plot=="SW116",:)
end

fic2 = "Hour";
groups2 = unique(heur1.(fic2)); % What are the different values for hours?
ngroups2 = numel(groups1);

msg = sprintf('%d %s: %d %d %d %d',numel(groups2),fic2,groups2(1:end));
disp(msg)

branch2 = {};
for b=1:numel(groups2)
    branch2{b} = heur1(heur1.(fic2)==groups2(b),:);
end

branch12 ={};
for b2=1:numel(groups2)
    for b1 = 1:numel(groups1)
        branch12{b1,b2} = heur1(logical([groups1(b1)==heur1.(fic1)].*[groups2(b2)==heur1.(fic2)]),:);
        msg = sprintf('%d tests had %s = %s and %s = %d',height(branch12{b1,b2}),fic1,groups1(b1),fic2,groups2(b2));
        %msg2 = sprintf('%d tests had %s = %s and %s = %d',height(branch12{b1,b2}),fic1,groups1(b1),fic2,groups2(b2));
        disp(msg)

    end
end

%% plot general
close(gcf)
legendstring = {};
for b2=1:numel(groups2)
    for b1 = 1:numel(groups1)
        if not(isempty(branch12{b1,b2}))
            plot(branch12{b1,b2}.j,branch12{b1,b2}.EI_M,'*-')
            hold on
            legendstring{end+1} = sprintf('%s %s, %s %d',fic1,groups1(b1),fic2,groups2(b2));
        end
    end
end

hleg = legend(legendstring);

%% plot, specific
close(gcf)
legendstring = {};
for b2=1:numel(groups2)
    for b1 = 1:numel(groups1)
        if not(isempty(branch12{b1,b2}))
            plot(branch12{b1,b2}.(string_xdata),branch12{b1,b2}.(string_ydata),'*-')
            hold on
            valueshow3 = mean(branch12{b1,b2}.forceBarHeight);
            valueshow4 = mean(branch12{b1,b2}.aveHeight);
            legendstring{end+1} = sprintf('%s %s, %s %d, fb %0.2g in, avgh %0.2g in',fic1,groups1(b1),fic2,groups2(b2),valueshow3,valueshow4);
        end
    end
end

hleg = legend(legendstring);
string_title = {strcat(keep1,string_titleBack)};
title(string_title)
xlabel(string_xlabel)
ylabel(string_ylabel)
axis(mat_ax)
xticks([1,2,3,4,5,6,7,8])

fig =  gcf;
filename_plot = strcat(string(keep1),string_exportfilenamedetail,'.png');
cd(directory_saveGraphs)
exportgraphics(fig, filename_plot,'Resolution',300)
            
hold off
end

cd(directory_processingCode)
%% OLD CRAP BELOW THIS LINE
%% Attempt one: Array of numbers only. Export to CSV(keep strings).
% Inherant issues: Shed useful data in order to use array parsing.
% form: tempa = data(data(:,1)==22,2); 
% vars = T.Properties.VariableNames;
% n = length(vars);
% h = height(T);
% columnNew = 1;
% A = ones(h,1);
% varsnew = {1};
% for column = 1:n
%     classOfColumn = class(T.(vars{column}));
%     if string(classOfColumn)~= string('string') && string(class(T.(vars{column})))~= string('cell')
%         A(:,columnNew) = T.(vars{column});
%         varsnew(columnNew) = vars(column);
%         columnNew = columnNew+1;
%     end
% end
% 
% TA = array2table(A);
% TA.Properties.VariableNames = varsnew;
% data = A;
% %writetable(TA,'TA.xlsx','filetype','spreadsheet')
%% Attempt two: Tables meeting criteria stored into a cell that contains all possible comparisons
% % col1 = "Variety";
% % keep1 = "LCS Artdeco";
% % heur1 = T(keep1 == T.(col1),:);
% 
% variety1 = "LCS Artdeco";
% heur1 = T(variety1 ==T.Variety,:);
% 
% 
% % fic1 = "Plot"; % filtercolumn
% % groups1 = unique(heur1.(fic1));
% % ngroups1 = numel(groups1);
% % sprintf('There were %d %s tested of the %s %s.',ngroups1,fic1,keep1,col1)
% 
% plots1 = unique(heur1.Plot);
% nfork1 = numel(plots1);
% sprintf('There were %d plots tested of the %s variety.',nfork1,variety1)
% branch1 = {};
% for b = 1:numel(plots1)
%     branch1{b} =  heur1(heur1.Plot==plots1(b),:);
% end
% 
% branch2 = {};
% fic2 = "Hour";
% groups2 = unique(heur1.(fic2));
% ngroups2 = numel(groups1);
% hours2 = unique(heur1.Hour);
% for b=1:numel(hours2)
%     branch2{b} = heur1(hours2(b)==heur1.Hour,:);
% end
% 
% % branch12 ={};
% % for b1=1:numel(hours2)
% %     for b2 = 
% %     branch12{b1,b2} = heur1(hours2(b)==heur1.Hour,:);
% %     end
% % end
% 
% %col = varsnew
% %tempa = data(data(:,3)==1,:); 
% 
% 
% 
% 
