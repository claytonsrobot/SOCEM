function [vectorA,vectorB,vectorC,vectorD,vectorE]=deleteDuplicates5in3judged(vectorA,vectorB,vectorC,vectorD,vectorE);

        vectors = {vectorA,vectorB,vectorC,vectorD,vectorE};
        
        for i=1:3
            active = vectors{i};
        [U, I] = unique(active, 'first');
        x = 1:length(active);
        x(I) = [];
        
        for j=1:5
        vectors{j}(x)=[];
        end
        end
        
        
%         [U, I] = unique(vectorB, 'first');
%         x = 1:length(vectorB);
%         x(I) = [];
%         vectorB(x)=[];
%         vectornewA(x)=[];
%         vectornewB=vectorB;
%         if not(numel(vector)==numel(unique(vector)))
%             display([numel(vector),numel(unique(vector))])
%             [vectornew]=deleteDuplicates(vectornew);
%         end
end
