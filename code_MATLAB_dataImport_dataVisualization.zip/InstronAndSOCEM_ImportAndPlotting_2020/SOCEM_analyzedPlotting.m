% SOCEM_ProcessDataPlotting
%% Plotting
    plot(S_metric.aveHeight,S_metric.EI_I,'b+')
    xlabel('SOCEM aveHeight, (mm)')
    ylabel('SOCEM EI I, (N*mm^2)')

    %%
    plot(S_metric.aveHeight,S_metric.aveForcePeak,'b+')
    xlabel('SOCEM Barley 2020 aveHeight, (mm)')
    ylabel('SOCEM Barley 2020 aveForcePeak, (N)')

    %%  moneyshot
    plot(S_metric.aveForcePeak,S_metric.EI_I,'b+')
    xlabel('SOCEM Barley 2020 aveForcePeak, (N)')
    ylabel('SOCEM Barley 2020 EI I, (N*mm^2)')
    %1:3 SBF111, 4:10 SBF406, 11:18 SBF215, 19:25 SBF 203, 26:31 SBF113, 32:39 SBF304)

    %% moneyshot2 
    idx=[1 3
        4 10
        11 18
        19 25
        26 31
        32 39]; %separates run indicies related to which plot
    colors = ['brkkbk'];%
    markers = ['od*^hs'];%
    labels=strings([6,1]); %6 is set as the height of idx, the current number of different plots at this time
    i=1; %should rangr from 1 to 6
    for j=1:39 % 39 is the current number of available runs
        hplot(i)=plot(S_metric.aveForcePeak(j),S_metric.StdEI_Is(j),[colors(i) markers(i)]);%'+','Color',cell2mat(colors(i)));
        
        if j == idx(i,1)
            labels(i)=eraseBetween(S_metric.Plot(j),strfind(S_metric.Plot(j),'_'),strlength(S_metric.Plot(j)));
        end
        
        if j >= idx(i,2)
            i=i+1;
        end
        hold on
    end
    xlabel('SOCEM Barley 2020 aveForcePeak (N)')
    ylabel('SOCEM Barley 2020 Std Dev EI_I, (N*mm^2)')
    hlegend = legend(hplot(1:end),labels(1:end));
    hold off

        %% moneyshot3
    clear plot
    
%     idx=[1 3
%         4 10
%         11 18
%         19 25
%         26 31
%         32 39]; %separates run indicies related to which plot
%          % discluded, SBF 111, too short

idx = [1 4
    5 9];
    ratio_value = 1:1:9;
    EI_value = 1:1:9;
    ratioList=zeros(6,8);
    EIList = zeros(6,8);
    colors = ['brkkbk'];%
    markers = ['od*^hs'];%
    labels=strings([2,1]); %6 is set as the height of idx, the current number of different plots at this time
    i=1; %should range from 1 to 6
    k=1; %subsequent test number
    for j=1:9 % 1:39, 39 is the current number of available runs
        ratio_value(j) =  S_metric.EI_I(j)/S_metric.EI_I(idx(i,1));
        EI_value(j) = S_metric.EI_I(j);
        EIList(i,k)=EI_value(j);
        
        
        %value(j) =  SoB_2020_metric.EI_I(j)/SoB_2020_metric.EI_I(idx(i,1));
        ratioList(i,k)=ratio_value(j);
        
        %value(j) =  SoB_2020_metric.areaUnderCurve(j);%/SoB_2020_metric.EI_I(idx(i,1));
        
        % X(isnan(X)) = [];
        
        %hplot(i)=plot(k,ratio_value(j),[colors(i) markers(i)]);
        %alternative plot:: hplot(i)=plot(k,SoB_2020_metric.EI_I(j),[colors(i) markers(i)]);%
        hplot(i)=plot(k,S_metric.EI_I(j),[colors(i) markers(i)]);%
        k=k+1;
        
        if j == idx(i,1)
            labels(i)=eraseBetween(S_metric.Plot(j),strfind(S_metric.Plot(j),'_'),strlength(S_metric.Plot(j)));
        end
        
        if j >= idx(i,2)
            i=i+1;
            k=1;
        end
        hold on
    end
    title('SOCEM Barley 2020, Force vs Distance')
    xlabel('Run number')
    ylabel('EI (N*mm^2)')
    axis([0,9,0,3*10^4])
    %ylabel('EI run / EI first ratio, (N*mm^2/N*mm^2)')
    %ylabel('areaUnderCurve, (N*mm)')
    hlegend = legend(hplot(1:end),labels(1:end));
    axis
    hold off
    
    %%
    plot(S_metric.spacing,S_metric.EI_I,'b+')
    xlabel('SOCEM Barley 2020 spacing, (mm)')
    ylabel('SOCEM Barley 2020 EI I, (N*mm^2)')

    %%
    plot(S_metric.EI_I,S_metric.AveEI_Is,'b+')
    xlabel('SOCEM EI I, (N*mm^2)')
    ylabel('SOCEM EI I avg, (N*mm^2)')
    %%
    plot(S_metric.EI_I,S_metric.StdEI_Is,'b+')
    xlabel('SOCEM Barley 2020 EI I, (N*mm^2)')
    ylabel('SOCEM Barley 2020 EI I Std Dev, (N*mm^2)')
    %%
    plot(S_metric.AveEI_Is,S_metric.StdEI_Is,'b+')
    xlabel('SOCEM Barley 2020 EI I Ave, (N*mm^2)')
    ylabel('SOCEM Barley 2020 EI I Std Dev, (N*mm^2)')
    %%
    plot(S_metric.spacing,S_metric.AveEI_Is,'b+')
    xlabel('SOCEM Barley 2020 spacing, (mm)')
    ylabel('SOCEM Barley 2020 EI I Ave, (N*mm^2)')
    
    %%
    

%% SPECIFIC TO 2020 BARLEY DATA ----- NOT THE TIME OR THE PLACE
% Plot SOCEM data over time/distance,
startIdx=32; %manually choose which elements of table to visulaize, to see only one crop plot at a time
stopIdx=39;
labels=strings([stopIdx-startIdx+1,1]);
i=1; %to cycle through the label list
for j=startIdx:stopIdx %1:3 SBF111, 4:10 SBF406, 11:18 SBF215, 19:25 SBF203, 26:31 SBF113, 32:39 SBF304)
plot(cell2mat(S_metric.Distance(j)),cell2mat(S_metric.ForcePerRow(j)),'-')
title('SOCEM Barley 2020, Force vs Distance')
xlabel('Distance (mm)')
ylabel('ForcePerRow, (N)')
hold on
labels(i)=S_metric.Plot(j);
i=i+1; %to cycle through the label list
end
annotation('textbox',[.2 .5 .3 .3],'String',strcat(S_metric.Name(startIdx),'....', S_metric.Plot(startIdx)),'FitBoxToText','on');
legend(labels)
hold off


%% BEYOND THIS: SPECIFIC TO EXISTING 2020 WHEAT DATA. CAN BE REPURPOSED FOR OTHER COMPARISONS.
%% For comparison to Austin's data (table S)
%load table S from file 'socemVsLodging_Wheat2020_metric_missingRemoved57.mat'
% remove rows in S not in So_metric
So_metric_austin=S; %create copy

list_j=[];
%identify which rows of S are represented in So_metric 
for i=1:n
    for j=1:height(S)
        if S_metric.Plot(i)==S.Plot(j)
            list_j=[list_j,j];
        end
    end
end

%sort list_j, of rows represented in both tables
list_j=sort(list_j);

list_inversej=1:height(S);

for j=1:height(S)
    if ismember(j,list_j)
        index = find(list_inversej==j);
        list_inversej(index) = [];
    end
end

So_metric_austin(list_inversej,:)=[]; %

%% throw away
% remove rows in So_metric not in So_metric_austin
So_metric2=S_metric;
list_j=[];
%identify which rows of S are represented in So_metric 
for i=1:height(So_metric_austin)
    for j=1:height(So_metric2)
        if So_metric_austin.Plot(i)==So_metric2.Plot(j)
            list_j=[list_j,j];
        end
    end
end

%sort list_j, of rows represented in both tables
list_j=sort(list_j);

list_inversej=1:height(So_metric2);

for j=1:height(So_metric2)
    if ismember(j,list_j)
        index = find(list_inversej==j);
        list_inversej(index) = [];
    end
end

So_metric2(list_inversej,:)=[]; %

%% Plotting comparison
plot(So_metric_austin.aveForcePeak,So_metric2.aveForcePeak,'b+')
ylabel('SOCEM Clayton aveForcePeak, (N)')
xlabel('SOCEM Austin aveForcePeak, (N)')
hold on
x = [min(So_metric_austin.aveForcePeak),max(So_metric_austin.aveForcePeak)];
y =(x);
plot(x,y)
hold off
%non-agreement: CF104, CF115

plot(So_metric_austin.EI_I,So_metric2.EI_I,'b+')
ylabel('SOCEM Clayton EI_I, (N)')
xlabel('SOCEM Austin EI_I, (N)')
hold on
x = [min(So_metric_austin.EI_I),max(So_metric_austin.EI_I)];
y =(x);
plot(x,y)
hold off
%non-agreement: CF104, CF115

plot(So_metric_austin.forceBarHeight,So_metric2.forceBarHeight,'b+')
ylabel('SOCEM Clayton forceBarHeight, (mm)')
xlabel('SOCEM Austin forceBarHeight, (mm)')
hold on
x = [min(So_metric_austin.forceBarHeight),max(So_metric_austin.forceBarHeight)];
y =(x);
plot(x,y)
hold off
%non agreement: CF409


plot(So_metric_austin.aveHeight,So_metric2.aveHeight,'b+')
ylabel('SOCEM Clayton aveHeight, (mm)')
xlabel('SOCEM Austin aveHeight, (mm)')
%show y=x line
hold on
x = [min(So_metric_austin.aveHeight),max(So_metric_austin.aveHeight)];
y =(x);
plot(x,y)
hold off
%indicates that CF104 and CF115 have a lack of agreement in aveHeight value
%CF104: Clayton's is 11.75 in, Austin's is 12.1201 inches
% the excel shet has 11.75 recorded, which is accurate from notebook
% numbers. Were did 12.12 come from..

%% Plotting of EI vs run number, manual
subplot(2,2,4)
plotName = 'HW218';
heightPercentage = '70';

%S_SW407 = S([1,2,3,4],:);
%S_HW218 = S([5,6,7,8],:);

%s = eval(strcat('S_',plotName));
s = S_HW218_EI;

directory_savePlot = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Patent\Visco Comparison 70 vs 90 percent\';
directory_processingCode = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Processing Code - Research Camp Echo\';
cd(directory_savePlot);

runList = 1:1:height(s);
ratioList = runList; %initialize
EIList = runList; %initialize

for j = 1:height(s)
    ratioList(j) = s.EI_I(j)/s.EI_I(1);
    EIList(j) = s.EI_I(j);
end

    plot(runList,ratioList,'-s','LineWidth',1.0)
    
    axis([1,4, 0.5,1])
    string_title=(strcat(plotName,'_.','Viscoelastic Curve, Bar Height:','_.',heightPercentage,'%'));
    title(string_title)
    %title('Strength per Cycle, Plot: SW407, Bar Height: 90%')
    %title('Strength per Cycle, Plot: HW218, Bar Height: 70%')
    
    xlabel('Run Number')
    ylabel('EI Ratio')
    ylabel('EI_r_u_n / EI_1     (N/mm^2 / N/mm^2)')
    ylabel('EI_r_u_n / EI_1     (lbs/in^2 / lbs/in^2)')
    xticks([1 2 3 4])
    yticks([0.5 0.6 0.7 0.8 0.9 1.0])
    yticklabels({'50%','60%','70%','80%','90%','100%'})
    title('Strength per Cycle, Plot: HW218, Bar Height: 70%')
    title('Strength per Cycle, Plot: SW407, Bar Height: 90%')
    fig = gcf;
    
    %legend('Run 1','Run 2', 'Run 3', 'Run 4')
    
    filenametext = strcat(plotName,'_',heightPercentage,'percent, EI ratio vs Run','.png');
    %exportgraphics(fig, filenametext,'Resolution',300)
    
    hold off

    cd(directory_processingCode);
    %% Plotting of HW218 EI vs run number, manual
subplot(2,2,3)
plotName = 'SW407';
heightPercentage = '90';

%S_SW407 = S([1,2,3,4],:);
%S_HW218 = S([5,6,7,8],:);

%s = eval(strcat('S_',plotName));
s = S_SW407_EI;

directory_savePlot = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Patent\Visco Comparison 70 vs 90 percent\';
directory_processingCode = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Processing Code - Research Camp Echo\';
cd(directory_savePlot);

runList = 1:1:height(s);
ratioList = runList; %initialize
EIList = runList; %initialize

for j = 1:height(s)
    ratioList(j) = s.EI_I(j)/s.EI_I(1);
    EIList(j) = s.EI_I(j);
end
    hold on
    % plot best fit line through points 3:end
    slope = (runList(2:4)).\(ratioList(2:4));
    slope1 = slope(2)-slope(3)
    yCalc = slope.*runList(2:4);
    plot(runList,ratioList,'-s','LineWidth',1.0)
    plot(runList,yCalc,'-')
    
    axis([1,4, 0.5,1])
    string_title=(strcat(plotName,'_.','Viscoelastic Curve, Bar Height:','_.',heightPercentage,'%'));
    title(string_title)
    title('Strength per Cycle, Plot: SW407, Bar Height: 90%')
    %title('Strength per Cycle, Plot: HW218, Bar Height: 70%')
    
    xlabel('Run Number')
    ylabel('EI Ratio')
    ylabel('EI_r_u_n / EI_1     (N/mm^2 / N/mm^2)')
    ylabel('EI_r_u_n / EI_1     (lbs/in^2 / lbs/in^2)')
    xticks([1 2 3 4])
    yticks([0.5 0.6 0.7 0.8 0.9 1.0])
    yticklabels({'50%','60%','70%','80%','90%','100%'})
    %title('Strength per Cycle, Plot: HW218, Bar Height: 70%')
    title('Strength per Cycle, Plot: SW407, Bar Height: 90%')
    fig = gcf;
    
    %legend('Run 1','Run 2', 'Run 3', 'Run 4')
    
    filenametext = strcat(plotName,'_',heightPercentage,'percent, EI ratio vs Run','.png');
    %exportgraphics(fig, filenametext,'Resolution',300)
    
    hold off

    cd(directory_processingCode);