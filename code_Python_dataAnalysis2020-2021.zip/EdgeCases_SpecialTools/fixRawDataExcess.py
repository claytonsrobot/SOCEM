'''
SOCEM Raw Data CSV Cleanup
Created: 10/23/2021
Last updated: 2/6/2022
Author: Clayton Bennett

Description:
    - Loops through folder containing clean SOCEM Excel data
    - User inputs additional info
    - User selects where to cut force dis. plot ends (eliminate edge effects)
    - User selects force peaks from cut plot
    - Calculations are performed (primiarily EI)
    - Exports data into Excel files

Input values last changed: 6/28/2021, by Clayton Bennett
'''

# needed libraries
import pandas as pd
from pandas import ExcelFile
from pandas import ExcelWriter
import numpy as np
from datetime import date
import os
import xlsxwriter

# MANUAL INPUTS, (automate to run in window?
# cresate target folders manually
folderUp = r'C:\Users\clayton\Google Drive\School\University of Idaho\AgMEQ\SOCEM\SAVE_DATA_2020'
folder = str(folderUp+'\dirtyRaw')
targetFolder = r'\cleanRaw'

# DEFINE FUNCTION
# Prepare and export clipped data.
def Excel(*args):
#def Excel Excel(time, dis, force, rows, fb, stems, sampDis)
    
    # Create Lists to provide labels
    timeL = ['Time (s)']
    disL = ['Distance (in.)']
    forceL = ['Force (lbs.)']
    heightL = ['Height(in.)']
    fbL = ['Fb Bottom Height (in.)']
    rowsL = ['Rows']
    stemsL = ['Ave Stem Count']
    sampDisL = ['Sample distance (in.)']


    #print('***************')
    
    # append all data into corresponding list
    timeL.extend(list(time))
    disL.extend(list(dis))
    forceL.extend(list(force))
    heightL.append(height)
    fbL.append(fb)
    rowsL.append(rows)
    stemsL.append(stems)
    sampDisL.append(sampDis)
    
    # identify export target
    saveAt = folderUp+targetFolder+ '\\'+ filename # address + filename
    workbook = xlsxwriter.Workbook(saveAt)
    worksheet = workbook.add_worksheet('Sheet1')

    worksheet.set_column('A:H', 12)
    
    # sheet 1: Raw Data
    worksheet.write_column('A1', timeL)
    worksheet.write_column('B1', disL)
    worksheet.write_column('C1', forceL)
    worksheet.write_column('D1', heightL)
    worksheet.write_column('E1', fbL)
    worksheet.write_column('F1', rowsL)
    worksheet.write_column('G1', stemsL)
    worksheet.write_column('H1', sampDisL)
    
    workbook.close()

    #print (filename)
    
# MAIN FUNCTION    
for filename in os.listdir(folder): # loop through files in folder

    file = str(folder+'/'+filename)
    print('\n' + 'NEXT!' + '\n' + filename)
    df = pd.read_excel(file) # convert Excel into pandas df

    time = np.array(df['Time (s)'])
    dis = np.array(df['Distance (in.)'])
    force = np.array(df['Force (lbs.)'])
    height = np.array(df['Height (in.)'])[0]
    fb = np.array(df['Fb Bottom Height (in.)'])[0]
    rows = np.array(df['Rows'])[0]
    stems = np.array(df['Ave Stem Count'])[0]
    sampDis = np.array(df['Sample Distance (in.)'])[0]

    o = len(time)

    # Remove first element from time, dis force
    if time[0]>time[1] or dis[0]>dis[1]:
        time = time[1:]
        dis = dis[1:]
        force = force[1:]
        print('First line removed')
        #del time[0]
        #del dis [0]
        #del force[0]

    i=0
    while True:
        i += 1
        if o == i+1 or o==i+2:
            break
        if isinstance(time[i+1], str):
            break
        if time[i+1]<time[i]:
            break
        
    print ('o = ',o,'\ni = ',i)

    if i < len(time):
        time = time[0:i]
        dis = dis[0:i]
        force = force[0:i]

    Excel(time, dis, force, rows, fb, stems, sampDis)
    
    # Make list of numbers comparing time(i+1)-time(i).
    # Find index of first negative drop in time, where another dataset has been appended in error.
    # Cut out all data after first negative number, for first three columns, time dis force.
    # For all other columns, store first values.
    # Write new file of same name, overwrite old file.


