'''
generateMap_blender.py
Author: Clayton Bennett
Created: 5/5/2022
Last edited: 9/27/2022
Version: V3

Description: Import, scale, and place objects with uniform scaling.
Add plot name text to plots.
Version description: Also show individual stem EI values.

How to use: Change file folder. For stems, change EI numbers, pasted from MATLAB table.

Changes:
Change import scale (0.0252) and change units to inches
Uniform scaling
'''

''' # To run in cmd, copy and paste:
cd C:\Program Files\Blender Foundation\Blender 3.1\
blender.exe --python "E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\CAD Drawings - Clayton\FieldMap\generateMap_blender.py"
blender.exe --background --python "E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\CAD Drawings - Clayton\FieldMap\generateMap_blender.py"
'''

'''
Dev:
# Operate from GUI, with inputs of directory, text string, and if stems should be generated or not.
# Add underline to color gradient numbers # low priority
# Add material for text color # secondary priority
# Covert individual stems from cubes to hollow cubes with no bottom, from an STL template # high priority
# import stem numbers, rather than having them pasted into this script
# Texture bake automatically # highest priority
# Export automatically # high priority
# change variable listing and location to be based on directory location and text pattern, rather than manually pasting lists from spreadsheet # high priority
# learn to group objects by name, to exclude certain objects: Group all SOCEM with a yardstick, and then all stems with a yardstick: If you do this, will they correlate?
# auto group bsed on plotheights spreadsheet, to reference variety names.
# Have a second script to copy and paste and finish the job of bakig and exporting, once window is changed.

'''

# filename --> import ---> scale
import sys
import os
import bpy
import math
import mathutils
import numpy as np

#sys.path.insert(0,'C:\Program Files\Blender Foundation\Blender 3.1\')
sys.path.insert(0,'E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\Code - Matlab, Python, etc\Code - Python - Data Processing, Computer')
import SortPlotSTLs
from SortPlotSTLs import plotcoordinates

inch = 0.0254
pathstring = 'E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\Code - Matlab, Python, etc\Code - Python - Data Processing, Computer'
sys.path.insert(0, pathstring)

# expected format: variety,plotname. Ex: Purl,SW429_50x50I.....stl
directory = 'E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\CAD Drawings - Clayton\FieldMap'
textIdentifier = "_50x50_EI_nearest_baseExperiment.stl"
textIdentifier = "_210x210_peaksUsed_noFloor.stl"

axis = "EI"
dimension = "(lb*in^2)"
axis = "Force"
dimension = "(lb)"
#textIdentifier = "_50x50_EI_nearest_sideHitExperiment.stl"
# example file: "E:\\Backups\\GoogleDrive_AgMEQ_03312022\\SOCEM\\CAD Drawings - Clayton\\FieldMap\\UI Magic CL+,CF245_50x50_EI_nearest_baseExperiment.stl",

# change unit shown to 'in', rather than just scaling 
bpy.context.scene.unit_settings.system = 'IMPERIAL'
bpy.context.scene.unit_settings.length_unit='INCHES'

scene = bpy.data.scenes["Scene"]

#bpy.data.objects['Cube'].select_set(True)
#bpy.ops.object.delete()
#filelist = textIdentifyFiles(textIdentifier, directory) # for modularity

#xcoord, ycoord, plotlist, varietylist = plotcoordinates(textIdentifier, directory)
[X, Y, plotnames, varietynames, filenamelist] = plotcoordinates(textIdentifier, directory)
print('X=',X)
print('Y=',Y)
filenames_long =[]
for filename in filenamelist:
    filenames_long.append(directory+'\\'+filename)
  
# stem EI's, in the order of plots, ten steams each plot, unit Lb*in^2
stems_EI = [
[4.3985,5.0419,	5.533,	6.3286,	6.352,	6.5079,	6.7777,	7.3641,	8.2311,	8.9165],
[4.8755,6.7695,	6.9183,	7.5315,	8.1287,	8.8279,	9.8995,	12.3587,16.2612,20.5403],
[5.8906,6.5101,	7.3269,	7.3619,	7.6685,	7.7005,	7.8776,	8.838,	9.5356,	11.2551],
[3.4642,3.6979,	6.1786,	6.3464,	6.5872,	6.71,	6.7475,	9.4962,	11.5494,12.6184],
[5.5021,5.6547,	5.6815,	6.899,	9.1044,	9.2301,	9.3202,	9.8497,	10.2571,14.9284],
[3.0895,3.4314,	4.0956,	6.7762,	7.139,	8.3665,	8.7825,	9.6982,	11.0288,13.1274],
[5.2614,6.563,	7.3124,	7.6979,	7.9468,	12.3944,12.4886,14.2512,14.5831,22.1258],
[4.083,	4.1518,	9.0843,	9.3991,	9.6882,	9.9092,	10.2727,12.3431,13.7987,15.1122],
[5.3686,6.8793,	7.2313,	8.2303,	8.2441,	9.3087,	9.4817,	9.5851,	9.8753,	10.4506],
[4.1466,4.4052,	5.0713,	5.9345,	6.6854,	8.163,	10.726,	12.0004,13.2852,17.91],
[4.5421,5.0121,	5.2971,	5.318,	6.6422,	7.2517,	8.6456,	8.6579,	9.5996,	11.4326],
[4.4048,5.8906,	6.4711,	7.8076,	7.8456,	8.3766,	9.702,	10.4793,12.2605,12.4164],
[1.9118,3.2149,	3.5989,	4.0376,	4.1708,	5.0437,	6.2076,	7.1044,	8.2121,	9.2726],
[3.7916,4.1258,	4.2061,	4.5165,	5.6019,	6.4566,	6.4975,	7.8125,	8.2251,	8.7308],
[1.5248,3.0869,	4.2296,	4.768,	4.9741,	5.216,	5.5799,	6.2713,	6.9336,	10.2326],
[4.3371,5.5955,	5.7228,	6.0082,	6.0979,	6.3252,	6.835,	6.8833,	6.9704,	9.4969],
[4.8208,5.9546,	5.9721,	7.8069,	12.0796,12.3386,15.6454,15.843,16.6247,17.0028],
[3.2945,3.8218,	3.9163,	5.8448,	7.9416,	8.5206,	9.5706,	13.389,	13.6569,14.0324],
[4.2199,4.2493,	4.928,	11.6714,11.6986,11.9107,13.0928,13.5762,13.7224,14.6292],
[2.5447,5.7526,	5.907,	7.6967,	7.7027,	8.1094,	9.7619,	10.0454,10.0588,11.7991],
[1.4329,7.8902,	8.1786,	8.7792,	9.4002,	9.4009,	9.8642,	12.4048,12.5354,14.131],
[3.9747,4.9779,	4.9823,	5.7399,	6.1909,	6.4603,	8.0688,	10.3498,10.7661,14.3717],
[2.4629,4.3092,	5.9442,	6.7297,	7.1777,	10.7118,13.2231,13.7354,18.3732,18.87],
[1.382,	4.3021,	4.3784,	5.6614,	6.1704,	6.9745,	7.5933,	8.2642,	10.8982,11.7496],
[2.6739,3.501,	3.9297,	4.5678,	4.6162,	5.6294,	6.7449,	8.3438,	8.4353,	8.7568],
[1.1911,2.3691,	3.4724,	3.5873,	6.1466,	6.9477,	7.539,	8.0119,	9.3273,	12.4554],
[5.242,	7.3492,	7.8225,	8.5295,	10.4372,11.4925,12.714,13.1252,13.1862,14.4145],
[3.565,	5.0006,	5.4757,	6.5753,	6.5823,	8.6802,	9.0359,	9.7321,	10.9968,11.0847],
[5.1148,5.7366,	6.4614,	7.4687,	9.1873,	9.7444,	12.2527,12.3379,14.2203,16.1674],
[2.5235,3.347,	3.4608,	5.3302,	8.4327,	8.7434,	9.0761,	9.453,	9.8303,	10.8368],
[1.4675,5.1423,	5.2692,	6.4484,	8.0502,	8.3416,	9.0772,	9.7094,	9.7935,	13.9371],
[1.9129,2.1053,	2.4153,	3.069,	3.7641,	4.3591,	5.6242,	5.6971,	11.3146,14.0007],
[3.5602,5.2112,	8.5529,	10.7821,12.4127,15.0493,15.2186, 15.4035,16.1641,16.3754],
[3.4311,4.1879,	5.6804,	6.6298,	8.0473,	8.058,	8.966,	10.7836,10.9362,13.4352],
[2.7754,3.1379,	4.8878,	4.9641,	6.1555,	6.4925,	6.9198,	8.3375,	9.2614,	10.8491],
[2.4015,4.1031,	4.4566,	4.49,	5.1598,	5.3529,	5.7187,	6.3881,	6.9481,	9.7317],
[2.2813,3.9416,	3.949,	4.7222,	4.931,	6.2891,	7.4151,	7.8378,	9.3782,	14.829],
[3.089,	3.4553,	4.7896,	8.2188,	10.5176,10.8246,11.6536,11.6938,12.9131,14.493],
[1.6912,3.36,	4.1202,	4.3487,	4.5779,	5.4192,	8.9116,	9.4675,	11.0259,13.5877],
[4.5235,4.8502,	4.8867,	5.8798,	6.8231,	7.9978,	8.211,	9.1278,	11.4277,15.9475],
[3.2007,5.1449,	6.3449,	6.6106,	7.738,	8.4644,	10.4487,10.765,12.7814,12.8897],
[2.6657,2.7271,	3.9066,	4.0487,	6.8435,	9.0296,	9.494,	11.3016,11.9237,12.4878],
[3.8311,4.5358,	7.4895,	7.5379,	7.5565,	8.6742,	8.9816,	9.6625,	11.9754,14.2936],
[2.6742,3.5542,	3.9356,	4.65,	4.9094,	5.5978,	5.9081,	10.2322,10.7271,12.5302]
]
'''
def print(data):
    for window in bpy.context.window_manager.windows:
        screen = window.screen
        for area in screen.areas:
            if area.type == 'CONSOLE':
                override = {'window': window, 'screen': screen, 'area': area}
                bpy.ops.console.scrollback_append(override, text=str(data), type="OUTPUT")
'''
                
def move(obj,i,inch):
    #print(objectname)
    #obj = bpy.data.objects[objectname]
    #obj.select_set(True)   ## set the object
    loc = obj.location
    (x,y,z) = (X[i], Y[i], 0)
    obj.location = loc + mathutils.Vector((x*inch,y*inch,z*inch))

    #return x,y,z
    
""" def color(filename):

    print(filename) """
    
## scale
def scale(obj,maxZ,C,inch):
    #for filename in filenames:
    # filename = "Stingray CL+,CF447_50x50_EI_nearest_baseExperiment"
    
    #print(objectname) 
    #objectToSelect = bpy.data.objects[objectname]
    #objectToSelect.select_set(True)   ## set the object
    #bpy.context.view_layer.objects.active = obj ## set the object as active in the 3D viewport
    obj.scale = (1*inch, 1*inch, 5*inch) ## change the scale!!
    #print(maxZ)
    #print(objZ)
    if objZ > maxZ:
        maxZ = objZ
        print("maxZ = ", maxZ)
    #print(objectname)
    #return objectToSelect
    return maxZ
    
def stems(i,inch):
    (x,y,z) = (X[i], Y[i], 0)

    # create ten stems the ten stems for plot i
    c=10
    j=0
    for EI in stems_EI[i]:
        #bpy.ops.mesh.primitive_cube_add
        bpy.ops.mesh.primitive_cube_add(size=2, calc_uvs=True, enter_editmode=False, align='WORLD', location=((x+30)*inch, (y+j*c+30)*inch, EI/2*inch), rotation=(0, 0, 0), scale=(1*inch, 1*inch, EI/2*inch))
        j+=1
      
def color(obj):

    #mat = bpy.data.materials.get('colorGradient')
    id = 'colorGradient'
    mat = bpy.data.materials.new(name=id)
    mat.use_nodes = True
    mat.node_tree.links.clear()
    mat.node_tree.nodes.clear()

    #mat = bpy.data.materials.new(name=id)
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    # nodes.items()
    # [('Map Range', bpy.data.materials['colorGradient'].node_tree.nodes["Map Range"]), ('ColorRamp', bpy.data.materials['colorGradient'].node_tree.nodes["ColorRamp"]), ('Gradient Texture', bpy.data.materials['colorGradient'].node_tree.nodes["Gradient Texture"]), ('Texture Coordinate', bpy.data.materials['colorGradient'].node_tree.nodes["Texture Coordinate"]), ('Mapping', bpy.data.materials['colorGradient'].node_tree.nodes["Mapping"]), ('Material Output', bpy.data.materials['colorGradient'].node_tree.nodes["Material Output"]), ('Image Texture', bpy.data.materials['colorGradient'].node_tree.nodes["Image Texture"]), ('Principled BSDF', bpy.data.materials['colorGradient'].node_tree.nodes["Principled BSDF"]), ('Diffuse BSDF', bpy.data.materials['colorGradient'].node_tree.nodes["Diffuse BSDF"])]


    materialoutput = nodes.new(type='ShaderNodeOutputMaterial')
    shader = nodes.new(type='ShaderNodeBsdfDiffuse')
    maprange = nodes.new(type='ShaderNodeMapRange')
    mapping = nodes.new(type='ShaderNodeMapping')
    colorramp = nodes.new(type='ShaderNodeValToRGB')
    gradienttexture = nodes.new(type='ShaderNodeTexGradient')
    texturecoordinates = nodes.new(type='ShaderNodeTexCoord')
    # will be used later:
    imagetexture_baked = nodes.new(type='ShaderNodeTexImage')
    shader_image = nodes.new(type='ShaderNodeBsdfPrincipled')
    shader_image = nodes["Principled BSDF"]


    ## Create useful names for things (not necessary, but here essentially as a heading)
    ## Then,change values
    # ---------------------------------------------------startsectiondave::
    materialoutput = nodes["Material Output"]
    materialoutput.target = 'ALL'

    shader = nodes["Diffuse BSDF"]
    shader.inputs[1].default_value=0.0 # roughness = 0

    mapping = nodes["Mapping"]
    mapping.vector_type = 'VECTOR'
    #mapping.inputs[1].default_value = Vector((0.0, 2.3164799213409424, 0.0))
    mapping.inputs[2].default_value = mathutils.Euler((0.0, 1.5707963705062866, 0.0), 'XYZ')
    #mapping.inputs[3].default_value = mathutils.Vector((0.0, 0.0, .125))
    mapping.inputs[3].default_value = mathutils.Vector((0.0, 0.0, 2.125))

    maprange = nodes["Map Range"]
    maprange.data_type = 'FLOAT_VECTOR'
    maprange.interpolation_type = 'STEPPED'
    maprange.clamp = True
    maprange.inputs[0].default_value = 1.0
    maprange.inputs[1].default_value = 0.0
    maprange.inputs[2].default_value = 1.0
    maprange.inputs[3].default_value = 0.0
    maprange.inputs[4].default_value = 1.0
    maprange.inputs[5].default_value = 4.0
    """ maprange.inputs[6].default_value = 
    maprange.inputs[7].default_value = 
    maprange.inputs[8].default_value = 
    maprange.inputs[9].default_value = 
    maprange.inputs[10].default_value = 
    maprange.inputs[11].default_value =  """

    colorramp = nodes["ColorRamp"]
    colorramp.color_ramp.color_mode = 'RGB'
    colorramp.color_ramp.hue_interpolation = 'NEAR'
    colorramp.color_ramp.interpolation = 'LINEAR'
    #colorramp.color_ramp.elements.new(position = 0.0)
    colorramp.color_ramp.elements[0].position = 0.0
    colorramp.color_ramp.elements[0].color = 0.196, 0.0, 0.592, 1.0
    #colorramp.color_ramp.elements.new(position = 0.2)
    colorramp.color_ramp.elements[1].position = 0.1
    colorramp.color_ramp.elements[1].color = 0.017, 0.017, 0.643, 1.0
    colorramp.color_ramp.elements.new(position = 0.2)
    colorramp.color_ramp.elements[2].color = 0.010681, 0.490, 0.694, 1.0
    colorramp.color_ramp.elements.new(position = 0.5)
    colorramp.color_ramp.elements[3].color = 0.035487, 0.796018, 0.05627, 1.0
    colorramp.color_ramp.elements.new(position = 0.8)
    colorramp.color_ramp.elements[4].color = 0.64303, 0.473186, 0.013768, 1.0
    colorramp.color_ramp.elements.new(position = 1.0)
    colorramp.color_ramp.elements[5].color = 1.0, 0.0, 0.03, 1.0

    gradienttexture = nodes['Gradient Texture']
    gradienttexture.gradient_type = 'LINEAR'

    texturecoordinate = nodes['Texture Coordinate']
    texturecoordinate.object = bpy.data.objects['joinedObjects']

    shader_image = nodes["Principled BSDF"]

    imagetexture_baked = nodes["Image Texture"]
    #--------------------------------------------------------------endsectiondave

    # link texture nodes
    links.new(shader.outputs[0], materialoutput.inputs[0])
    links.new(maprange.outputs[1], shader.inputs[0]) #error
    links.new(colorramp.outputs[0], maprange.inputs[6]) # error
    links.new(gradienttexture.outputs[0], colorramp.inputs[0])
    links.new(mapping.outputs[0], gradienttexture.inputs[0])
    links.new(texturecoordinates.outputs[3], mapping.inputs[0])
    links.new(shader.outputs[0], materialoutput.inputs[0])
    links.new(imagetexture_baked.outputs[0],shader_image.inputs[0])
    
    # control location of texture nodes in the shader editor GUI so that they are easy to read
    texturecoordinate.location = mathutils.Vector((0.0,0.0))
    mapping.location = mathutils.Vector((250.0,0.0))
    gradienttexture.location = mathutils.Vector((500.0,0.0))
    colorramp.location = mathutils.Vector((725.0,0.0))
    maprange.location = mathutils.Vector((1000.0,0.0))
    shader.location = mathutils.Vector((1250.0,0.0))
    shader_image.location = mathutils.Vector((1250.0,-200.0))
    materialoutput.location = mathutils.Vector((1600.0,0.0))
    imagetexture_baked.location = mathutils.Vector((750.0,-250.0))

    bpy.data.objects['joinedObjects'].data.materials[0]=bpy.data.materials['colorGradient']

    


    return mat

def deselectall():
    for obj in bpy.context.selected_objects:
        obj.select_set(False)

def bake(mat):
    print("bake mat")
    # remind vars:
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    shader_image = nodes["Principled BSDF"]
    imagetexture_baked = nodes["Image Texture"]
    materialoutput = nodes["Material Output"]
    # change render engine to cycles
    bpy.data.scenes["Scene"].render.engine = 'CYCLES'
    # default: bpy.data.scenes["Scene"].render.engine = 'BLENDER_EEVEE'
    bpy.ops.image.new(name="bake_joined", width=4096, height=4096, color=(0, 0, 0, 1), alpha=False, generated_type='BLANK', float=False, use_stereo_3d=False, tiled=False)

    #imagetexture_baked = mat.node_tree.nodes["Image Texture"] #remind it
    imagetexture_baked.image = bpy.data.images['bake_joined']

    #create mesh
    # go to UV editor
    # select object (all), or joined object
    # press U
    deselectall()
    #bpy.context.workspace = bpy.data.workspaces['UV Editing']
    bpy.context.window.workspace = bpy.data.workspaces['UV Editing']
    bpy.ops.object.mode_set(mode='EDIT')
    #if bpy.context.workspace == bpy.data.workspaces['UV Editing']:
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.uv.smart_project(angle_limit=1.15192, island_margin=0.06, area_weight=0, correct_aspect=True, scale_to_bounds=False) # failing
    bpy.ops.image.save
    #else:
    #    print("Failed to active UV Editing window")


    #bake
    bpy.context.window.workspace = bpy.data.workspaces['Shading']
    bpy.data.screens['Shading']
    deselectall()
    imagetexture_baked.select=True # select UV map node in shader
    bpy.context.view_layer.objects.active = bpy.data.objects['joinedObjects']
    bpy.data.objects['joinedObjects'].select_set(True)
    #bpy.ops.node.select(imagetexture_baked)

    
    scene.cycles.bake_type = 'DIFFUSE'
    bpy.context.scene.render.bake.use_pass_direct = False
    bpy.context.scene.render.bake.use_pass_indirect = False
    bpy.context.scene.render.bake.use_pass_color = True
    bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES'

    #bpy.data.images['bake_joined'].select_set(True)

    #bpy.data.screens["Shading"].areas.items()
    #bpy.context.area.spaces.active

    bpy.ops.object.bake(type='DIFFUSE') # this line does literally nothing. sad.
    '''
    bpy.ops.object.bake(type='DIFFUSE', pass_filter=set(),
    filepath="", width=512, height=512, margin=16,
    margin_type='EXTEND', use_selected_to_active=False, max_ray_distance=0,
    cage_extrusion=0, cage_object="", normal_space='TANGENT',
    normal_r='POS_X', normal_g='POS_Y', normal_b='POS_Z', target='IMAGE_TEXTURES',
    save_mode='INTERNAL', use_clear=False, use_cage=False, use_split_materials=False, use_automatic_name=False, uv_layer="")
    '''
    bpy.ops.file.pack_all()

    '''
    links.new(shader_image.outputs[0], materialoutput.inputs[0])
    '''
    
    # This is broken. I'm giving up on complete automation. CB 6/10/2022.
    #bpy.context.scene.render.engine = 'BLENDER_EEVEE'
    #bpy.context.area.ui_type = 'VIEW_3D'
    #bpy.context.space_data.shading.type = 'MATERIAL'
    # error: AttributeError: 'NoneType' object has no attribute 'ui_type'

    #bpy.context.view_layer.objects.active

    # detached gradient and single stems from joined STL objects. This is possible because the tallest STL object is the same height as the scale reference cube, and maxZ is a saved variable 
    
def plottext(i,inch,usednames):
    font_curve = bpy.data.curves.new(type="FONT", name="Font Curve")
    font_curve.body = plotnames[i]

    (x,y,z) = (X[i], Y[i], 0)
    #font_obj = bpy.data.objects.new(name="Font Object", object_data=font_curve)
    font_obj = bpy.data.objects.new(name=plotnames[i], object_data=font_curve)
    loc = font_obj.location
    font_obj.location = loc + mathutils.Vector((x*inch,y*inch-0*inch,z*inch))
    #print(x)
    scale_plottext = 0.33
    font_obj.scale = mathutils.Vector((scale_plottext, scale_plottext, scale_plottext))
    bpy.context.scene.collection.objects.link(font_obj)

    scale_varietytext = 0.4

    if i==0:
        font_curve = bpy.data.curves.new(type="FONT", name="Font Curve")
        font_curve.body = varietynames[i]
        usednames.append(varietynames[i])
        (x,y,z) = (X[i], Y[i], 0)
        font_obj = bpy.data.objects.new(name=varietynames[i], object_data=font_curve)
        loc = font_obj.location
        font_obj.location = loc + mathutils.Vector((x*inch,y*inch-19*inch,z*inch))
        font_obj.scale = mathutils.Vector((scale_varietytext,scale_varietytext,scale_varietytext))
        bpy.context.scene.collection.objects.link(font_obj)
        
    elif varietynames[i]!=varietynames[i-1] and not(usednames.__contains__(varietynames[i])):
        usednames.append(varietynames[i])
        font_curve = bpy.data.curves.new(type="FONT", name="Font Curve")
        font_curve.body = varietynames[i]
        (x,y,z) = (X[i], Y[i], 0)
        font_obj = bpy.data.objects.new(name=varietynames[i], object_data=font_curve)
        loc = font_obj.location
        font_obj.location = loc + mathutils.Vector((x*inch,y*inch-19*inch,z*inch))
        font_obj.scale = mathutils.Vector((scale_varietytext, scale_varietytext, scale_varietytext))
        bpy.context.scene.collection.objects.link(font_obj)

    return usednames   
    

def scaletext(i,inch):
    font_curve = bpy.data.curves.new(type="FONT", name="Font Curve")
    font_curve.body = str(i)

    (x,y,z) = (-5, 0, i)
    #font_obj = bpy.data.objects.new(name="Font Object", object_data=font_curve)
    font_obj = bpy.data.objects.new(name=("scale"+str(i)), object_data=font_curve)
    loc = font_obj.location
    font_obj.location = loc + mathutils.Vector((x*inch,y*inch-0*inch,z*inch))
    font_obj.rotation_euler = mathutils.Euler((3.141592/2,0,0))
    font_obj.scale = mathutils.Vector((0.1, 0.1, 0.1))
    bpy.context.scene.collection.objects.link(font_obj)
    font_curve.extrude = 1.3


def scaletitle(axis,dimension,inch):
    font_curve = bpy.data.curves.new(type="FONT", name="Font Curve")
    font_curve.body = (axis+" "+dimension)

    (x,y,z) = (-10, 0, 0)
    #font_obj = bpy.data.objects.new(name="Font Object", object_data=font_curve)
    font_obj = bpy.data.objects.new(name=("scale"+str(i)), object_data=font_curve)
    loc = font_obj.location
    font_obj.location = loc + mathutils.Vector((x*inch,y*inch-0*inch,z*inch))
    font_obj.rotation_euler = mathutils.Euler((3.141592/2,-3.141592/2,0))
    font_obj.scale = mathutils.Vector((0.2, 0.2, 0.2))
    bpy.context.scene.collection.objects.link(font_obj)
    font_curve.extrude = 0.2
    
## Main script
i=0
#maxZ = DoubleVar()
#maxZ.set(0)
#global maxZ
maxZ = float(0.01)
objectnames = []
for filename in filenames_long:
    
    bpy.ops.import_mesh.stl(filepath=filename) ##import

    objectname = os.path.split(filename)
    objectname = objectname[-1]
    len_objectname = len(objectname)
    objectname = objectname[:len_objectname - 4] 
    obj = bpy.data.objects[objectname]
    objectnames.append(objectname)
    obj.select_set(True)   ## set the object
    
    objZ = bpy.context.object.dimensions.z*5
    maxZ = scale(obj,maxZ,objZ,inch)
    
    move(obj,i,inch)
    # stems(i,inch)

    i+=1

obj = bpy.data.objects['Cube']
obj.select_set(True)
offset = 0
obj.scale = [4*inch, 4*inch, (maxZ/2+offset)*inch] #scale to improve color gradient, drop below z=0 plane
obj.location = mathutils.Vector((-20*inch,0,(maxZ/2-offset)*inch)) # was (-4, 0, etc)

for obj in bpy.data.collections['Collection'].all_objects:
    obj.select_set(True)

#bpy.data.objects['Cube'].select_set(False)
bpy.ops.object.join()
bpy.context.object.name = "joinedObjects"

# Shading
mat = color(bpy.context.object) #

# Bake mesh to texture
bake(mat)

# Names
i=0  
# objectname = "fonts"
# obj = bpy.data.objects[objectname]
# obj.select_set(True)   ## set the object

usednames = []
for objectname in objectnames:
    usednames = plottext(i,inch,usednames)
    i+=1
print("usednames = ")
print(usednames)

# Add title and reference number to color gradient and to distance traveled
#axis = "EI"
#dimension = "(lb*in^2)"
scaletitle(axis,dimension,inch)
scaleref_doubledigits = [10,20,30,40,50,60,70,80,90]
scaleref_singledigits = [1,2,3,4,5,6,7,8,9,10]
if maxZ >= 10:
    scaleref = scaleref_doubledigits
elif maxZ < 10:
    scaleref = scaleref_singledigits
i=0
while scaleref[i] < maxZ:
    scaletext(scaleref[i],inch)
    i+=1
scaletext(round(maxZ,2),inch)

