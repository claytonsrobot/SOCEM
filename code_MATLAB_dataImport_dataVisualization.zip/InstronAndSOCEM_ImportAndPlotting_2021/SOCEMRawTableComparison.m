%% Comparison 1 - Visco Cycled Cell 6

for j=1:4
    plot(cell2mat(S_east_cell6.Distance(j)),cell2mat(S_east_cell6.Force(j)))
    hold on
end
title('Cross Examination, Cell 6, East, Cycled')
xlabel('Distance (inches)')
ylabel('Force (pounds)')
fig = gcf;

string_title = 'Cell6CycledVisco';
filenametext = strcat(erase(string_title,'.'),'.png');
exportgraphics(fig, filenametext,'Resolution',300)
hold off

%% Comparison 2 - North (Cell 7, 8) compared to South (Cell 5)
S_northCell78_southCell5;
for j=1:3
    plot(cell2mat(S_northCell78_southCell5.Distance(j)),cell2mat(S_northCell78_southCell5.Force(j)))

    string_title=erase(strcat('Distance_.vs_.Force',strrep(S_northCell78_southCell5.File(j),'_','_.')),'.xlsx');
    title(string_title)
    
    xlabel('Distance (inches)')
    ylabel('Force (lbs)')
    fig = gcf;
    
    filenametext = strcat(erase(string_title,'.'),'.png');
    %exportgraphics(fig, filenametext,'Resolution',300)
    hold off
        pause(5)
%plot3
end
%% Comparison 2 - 3D for Comparable Cross Examination Cells

% East and South: Cell 10 vs Cell 3 ~~~~~ i=1 vs i=4
% East and South: Cell 1 vs Cell 3 ~~~~~ i=2 vs i=4
% East and South: Cell 2 vs Cell 3 ~~~~~ i=3 vs i=4
% East and South: Cell 9 vs Cell 3 ~~~~~ i=6 vs i=4

% East and South: Cell 10 vs Cell 4 ~~~~~ i=1 vs i=5
% East and South: Cell 1 vs Cell 4 ~~~~~ i=2 vs i=5
% East and South: Cell 2 vs Cell 4 ~~~~~ i=3 vs i=5
% East and South: Cell 9 vs Cell 4 ~~~~~ i=6 vs i=5

% indexes:
% Cell 10: i=1
% Cell 1: i=2
% Cell 2: i=3
% Cell 3: i=4
% Cell 4: i=5
% Cell 9: i=6

% Distance arrays are X and Y. Z needs to be the two force arrays
% multiplied together; 

%S_current = S_southCell34_eastCell12910_higher;
% from folder:
% directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\SAVED_DATA_2021\Research Camp Echo Day 2\Homogenous Stretch Cross Examination\Ruler9,875_MeasuredGreaterThan8,1\';

S_current = S_countDensityCorrelation;
% from folder:
% directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\SAVED_DATA_2021\August23\cellularDensity\';

% % 3D attempt!!
% East and South: Cell 10 vs Cell 3 ~~~~~ i=1 vs i=4
% indexMatrix = [1 4; %S_current = S_southCell34_eastCell12910_higher;
%     2 4;
%     3 4;
%     6 4;
%     1 5;
%     2 5;
%     3 5;
%     6 5];

indexMatrix = [5 1; %S_current = S_countDensityCorrelation;
    5 2;
    5 3;
    5 4;
    6 4;
    7 4];


for j=1:length(indexMatrix)
                
    index1 = indexMatrix(j,1); %east
    index2 = indexMatrix(j,2); %south

    %index1 = 1;%east
    %index2 = 4;%south
    
    X1 = cell2mat(S_current.Distance(index1));
    Y1 = cell2mat(S_current.Force(index1));
    X2 = cell2mat(S_current.Distance(index2));
    Y2 = cell2mat(S_current.Force(index2));


            if length(Y1) < length(Y2)
                Yshorter = Y1;
                Ylonger =  Y2;
                Xshorter = X1;
                Xlonger =  X2;    
            elseif length(Y1) > length(Y2)
                Yshorter = Y2;
                Ylonger =  Y1;
                Xshorter = X2;
                Xlonger =  X1;
            end
            Yshorter_length = length(Yshorter);
            Ylonger_length = length(Ylonger);
            lengthDifference = Ylonger_length-Yshorter_length;
            Ylonger_clipped = Ylonger((lengthDifference/2):(end-lengthDifference/2-1));
            Xlonger_clipped = Xlonger((lengthDifference/2):(end-lengthDifference/2-1));
            %Z = Yshorter.*Ylonger_clipped; % results in a single-column vector =  times(Yshorter,Ylonger_clipped)
            Z1 = mtimes(Ylonger_clipped, Yshorter'); % Correct!
            %Z2 = mtimes(Yshorter,Ylonger_clipped'); %Not correct!
            
            % filtering
            %threadsholdForce=20; %lbs^2
            %matZ1=Z1>threadsholdForce;
            %z1 = matZ1.*Z1;
            
            %make a list of all nonzero values, and use this to find
            %standard deviation and average
            %includedZ1=append(includedZ1);


    
    mesh(Xshorter,Xlonger_clipped,Z1); % 'Z must be a matrix, not a scalar or vector.'
    %mesh(Xshorter,Xlonger_clipped,Z2); % 
    
    string1 = str2mat(S_current.File(index1));
    string2 = str2mat(S_current.File(index2));

    string_cellindex1 = strfind(string1,'cell');
    string_cellindex2 = strfind(string2,'cell');
    string_hyphenindex1 = strfind(string1,'_');
    string_hyphenindex2 = strfind(string2,'_');
    
    string_cellnum1 = string1(string_cellindex1+4:string_hyphenindex1(2)-1);
    string_cellnum2 = string2(string_cellindex2+4:string_hyphenindex2(2)-1);
    
    
    string_title=strcat('Mesh_.Cell ',string_cellnum1,'East_.vs_.Cell ',string_cellnum2,'South');
    
    string_cellname1 = extractBetween(S_current.File(index1),'forceBar8,1_','.xlsx');
    string_cellname2 = extractBetween(S_current.File(index2),'forceBar8,1_','.xlsx');
    
    string_title = strcat('SW431_.countDensityCorr_.Aug23_.',string_cellname1,'_.vs_.',string_cellname2);
    
    hold on
    title(string_title)
    xlabel('Distance South (inches)')
    ylabel('Distance East (inches)')
    zlabel('Force, squared (lbs^2)')
    fig = gcf;
    filenametext = strcat(erase(string_title,'.'),'.png');
    exportgraphics(fig, filenametext,'Resolution',300)
    hold off
end
%% Filtered Mesh Plotting
indexMatrix = [5 3]; %S_current = S_countDensityCorrelation;
%     5 2;
%     5 3;
%     5 4;
%     6 4;
%     7 4];

for j=1:length(indexMatrix)
                
    index1 = indexMatrix(j,1); %east
    index2 = indexMatrix(j,2); %south

    %index1 = 1;%east
    %index2 = 4;%south
    
    X1 = cell2mat(S_current.Distance(index1));
    Y1 = cell2mat(S_current.Force(index1));
    X2 = cell2mat(S_current.Distance(index2));
    Y2 = cell2mat(S_current.Force(index2));


            if length(Y1) < length(Y2)
                Yshorter = Y1;
                Ylonger =  Y2;
                Xshorter = X1;
                Xlonger =  X2;    
            elseif length(Y1) > length(Y2)
                Yshorter = Y2;
                Ylonger =  Y1;
                Xshorter = X2;
                Xlonger =  X1;
            end
            Yshorter_length = length(Yshorter);
            Ylonger_length = length(Ylonger);
            lengthDifference = Ylonger_length-Yshorter_length;
            Ylonger_clipped = Ylonger((lengthDifference/2):(end-lengthDifference/2-1));
            Xlonger_clipped = Xlonger((lengthDifference/2):(end-lengthDifference/2-1));
            %Z = Yshorter.*Ylonger_clipped; % results in a single-column vector =  times(Yshorter,Ylonger_clipped)
            
            if length(Y1) < length(Y2)
                X1 = Xshorter;
                X2 = Xlonger_clipped;
                Y1 = Yshorter; % not necessary, already true
                Y2 = Ylonger_clipped;
            elseif length(Y1) > length(Y2)
                X2 = Xshorter;
                X1 = Xlonger_clipped;
                Y2 = Yshorter; % not necessary, already true
                Y1 = Ylonger_clipped;
            end
            
            %Z1 = mtimes(Ylonger_clipped, Yshorter'); % Correct!
            Z1 = mtimes(Y1,Y2');
            %Z2 = mtimes(Yshorter,Ylonger_clipped'); %Not correct!
            
            % filtering
            thresholdForce=9.5; %lbs^2
            matZ1=Z1>thresholdForce;
            z1 = matZ1.*Z1;
            
            %make a list of all nonzero values, and use this to find
            %standard deviation and average
            z1nums = [];
            for irow = 1:length(z1)
                for icolumn = 1:length(z1)
                    if z1(irow,icolumn)<thresholdForce
                        z1(irow,icolumn)=0;
                    else
                        z1nums(end+1)=z1(irow,icolumn);
                    end
                end
            end

            averageZ1 = mean(z1nums);
            stdevZ1 = std(z1nums);
            quantilesZ1 = quantile(z1nums,[.025 .25 .50 .75 .975]);

        
            



    
    %handle_mesh=mesh(Xshorter,Xlonger_clipped,z1); % 'Z must be a matrix, not a scalar or vector.'
    %handle_mesh=mesh(X1,X2,z1); % 'Z must be a matrix, not a scalar or vector.'
    handle_mesh=mesh(X2,X1,z1); % 'Z must be a matrix, not a scalar or vector.'
    xMax=max(handle_mesh.Parent.XLim);
    yMax=max(handle_mesh.Parent.YLim);
    %mesh(Xshorter,Xlonger_clipped,Z2); % 
    hold on 
    %plot3(Xshorter,yMax.*ones(length(Xshorter),1),averageZ1.*ones(length(Xshorter),1))
    plot3([0,xMax],[yMax,yMax],[averageZ1,averageZ1])
    for j=1:length(quantilesZ1)
        plot3([xMax, xMax],[0,yMax],quantilesZ1(j).*[1,1])
    end
    
    string1 = str2mat(S_current.File(index1));
    string2 = str2mat(S_current.File(index2));

    string_cellindex1 = strfind(string1,'cell');
    string_cellindex2 = strfind(string2,'cell');
    string_hyphenindex1 = strfind(string1,'_');
    string_hyphenindex2 = strfind(string2,'_');
    
    %string_cellnum1 = string1(string_cellindex1+4:string_hyphenindex1(2)-1);
    %string_cellnum2 = string2(string_cellindex2+4:string_hyphenindex2(2)-1);
    
    
    %string_title=strcat('Mesh_.Cell ',string_cellnum1,'East_.vs_.Cell ',string_cellnum2,'South, Filtered above',string(thresholdForce),'lb^2');
    
    string_cellname1 = extractBetween(S_current.File(index1),'forceBar8,1_','.xlsx');
    string_cellname2 = extractBetween(S_current.File(index2),'forceBar8,1_','.xlsx');
    
    string_title = strcat('SW431_.countDensityCorr_.Aug23_.',string_cellname1,'_.vs_.',string_cellname2);
    string_text = strcat('Average: ',string(averageZ1),'lbs^2, Stdev: ',string(stdevZ1)); 
    
    hold on
    title(string_title)
    xlabel('Distance South (inches)')
    ylabel('Distance East (inches)')
    zlabel('Force, squared (lbs^2)')
    text(max(Xshorter),max(Xlonger_clipped), max(max(z1)),string_text);
    fig = gcf;
    filenametext = strcat(erase(string_title,'.'),'.png');
    exportgraphics(fig, filenametext,'Resolution',300)
    hold off
end
%%

%plot3
















