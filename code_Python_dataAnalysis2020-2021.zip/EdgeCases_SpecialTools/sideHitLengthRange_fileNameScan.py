'''
Title: sideHitLengthRange
Author: Clayton Bennett (version 1)
Last edited: 02/14/2022, by Clayton Bennett (version 1)


Purpose: For side hits, find the horizontal measurements take to the position of the left and right ends of the force bar.

Details:
    Default to numRangeStart = 30, numRangeEnd = 60, if no typical text indicators are found in the filename.
        - Designed for data from August 2021, Genesee, Baldus Road,
        - This only applied to August 23rd data,
            and the naming convention used therein.

    Import into SOCEM_Data_Analysis.py.
    The returned values {numRangeStartSideHit, numRangeEndSideHit, heightsSideHit} will be used to alter
        how the {heights} variable is used, changing the {heights} values
        apply to the EI calculation.
        Only one average height value will result.

    Import into SOCEM_Data_Analysis.py.
    The returned value {direction} will be used to alter
    how the {heights} variable is used, changing the {heights} values
        apply to the EI calculation.

    This tool was designed as an adaptation of the functionality
        of the SOCEM_Data_Analysis.py script, originally authored by
        Austin Bebee in 2020.

2/15/2022
'''

## this only applied to August 23rd data
def sideHitLengthRange(filename, heights):
    idx_inTo = filename.find('inTo')
    feel = idx_inTo-3
    feelLeft = idx_inTo-4
    feelRight = idx_inTo-2
    feelRightRight = idx_inTo-1
    char = filename[feel]
    charLeft = filename[feelLeft]
    charRight = filename[feelRight]
    charRightRight = filename[feelRightRight]
    if char == '_' and charRight.isnumeric():
        idx_start = feel+1 # double digit number
    elif char.isnumeric() and charLeft == '_':
        idx_start = feel # triple digit number
    elif charRight == '_' and charRightRight == '0':
        idx_start = feel+2 # 0, single digit number

    stringRangeStartSideHit = filename[idx_start : idx_inTo]
    numRangeStartSideHit = int(stringRangeStartSideHit)

    print(numRangeStartSideHit)

    ##
    idx_indot = filename.find('in.')
    feel = idx_indot-3
    feelLeft = idx_indot-4
    feelRight = idx_indot-2
    char = filename[feel]
    charLeft = filename[feelLeft]
    charRight = filename[feelRight]
    if char == 'o' and charRight.isnumeric():
        idx_end = feel+1 # double digit number
    elif char.isnumeric() and charLeft == 'o':
        idx_end = feel # triple digit number

    stringRangeEndSideHit = filename[idx_end : idx_indot]
    numRangeEnd = int(stringRangeEndSideHit)
    print(numRangeEndSideHit)

    # return numRangeStartSideHit, numRangeEndSideHit; # WORK ON TNIS CB
    return heightsSideHit; # WORK ON TNIS CB
