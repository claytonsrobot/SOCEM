'''
scaleBlender.py
Author: Clayton Bennett
Created: 5/5/2022

Description: Utility for feeeding in filename and rescaling to object
'''
import os
import bpy

import sys

class CallableModule():

    def __init__(self, wrapped):

        self._wrapped = wrapped

    def __call__(self, *args, **kwargs):

        return self._wrapped.main(*args, **kwargs)

    def __getattr__(self, attr):

        return object.__getattribute__(self._wrapped, attr)

    sys.modules[__name__] = CallableModule(sys.modules[__name__])

#def main(x):

     
    def scale(self,filename):
        #for filename in filenames:
        # filename = "Stingray CL+,CF447_50x50_EI_nearest_baseExperiment"
        len_filename = len(filename)
        objectname = filename[:len_filename - 4]
        objectToSelect = bpy.data.objects[objectname]
        objectToSelect.select_set(True)   ## set the object
        bpy.context.view_layer.objects.active = objectToSelect ## set the object as active in the 3D viewport
        bpy.context.view_layer.objects.active.scale = (1, 1, 5) ## change the scale!!

        print(objectname)
        
        #return objectToSelect
