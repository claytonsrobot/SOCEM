% Author: Clayton Bennett
% Title: powerFitting.m
% Date: 10 February 2022
% Last edited: 10 February 2022


function [abc,a,b,c,Rsq,RMSE,SSE,nlm,f0,string1] = powerFitting(x,y,displayplot,displayline,displayrawdata)
% Inputs:
%     1. X
%     2. Y
%     3. displayplot (1 or 0) % must be 1 for remaining options to be 1
%     4. displayline (1 or 0)
%     5. displayrawdata (1 or 0)
%Example: exponentialFitting(T.NodeMajorDiameter,T.NodeMajorDiameter)
%x = T.NodeMajorDiameter;
%y = T.Stiffness;


% x and y must be verical single column!!
size_x=size(x);
size_y=size(y);
if size_x(1)==1 && size_y(1)==1
    x=x';
    y=y';
end

g = fittype('a+b*x^c');
%g = fittype('b*x^c');
beta = [60; 60; -0.1];
beta = [300; 200; -1];
f0 = fit(x,y,g,'StartPoint',beta);
%f0 = fit(x,y,g,'StartPoint',[[ones(size(x)), -exp(-x)]\y]);

try
    myfun = 'y~a+b*x^c';
    %myfun = 'y~b*x^c';
    %beta0 = [6000 6000 -0.001]; % starting points for a,b,c; values don't matter much I don't think
    %beta0 = [200; -200; 0.01]';
    beta0 = beta';
    nlm = fitnlm(x,y,myfun, beta0,'Varnames',{'x','y'});
    Rsq=nlm.Rsquared.Ordinary;
    RMSE=nlm.RMSE;
    SSE=nlm.SSE;
    
    [abc]=[nlm.Coefficients.Estimate]';
    a = abc(1);
    %a = 0;
    b = abc(2);
    c = abc(3);
    % [yy,I] = sortrows(yy);
    % xx = x(I);
    string1 = {strcat('Power Fit, f(x) = a + b*x^c');...
        strcat('a = ',{' '},string(a),' b = ',{' '},string(b),' c = ',{' '},string(c),', 95% confidence');...
        strcat('R-squared = ',{' '},string(nlm.Rsquared.Ordinary),{', '},' RMSE = ',{' '},string(nlm.RMSE),{', '},' SSE = ',{' '},string(nlm.SSE),{', '})};
        
catch
    g = fittype('a+b*x^c');
    %g = fittype('b*x^c');
    %iniitialGuess = [[ones(size(x)), -exp(-x)]\y; 1];
    %beta0 = [200; -200; 0.01];
    f0 = fit(x,y,g,'StartPoint',beta);
    %f0 = fit(x,y,g,'StartPoint',[[ones(size(x)), -exp(-x)]\y]);
    a = f0.a;
    %a = 0;
    b = f0.b;
    c = f0.c;
    string1 = {strcat('Power Fit, f(x) = a + b*x^c');...
        strcat({'a = '},string(a),{', b = '},string(b),{', c = '},string(c),{', 95% confidence'});...
        %strcat('R-squared = ',{' '},string(nlm.Rsquared.Ordinary),{', '},' RMSE = ',{' '},string(nlm.RMSE),{', '},' SSE = ',{' '},string(nlm.SSE),{', '})};
        };
    abc = [a,b,c];
    Rsq = NaN;
    RMSE = NaN;
    SSE = NaN;
    nlm = NaN;
end

xx = linspace(min(x),max(x),100);
f = @(x) a+b.*x.^(c);
yy = f(xx);

if displayplot == 1
    %hf=figure;
    if displayrawdata == 1
        
        plot(x,y,'o')
        hold on
        
    end
    if displayline == 1
        plot(xx,yy,'-')
        
        
        %xloc = (max(xx)-min(xx))*0.02+min(xx); %upper left corner
        %yloc = (max(yy)-min(yy))*0.95+min(yy); %upper left corner
        %xloc = 0+ 0.02;
        %yloc = min(ylist)-.2*(max(ylist)-min(ylist));
        %axis([0, max(xlist)+1, min(ylist)-.2*(max(ylist)-min(ylist)), max(ylist)+.1*(max(ylist)-min(ylist))]);

        %stringline1 = {strcat('a + b*exp(c*x)');strcat('a, b, c = ',string(abc),', 95% confidence');strcat('R-squared = ',string(nlm.Rsquared.Ordinary),{', '},' RMSE = ',string(nlm.RMSE),{', '},' SSE = ',string(nlm.SSE),{', '})};
%         string1 = {strcat('Exponential Fit, f(x) = a + b*exp(c*x)');...
%             strcat('a = ',{' '},string(abc(1)),' b = ',{' '},string(abc(2)),' c = ',{' '},string(abc(3)),', 95% confidence');...
%             strcat('R-squared = ',{' '},string(nlm.Rsquared.Ordinary),{', '},' RMSE = ',{' '},string(nlm.RMSE),{', '},' SSE = ',{' '},string(nlm.SSE),{', '})};
%         
        
        ha=annotation(gcf,'textbox',[0.121,0.11,1,1],'String',string1,'EdgeColor', 'none','FitBoxToText','on',  'verticalalignment', 'bottom', 'color','k');
    
    end
    
end
%f0;
%nlm; %compare results
hold off
end