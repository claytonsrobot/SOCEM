%comparison_2020_2021.m
% two versions: one row for every stem, and one row for every plot 
directory_code = 'D:\Instron Wheat Testing 2021\MatlabCode';
cd(directory_code)
importKeyVariables

fileSOCEM2020='C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron and Socem Comparison 2020\SOCEM_vs_lodging.xlsx';
fileSOCEM2021='D:\Instron Wheat Testing 2021\CompiledData\T_wheat2021_SOCEM_directImport.csv';

opts2020=detectImportOptions(fileSOCEM2020,'PreserveVariableNames',1);
opts2021=detectImportOptions(fileSOCEM2021,'PreserveVariableNames',1);
opts2021=setvartype(opts2021,{'Test description'},'string');

T20Socem=readtable(fileSOCEM2020,opts2020);
T21Socem=readtable(fileSOCEM2021,opts2021);

T21Socem=T21Socem(logical([T21Socem.("Test description")=="0hour"]+[T21Socem.("Test description")=="1"]),:);
%
for i=1:height(T20Socem)
T20Socem.plot{i}=strrep(T20Socem.plot{i},'SWW','SW');
T20Socem.plot{i}=strrep(T20Socem.plot{i},'HWW','HW');
end

%% 
fileInstron2021 = 'D:\Instron Wheat Testing 2021\CompiledData\T_InstronWheat2021_stemByStem.mat';
load(fileInstron2021);
T21Instron=T;

fileInstron2020 = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\T_wheat2020_Instron.mat';
load(fileInstron2020);
T20Instron=T;

fileSocem2020b = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\ProcessingCode\MAT file backups\socemVsLodging_Wheat2020_metric.mat';
load(fileSocem2020b);
T20SocemB=S;

load('D:\Instron Wheat Testing 2021\CompiledData\T_SOCEM_Wheat2021_correctedHeights.mat')
T21SocemB=T;

%% 2021 Instron Data organization
plotsInstron2021 = unique(T21Instron.Plot);
AveEI_Instron2021=[];
EI_SOCEM2021=[];
plotsSOCEM_NaN=[];
for i=1:numel(plotsInstron2021)
    AveEI_Instron2021(i)=mean(table2array(T21Instron(plotsInstron2021(i)==string(T21Instron.Plot),find(string(T21Instron.Properties.VariableNames)=='EI'))));
    if sum(plotsInstron2021(i)==string(T21Socem.Plot))>0 && contains(plotsInstron2021(i),"HW") % remove HW plots
        EI_SOCEM2021(i)=NaN;
        plotsSOCEM_NaN(end+1)=i;
    elseif sum(plotsInstron2021(i)==string(T21Socem.Plot))>0
        EI_SOCEM2021(i) = table2array(T21Socem(plotsInstron2021(i)==string(T21Socem.Plot),find(string(T21Socem.Properties.VariableNames)==("EI-M (lbs*in^2)"))));
    else
        EI_SOCEM2021(i)=NaN;
        plotsSOCEM_NaN(end+1)=i;
        
    end
end
AveEI_Instron2021(plotsSOCEM_NaN)=[];
plotsInstron2021(plotsSOCEM_NaN)=[];
EI_SOCEM2021(plotsSOCEM_NaN)=[];
AveEI_Instron2021=AveEI_Instron2021';
EI_SOCEM2021 = EI_SOCEM2021./Newtons2Pounds./mmsqr2insqr;
EI_SOCEM2021=EI_SOCEM2021';

%% 2021 Instron Data organization, B, corrected heights
plotsInstron2021 = unique(T21Instron.Plot);
AveEI_Instron2021=[];
EI_SOCEM2021b=[];
plotsSOCEM_NaN=[];
varieties_SOCEM2021b={};
for i=1:numel(plotsInstron2021)
    AveEI_Instron2021(i)=mean(table2array(T21Instron(plotsInstron2021(i)==string(T21Instron.Plot),find(string(T21Instron.Properties.VariableNames)=='EI'))));
    if sum(plotsInstron2021(i)==string(T21SocemB.Plot))>0 && contains(plotsInstron2021(i),"HW") % remove HW plots
        EI_SOCEM2021b(i)=NaN;
        varieties_SOCEM2021b{i}=NaN;
        plotsSOCEM_NaN(end+1)=i;
    elseif sum(plotsInstron2021(i)==string(T21SocemB.Plot))>0
        EI_SOCEM2021b(i) = table2array(T21SocemB(plotsInstron2021(i)==string(T21SocemB.Plot),find(string(T21SocemB.Properties.VariableNames)==("EI-M (lbs*in^2)"))));
        varieties_SOCEM2021b{i}= table2array(T21SocemB(plotsInstron2021(i)==string(T21SocemB.Plot),find(string(T21SocemB.Properties.VariableNames)==("Variety"))));
    else
        EI_SOCEM2021b(i)=NaN;
        varieties_SOCEM2021b{i}=NaN;
        plotsSOCEM_NaN(end+1)=i;
        
    end
end
AveEI_Instron2021(plotsSOCEM_NaN)=[];
plotsInstron2021(plotsSOCEM_NaN)=[];
EI_SOCEM2021b(plotsSOCEM_NaN)=[];
varieties_SOCEM2021b(plotsSOCEM_NaN)=[];
AveEI_Instron2021=AveEI_Instron2021';
EI_SOCEM2021b = EI_SOCEM2021b./Newtons2Pounds./mmsqr2insqr;
EI_SOCEM2021b=EI_SOCEM2021b';
%% 2020  Data organization, I don't trust this one.
plotsInstron2020 = unique(T20Instron.Plot);
AveEI_Instron2020=[];
EI_SOCEM2020=[];
plotsSOCEM_NaN=[];
for i=1:numel(plotsInstron2020)
    AveEI_Instron2020(i)=mean(table2array(T20Instron(plotsInstron2020(i)==string(T20Instron.Plot),find(string(T20Instron.Properties.VariableNames)=='EI'))));

    if sum(plotsInstron2020(i)==string(T20Socem.plot))>0
        EI_SOCEM2020(i) = table2array(T20Socem(plotsInstron2020(i)==string(T20Socem.plot),find(string(T20Socem.Properties.VariableNames)==("EI-M (lbs*in^2)"))));
    else
        EI_SOCEM2020(i)=NaN;
        plotsSOCEM_NaN(end+1)=i;
        
    end
end
AveEI_Instron2020(plotsSOCEM_NaN)=[];
plotsInstron2020(plotsSOCEM_NaN)=[];
EI_SOCEM2020(plotsSOCEM_NaN)=[];
AveEI_Instron2020=AveEI_Instron2020';
EI_SOCEM2020 = EI_SOCEM2020./Newtons2Pounds./mmsqr2insqr;
EI_SOCEM2020=EI_SOCEM2020';

%% 2020  Data organization, alterative SOCEM source, I trust this one
plotsInstron2020b = unique(T20Instron.Plot);
AveEI_Instron2020b=[];
EI_SOCEM2020b=[];
plotsSOCEM_NaN=[];
for i=1:numel(plotsInstron2020b)
    AveEI_Instron2020b(i)=mean(table2array(T20Instron(plotsInstron2020b(i)==string(T20Instron.Plot),find(string(T20Instron.Properties.VariableNames)=='EI'))));
    if sum(plotsInstron2020b(i)==string(T20SocemB.Plot))>0
        EI_SOCEM2020b(i) = table2array(T20SocemB(plotsInstron2020b(i)==string(T20SocemB.Plot),find(string(T20SocemB.Properties.VariableNames)==("EI_M"))));
    else
        EI_SOCEM2020b(i)=NaN;
        plotsSOCEM_NaN(end+1)=i;
        
    end
end
AveEI_Instron2020b(plotsSOCEM_NaN)=[];
plotsInstron2020b(plotsSOCEM_NaN)=[];
EI_SOCEM2020b(plotsSOCEM_NaN)=[];
AveEI_Instron2020b=AveEI_Instron2020b';
%EI_SOCEM2020b = EI_SOCEM2020b./Newtons2Pounds./mmsqr2insqr;
EI_SOCEM2020b=EI_SOCEM2020b';

%% Import 2020 Barley
fileBarley2020_5 = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\T_barley5_run1s.mat';
fileBarley2020_15 = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\T_barley15_run1s.mat';
fileBarley2020_99 = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\T_barley_99percentDecrease_11282021.mat';
load(fileBarley2020_5);
T5=T;
load(fileBarley2020_15);
T15=T;
load(fileBarley2020_99);
T99=T;
T99.i=[];
T20Instron_barley=[T5;T15;T99];
plots_barley2020=unique(T20Instron_barley.Plot);

fileSocemBarley2020='D:\Instron Wheat Testing 2021\CompiledData\T_SOCEM_barley2020_allHits.mat';
load(fileSocemBarley2020);
T20Socem_barley = T;
%remove all but first hits
T20Socem_barley_allhits=T20Socem_barley;
T20Socem_barley=T20Socem_barley(contains(T20Socem_barley.Plot,"_1"),:);
T20Socem_barley.Plot=strrep(T20Socem_barley.Plot,"_1","");

load('D:\Instron Wheat Testing 2021\CompiledData\T_SOCEM_barley2020_correctedHeights.mat')
T20Socem_barleyC=T;

%% 2020 Barley data organization, 
plotsInstron2020_barley = unique(T20Instron_barley.Plot);
AveEI_Instron2020_barley=[];
EI_SOCEM2020_barley=[];
plotsSOCEM_NaN=[];
for i=1:numel(plotsInstron2020_barley)
    AveEI_Instron2020_barley(i)=mean(table2array(T20Instron_barley(plotsInstron2020_barley(i)==string(T20Instron_barley.Plot),find(string(T20Instron_barley.Properties.VariableNames)=='EI'))));
    if sum(plotsInstron2020_barley(i)==string(T20Socem_barley.Plot))>0
        EI_SOCEM2020_barley(i) = table2array(T20Socem_barley(plotsInstron2020_barley(i)==string(T20Socem_barley.Plot),find(string(T20Socem_barley.Properties.VariableNames)==('EI-M (lbs*in^2)'))));
    else
        EI_SOCEM2020_barley(i)=NaN;
        plotsSOCEM_NaN(end+1)=i;
        
    end
end
AveEI_Instron2020_barley(plotsSOCEM_NaN)=[];
plotsInstron2020_barley(plotsSOCEM_NaN)=[];
EI_SOCEM2020_barley(plotsSOCEM_NaN)=[];
AveEI_Instron2020_barley=AveEI_Instron2020_barley';
EI_SOCEM2020_barley = EI_SOCEM2020_barley./Newtons2Pounds./mmsqr2insqr;
EI_SOCEM2020_barley=EI_SOCEM2020_barley';

%% 2020 Barley data organization C, corrected height
plotsInstron2020_barleyC = unique(T20Instron_barley.Plot);
AveEI_Instron2020_barleyC=[];
EI_SOCEM2020_barleyC=[];
plotsSOCEM_NaN=[];
for i=1:numel(plotsInstron2020_barleyC)
    AveEI_Instron2020_barleyC(i)=mean(table2array(T20Instron_barley(plotsInstron2020_barleyC(i)==string(T20Instron_barley.Plot),find(string(T20Instron_barley.Properties.VariableNames)=='EI'))));
    if sum(plotsInstron2020_barleyC(i)==string(T20Socem_barleyC.Plot))>0
        EI_SOCEM2020_barleyC(i) = table2array(T20Socem_barleyC(plotsInstron2020_barleyC(i)==string(T20Socem_barleyC.Plot),find(string(T20Socem_barleyC.Properties.VariableNames)==('EI-M (lbs*in^2)'))));
    else
        EI_SOCEM2020_barleyC(i)=NaN;
        plotsSOCEM_NaN(end+1)=i;
        
    end
end
AveEI_Instron2020_barleyC(plotsSOCEM_NaN)=[];
plotsInstron2020_barleyC(plotsSOCEM_NaN)=[];
EI_SOCEM2020_barleyC(plotsSOCEM_NaN)=[];
AveEI_Instron2020_barleyC=AveEI_Instron2020_barleyC';
EI_SOCEM2020_barleyC = EI_SOCEM2020_barleyC./Newtons2Pounds./mmsqr2insqr;
EI_SOCEM2020_barleyC=EI_SOCEM2020_barleyC';

%% comparing multiple Barley 2020 Instron sets from same plots. Ignore this. It's fine.
% plots5=unique(string(T5.Plot));
% plots15=unique(string(T15.Plot));
% plots99=unique(string(T99.Plot));
% 
% stuff={plots5,T5,zeros(numel(plots5),1);plots15,T15,zeros(numel(plots15),1);plots99,T99,zeros(numel(plots99),1)};
% for er=1:3
% for i=1:numel(stuff{er,1})
%     stuff{er,3}(i)=mean(table2array(stuff{er,2}(stuff{er,1}(i)==stuff{er,2}.Plot,find(string(stuff{er,2}.Properties.VariableNames)=='EI'))));
% end
% end
% allplots=[stuff{1,1};stuff{2,1};stuff{3,1}];
% allrefs=[{1,[1:numel(stuff{1,1})];2,[1:numel(stuff{2,1})];3,[1:numel(stuff{3,1})]}];
% allrefs_flat = [allrefs{4},allrefs{5},allrefs{6};...
%                 ones(1,numel(allrefs{4})).*1,ones(1,numel(allrefs{5})).*2,ones(1,numel(allrefs{6})).*3;...
%                 1:numel(allplots)]';
%                 % column of i, then column of er
% allrefs_flat_og=allrefs_flat;
% duplicateplots=allplots;
% j=1;
% while j<=numel(duplicateplots)
%     
%     if sum(duplicateplots(j)==allplots)==1
%         duplicateplots(j)=[];
%         allrefs_flat(j,:)=[];
%     else
%         j=j+1;
%     end
% end
% duplicateplots2=unique(duplicateplots);
% 
% msgblock={};
% for er=1:3
% for k=1:numel(duplicateplots2)
%     if (not(isempty(find(duplicateplots2(k)==stuff{er,1}))))
%         i=find(duplicateplots2(k)==stuff{er,1});
%         msg=sprintf('i=%d, er=%d, k=%d, plot=%s',i,er,k,(stuff{er,1}(i)));
%         msgblock{end+1}=msg;
%         disp(msg)
%     end
% end
% end
% stuff2={}
% for j=1:numel(duplicateplots2)
%     j1=min(find(duplicateplots2(j)==allplots));
%     j2=max(find(duplicateplots2(j)==allplots));
%     er1=allrefs_flat_og(j1,2);
%     i1=allrefs_flat_og(j1,1);
%     er2=allrefs_flat_og(j2,2);
%     i2=allrefs_flat_og(j2,1);
%     [stuff{er1,3}(i1),stuff{er2,3}(i2)]
%     mean([stuff{er1,3}(i1),stuff{er2,3}(i2)])
%     std([stuff{er1,3}(i1),stuff{er2,3}(i2)])
% end