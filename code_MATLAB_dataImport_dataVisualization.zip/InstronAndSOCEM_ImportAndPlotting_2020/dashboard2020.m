% Title: dashboard.m
% Author: Clayton Bennett
% Created: 26 Novermber 2021
% Last updated: 26 Novermber 2021
format compact
% Create T
%directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\Wheat\August 2020\Alt Method - No AutoStop, continuous\';
%directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\Wheat\August 2020\';
%directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\Barley\September 2020\Alt Method - No AutoStop, continuous\';
%directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\Barley\September 2020\Alt Method - 5% Decrease Past Max Reading\';
%directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\Barley\September 2020\Alt Method - No AutoStop, continuous\';
directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\Wheat\August 2020\'

%T = InstronTableMaker_multiname(directory,{'hardwinterwheat','clearfield','softwinterwheat','springbarleyfeed'},{'0HW','0CF','0SW','0SBF'},'non-cyclic'); 
T = InstronTableMaker_multiname(directory,{'hardwinter','clearfieldwheat','softwinterwheat','springbarleyfeed'},{'0HW','0CF','0SW','0SBF'},'non-cyclic');

thresholdCheckerInstronTable_2

InstronColumnMagic_3

InstronAveraging_createTableI_4