% Clayton Bennett
%% Header
% Filename: thresholdCheckerInstronTable_2.m
% Author: Clayton Bennett
% Created: 10 March 2021
% Updated: 31 July 2021

% Step 2 in Instron data processing.

% Overview: This script looks through the load and displacement arrays
%  for each Instron test in table T to identify the max load, the index
%  of the max load in the array, and the displacement at that index.
%  To ensure accuracy and functionality, these values (which are sourced
%  from the individual csv files and have four decimal places) are
%  compared to the values which were sourced from the overview files
%  (which have two decimal places). The user can set a percentage
%  difference threshold for this comparison.
% 
% Reason: 
%  The numbers for time, force, and displacement in the overview Instron
%  files are rounded. To get more specifc numbers, with four decimal places,
%  We will replace the recorded force and displacement at max force values
%  with the ones from the arrays. As this is done, we will make sure that
%  the values are at least similar, with an oppounity to view the
%  comparison. Set the threshhold percentage higher (~0.8%) to see less instances of
%  disparity, and lower (0.1%) to see more instances of disparity.
%
% Input values: Threshold percentage for comparison. If the difference
%  between the two-decimal-place overview max load and the four-decimal-place
%  individual file max load exceeds the user-defined threshold percentage,
%  this will trigger a print-to-command-window of these relevant values:
%  index, plot name, stem number, file name, the max load from both
%  sources, the percentage difference between the max load from both
%  sources, the loads from directly before and after the max load (so
%  that the user can clearly see this is truly the max load).

% Updates
%  - 25 June 2021 - Add notes, clean up script.
%  - 31 June 2021 - Add notes, clean up script.
%  - 10 June 2021 - Changed name away from "instronDataTable_calculations".
%% Inputs

thresholdPercentage = .5; % Actual percetnage value. 1 = 1%.
% If nothing is printed to the command window, make "thresholdPercentage"
%       smaller and run again, if you want to see what that's like or for
%       peace of mind.
% %% %%

% %% 
% Example of intepretation for output data :
% Biggest perctage off displacement: 5.3442 mm, rounded to 5.3400 mm, 0.3281%
% Biggestpercentage off max force: 1.6740 N, rounded to 1.6700 N. 0.2395, j=449, 'softwinter236_3.csv' %
% %% %%

%% Prepare table for calculations, add columns.
T.MaxLoad_calculated = nan(height(T),1);
T.DisplacementAtMaxLoad_calculated = nan(height(T),1);

%% Calculate MaxLoad_calculated and DisplacementAtMaxLoad_calculated for each row.
percentageOff_maxLoad_max=0;
percentageOff_maxLoad=0;
percentageOff_displacementAtMaxLoad_max=0;
percentageOff_displacementAtMaxLoad=0;
count_exceedThresholdPercentage=1;

for j = 1:height(T)
    % %% These three lines do all the work of replacing data.
    %
    T.MaxLoad_calculated(j)=max(T.Force{j});
    index_atForceMax=find(max(T.Force{j}) == T.Force{j});
    T.DisplacementAtMaxLoad_calculated(j) = min(T.Displacement{j}(index_atForceMax));
    %
    % %% %%
    
        % %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %%
        % %% Everything else is meant to check to make sure numbers ended up in the
        %       right place.
        %
        difference_maxLoad = T.MaxLoad_calculated(j)-T.MaxLoad(j);
        percentageOff_maxLoad_last=percentageOff_maxLoad;
        percentageOff_maxLoad=difference_maxLoad./T.MaxLoad(j)*100;
        percentageOff_maxLoad_max = max([percentageOff_maxLoad_last,abs(percentageOff_maxLoad),percentageOff_maxLoad_max]);

            % %% Display information for instances that exceed the input
            %       thresholdPercentage.
            %
            if percentageOff_maxLoad>=thresholdPercentage
                j % row in table T
                count_exceedThresholdPercentage % count of instances with a threshold exceeding thresholdPercentage
                plot=T.Plot(j)
                stem = T.Stem(j)
                file = T.File{j}

                preMaxF=T.Force{j}(index_atForceMax-1)
                maxF=T.Force{j}(index_atForceMax)
                postMaxF=T.Force{j}(index_atForceMax+1)
                maxF_calculated=T.MaxLoad_calculated(j)
                maxF_overview=T.MaxLoad(j)
                percentageOff_maxLoad
                fprintf('\n')
                count_exceedThresholdPercentage=count_exceedThresholdPercentage+1;
            end
            %
            %
            % %% %%

        %    
        %   
        % %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %%
end

% Keep the Workspace tidy. Clear variables with no further use.
clear preMaxF postMaxF maxF maxF_calculated maxF_overview ...
    difference_maxLoad percentageOff_displacementAtMaxLoad ...
    percentageOff_displacementAtMaxLoad_max percentageOff_maxLoad ...
    percentageOff_maxLoad_last percentageOff_maxLoad_max plot stem file ...
    index_atForceMax % These change for each loop through.

clear thresholdPercentage 

%% Adjust units and descriptions.
T.Properties.VariableUnits = {'','','', '', '','','', 's', 'mm', 'N', 'N/mm', 'MPa', 'N', 'mm', '', '', 'N', 'mm'};
T.Properties.VariableDescriptions{'MaxLoad_calculated'} = 'Calculated from MaxLoad array, for comparison to MaxLoad value from overview file.';
T.Properties.VariableDescriptions{'DisplacementAtMaxLoad_calculated'} = 'Calculated from DisplacementAtMaxLoad array, for comparison to DisplacementAtMaxLoad value from overview file.';

%% Save progress to relevant variable.
% example: T_barley=T; T_wheat = T;
%T_barley=T;
%T_wheat=T;
