function [distX,distY,magX,magY] = capBuilder(distX,distY,magX,magY)
%         [distX,distY,magX,magY] = capBuilder(distX,distY,magX,magY);

% elongate vector by copying the first and last values.
distY = elongateCap(distY);

if numel(distY)>numel(distX)
distX = elongateCap(distX);
magX = elongateCap(magX);
end

% insert place holder values of -10 at extremities
frontcap = -10;
endcap = frontcap;
magY=[frontcap,magY];
magY(end+1)=endcap;

end
%% metadata
% author: Clayton Bennett
% created: 05/01/2022
% Description: Put endcaps on extremities of 3D data shape