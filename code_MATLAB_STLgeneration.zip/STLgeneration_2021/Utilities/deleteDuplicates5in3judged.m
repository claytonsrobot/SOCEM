function [vectorA_new,vectorB_new,vectorC_new,vectorD_new,vectorE_new]=deleteDuplicates5in3judged(vectorA,vectorB,vectorC,vectorD,vectorE);

        vectors = {vectorA,vectorB,vectorC,vectorD,vectorE};
        
        for i=1:3
            active = vectors{i};
        [U, I] = unique(active, 'first');
        x = 1:length(active);
        x(I) = [];
        
        for j=1:5
        vectors{j}(x)=[];
        end
        end
        
        vectorA_new = vectors{1};
        vectorB_new = vectors{2};
        vectorC_new = vectors{3};
        vectorD_new = vectors{4};
        vectorE_new = vectors{5};
        
%         [U, I] = unique(vectorB, 'first');
%         x = 1:length(vectorB);
%         x(I) = [];
%         vectorB(x)=[];
%         vectornewA(x)=[];
%         vectornewB=vectorB;
%         if not(numel(vector)==numel(unique(vector)))
%             display([numel(vector),numel(unique(vector))])
%             [vectornew]=deleteDuplicates(vectornew);
%         end
end
