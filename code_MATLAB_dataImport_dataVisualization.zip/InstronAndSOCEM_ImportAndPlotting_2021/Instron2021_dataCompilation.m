% Author: Clayton Bennett
% Date 31 January 2022
% Title: Instron2021_dataCompilation.m
% Description: Pulls in overview files for basic overview data analysis.
%   Uses averages of strength and stiffness from each variety.

format compact

%% Import data

directory_script = 'H:\Instron Wheat Testing 2021\MatlabCode';
directory_data = 'H:\Instron Wheat Testing 2021\SOCEM2021';

% %%
% If '\' is not input by the user as the final character in the directory
% assignment, add  it.
% 
if (directory_data(end)~='\')
    directory_data = strcat(directory_data,'\');
end

if (directory_script(end)~='\')
    directory_script = strcat(directory_script,'\');
end
% %%%

cd(directory_data)

list_csvfiles = dir('*.csv');
n_plots = length(list_csvfiles)'; % How many overview files are there in the directory?
n_stems = n_plots*10;
idxs_names = zeros(n_plots,1);
for i=1:n_plots
    idxs_names(i)=i*6+1-6;
end
tc=struct2cell(list_csvfiles);
names_overviewfiles = tc(idxs_names');

%% PREPARE THE TABLE
% varnames = {'i','Variety','Plot','Stem','OverviewFile','StiffnessSlope_average','Strength_average','Modulus_average','DisplacementAtMaxLoad','StiffnessChoice','Breaktype','Notes'};
varnames = {'i','Variety','Plot','OverviewFile','StiffnessSlope_average','Strength_average','Modulus_average','DisplacementAtMaxLoad_average','StiffnessChoice'};

T = cell2table(cell(n_plots,numel(varnames)), 'VariableNames', varnames); % Create table T.
T.i = nan(height(T),1); % Prepare column "i" to be numbers.
T.Variety = strings([height(T),1]);
T.Plot = strings([height(T),1]); % Prepare column "Plot" to be strings.
%T.Stem = nan(height(T),1); % Prepare column "Stem" to be numbers.
T.OverviewFile = strings([height(T),1]); % Prepare column "OverviewFile" to be strings.
T.StiffnessSlope_average = nan(height(T),1); % Prepare column "LoadDeflection" to be numbers.
%T.Modulus = nan(height(T),1); % Prepare column "Modulus" to be numbers.
T.Strength_average = nan(height(T),1); % Prepare column "MaxLoad" to be numbers.
T.Modulus_average = nan(height(T),1); % Prepare column to be numbers.
T.DisplacementAtMaxLoad_average = nan(height(T),1); % Prepare column "DisplacementAtMaxLoad" to be numbers.
T.StiffnessChoice = strings([height(T),1]);
%T.BreakType = strings([height(T),1]);
%T.Notes = strings([height(T),1]);
%%
for i=1:n_plots
    OverviewFile = string(names_overviewfiles(i)); 
    Plot = eraseBetween(OverviewFile,min(strfind(OverviewFile,'_')),strlength(OverviewFile)); %for non-cyclic tests
    Plot = extractAfter(Plot,1);
    % Identify each file name, one at a time.
    T.i(i)=i;
    %T.File(i)=File;
    T.Plot(i)=Plot;
    T.OverviewFile(i)=OverviewFile;
    % %%
end
%% 
heightT=height(T);
handle_waitbar_overviewFiles=waitbar(0,strcat('Data is being imported from ',string(heightT),'overview Instron files. Computer speed, go!'));


for i=1:height(T)
    
    [ndata_notUsed, text_notUsed, c_overviewDataPullIn] = xlsread(strcat(directory_data,T.OverviewFile(i))); %c is of type cell %% ERROR for j=63, j=23
    fprintf('%d.', i)
    waitbar(i/height(T),handle_waitbar_overviewFiles)
    
            clear StiffnessChoicesArray StiffnessSlopesArray
            StiffnessChoicesArray = c_overviewDataPullIn(7:16,18);
            StiffnessSlopesArray = cell2mat(c_overviewDataPullIn(7:16,[3:6,8:11]));
            StiffnessSlopesList = zeros(10,1);
            
            for n_stem=1:10
                if string(StiffnessChoicesArray(n_stem,:))==string('Auto slope')
                    StiffnessSlopesList(n_stem) = StiffnessSlopesArray(n_stem,1);
                elseif StiffnessChoicesArray(n_stem,:)==string('Average all')
                    StiffnessSlopesList(n_stem) = mean(StiffnessSlopesArray(n_stem,:));
                elseif StiffnessChoicesArray(n_stem,:)==string('2nd lowest')
                    StiffnessSlopesList(n_stem) = max(mink(StiffnessSlopesArray(n_stem,:),2));
                else 
                    StiffnessSlopesList(n_stem) = StiffnessSlopesArray(n_stem,1);
                end
            end
            
            
            %T.Stem = nan(height(T),1); % Prepare column "Stem" to be numbers.
            T.StiffnessSlope_average(i) = mean(StiffnessSlopesList); % N/mm
            T.Strength_average(i) = mean(cell2mat(c_overviewDataPullIn(7:16,13))); %N, max forces from each stalk
            T.Modulus_average(i) = T.StiffnessSlope_average(i).*0.9182; %0.9182 comes from assumptions made about wall thickness and standard diameter, which is not accurate. Diameter measurentsd were recorded.
            %T.Notes(i) = cell2mat(c_overviewDataPullIn(7+rowIndex-1,6)); %notes
            %T.BreakType(i) = cell2mat(c_overviewDataPullIn(7+rowIndex-1,7)); %breaktype
            
end
close(handle_waitbar_overviewFiles)

section6of7 = "Overview values have been imported."
%% Descriptions and units
% %% Is scalable only if in metric and these are the expected variables. +*#*#*#*#*#*+
%T.Properties.VariableUnits = {'','','', '', '','','', 's', 'mm', 'N', 'N/mm', 'MPa', 'N', 'mm', '', ''}; 
%T.Properties.VariableDescriptions{'Time'} = 'Array of time values during INSTRON test.';
%T.Properties.VariableDescriptions{'Displacement'} = 'Array of displacement values during INSTRON test.';
%T.Properties.VariableDescriptions{'Force'} = 'Array of force values during INSTRON test.';
T.Properties.VariableDescriptions{'StiffnessSlope_average'} = 'Automatically generated overview value based on INSTRON method. In this case, the slope was taken from the Force data at displacements of 0.8 mm and 1 mm. This number is not to be trusted. In some cases, the number was not generated at all.';
T.Properties.VariableDescriptions{'Modulus_average'} = 'Automatically generated overview value based on INSTRON method. This number requires an input for cross sectional area of the plant, which was not measured. Hypothetically, a coefficient can be discovered for adjustment, based on the span of the INSTRON at the time of testing.';
T.Properties.VariableDescriptions{'Strength_average'} = 'Max load, identified automatically. Should be checked for accuracy.';
T.Properties.VariableDescriptions{'DisplacementAtMaxLoad_average'} = 'Displacement at max load, calculated automatically. Should be checked for accuracy.';
%T.Properties.VariableDescriptions{'BreakType'} = 'Choices: CRUSHED, SNAPPED, or SPLINTERED.';
T.Properties.VariableDescriptions{'Variety'} = '';

%% Plot data
hold off
plot(T.StiffnessSlope_average,T.Strength_average,'o')
hold on

% y = 3.019*x + 1.834, R^2 = 0.8579
yintercept = 1.834;
xintercept = -1.834/3.019;

xlabel('Stiffness [N/mm]')
ylabel('Strength [N]')
title('Stiffness and Strength Correlation, Wheat 2020, Instron')
string1 = {'10 stem samples from','each plot were tested,','and results were averaged.'};
text(2.5,6,string1)

%string2 = {'y = 3.019*x + 1.834','R^2 = 0.8579'};
%text(1.6,10.5,string2)
plot([0,xintercept,3.5],[yintercept,0,3.019*3.5+1.834],'-')
axis([1 3.5 5 13])

legend('52 Experimental Wheat Plots',strcat('Linear Best Fit: y = 3.019*x + 1.834 , R^2 = 0.8579'),'Location','northwest')
hold off
%% End matter
cd(directory_script)
