'''
TItle: PeakClick
SOCEM Data Analysis
Author: Clayton Bennett and Austin Bebee
Austin Bebee wrote version 1. 
Last edited: 04/29/2022, by Clayton Bennett (Version 7)

Description:
    - Loops through folder containing clean SOCEM Excel data
    - User inputs additional info
    - User selects where to cut force dis. plot ends (eliminate edge effects)
    - User selects force peaks from cut plot
    - Calculations are performed (primiarily EI)
    - Exports data into Excel files

V4 - Massive automation upgrades all around
V5 - Changed refernces to external drive
        - Several old comments removed.
        - Change so that only data xCut range is saved.
        - Changed xL to horzL and x (where it reresents [0 20 40 ... 120 etc] to horz.
        - Plot formatting altered, secondary axis added for force.
V6
        - Reorder variables in output file.
        - Prepare for import of data into Matlab using SOCEM2021_dataCompilation.m script.
        - Autosave pre-xCut and post-click images of each plot to the Documentation folder.
        - Add vertical lines in the plot halfway between horz values.

V7
        - Change header names
        - Change units to metric
        - Delete variables meant to track xCut and tCut, from previous troubleshooting
        
V8
        - Change interface to 9 cell input
        - driveLetter variable added to help with directory issue
V9
        - Changed name to PeakClick from SOCEM_Data_Analysis_vCurrent
        - Shred excess. Even hypothetically useful calcualtions like area under the curve have been removed. See old version SOCEM_Data_Analysis_v8+.py for reference to use.
        - Name changes to variables and to spreadsheer headers
        - CSV generate instead of XLSX
        - Change to Metric (N and cm)
        - Forward direction hits will no longer be used for anything except for rich 3D imagery and weighting . No EI calc necessary for forward hits.
V10
        - Now this not a tool to calcualte EI. it is just for getting peak force, time, and distance values. oh and cuts. return raw data between cuts?

V13
        - Triggered by StemBerry_v77 and above
        - American units changed to metric
        
Future work:
        - Plot changes in initialPlot, prior to autosaving, showing xCut red-line selections
        - In choosePeaks(), show zone differentiation lines, halfway between each horz value and the next.
        - Shred excess
        - - - - - -THIS: All this needs to do now is return the force, distance, and time values of peaks. These should be saved to a file, named GUI.filename_force.get()+"_peaks"
Bugs:
    - (Rarely, only during troubleshooting) The betaV value in the EI_Interaction tool cannot calculate because the arcsin query is above 1.0. Observed value of 1.04. Typical observed range of 0.8 to 0.99.
        o Fix: (Currently not active) If the arcsin query is above 1.0, change it to 1.0. This change must be made in the EI_Interaction_Fx script.
        o If value exceeds 1, have value print.
    - ...

Stem counts matter and differ for each side hit. But, this will be processed in the compileNineCell portion of the Stemberry script

'''
# needed libraries
import math
import pandas as pd
from pandas import ExcelFile
from pandas import ExcelWriter
import numpy as np
from datetime import date
from datetime import datetime
import os
import csv
import xlsxwriter
# import peakutils
import matplotlib.pyplot as plt
from matplotlib.widgets import Cursor


barlength = 76 # cm = 30 in
#generateGraphs = (str(input('Would you like graphs to be generated in the exported analysis files (y/n)? ')))
generateGraphs = True
useInitialPlot = False
disReferenced = False # initially
'''
# New way, CSV # if importing
csvfilename = Purl,SW429_preTest.csv #example, will errror for now # {variety},{plot}_preTest.csv
df = pd.read.csv(csvfilename) # read to get force and distance.....except, this can be saved in save state
stemheight = 2 # one number from {variety},{plot}_preTest.csv
'''

def testOS():
    print("Check incoming address name for \ or /, MS windows or linux")
    print("if \ in: or elseif / in: ")
    print("Change \\ to //.")
    
class SnaptoCursor(object):
    '''
    Cursor crossshair snaps to nearest x, y point.
    '''
    def __init__(self, ax, x, y):
        self.ax = ax
        #self.lx = ax.axhline(color='gold') # horizontal line
        self.ly = ax.axvline(color='orange', linewidth=1, linestyle="--") # vertical line
        self.x = x
        self.y = y
        # text location in axes coords
        self.txt = ax.text(0.7, 0.9, '', transform=ax.transAxes)

    def mouse_move(self, event):
        if not event.inaxes:
            return

        x, y = event.xdata, event.ydata
        indx = min(np.searchsorted(self.x, x), len(self.x)-1)
        x = self.x[indx]
        y = self.y[indx]
        # update the line positions
        #self.lx.set_ydata(y)
        self.ly.set_xdata(x)

        self.txt.set_text('x=%1.2f, y=%1.2f' % (x, y))
        #print('x=%1.2f, y=%1.2f' % (x, y))
        self.ax.figure.canvas.draw()

class Cursor(object):
    '''
    Cursor crosshair that follows mouse
    '''

    def __init__(self, ax):
        self.ax = ax
        self.lx = ax.axhline(color='orange', linewidth=1, linestyle="--")
        self.ly = ax.axvline(color='orange', linewidth=1, linestyle="--")
        #text location in axes coords
        self.txt = ax.text(0.7, 0.9, '',transform=ax.transAxes)

    def mouse_move(self, event):
        if not event.inaxes:
            return
        x, y = event.xdata, event.ydata
        #update line positions
        self.lx.set_ydata(y)
        self.ly.set_xdata(x)

        self.txt.set_text('x=%1.2f, y=%1.2f' % (x, y))
        self.ax.figure.canvas.draw()

#####################################################################################################################
def initialPlot(distanceTraveled, forcePushed, timeElapsed, encoderWorked, varietyAndPlotnameAndDetail, documentationFolder,averageVelocity):
    fig, ax = plt.subplots()

    ''' vertical lines, for suggesting edge effect regions for forward tests '''
    if encoderWorked == True:  
        start = 50 # cm , cut off 1st 50cm = 20" usually #
        end = 305 # cm, cut off after 120 inches = 305 cm usually
    else:
        startDis = 50 # cut off 1st 50cm = 20" usually
        try:
            speed = averageVelocity # assume cm/ms . would need encode to work.....
            start = startDis/speed # CB edit # 20/speed # find t where SOCEM ~ 20" into plot
        except:
            speed = 50 # assume 50 cm/s
            start = startDis/speed # CB edit # 20/speed # find t where SOCEM ~ 20" into plot
        endDis = 305 # cut of after 120" usually
        end = endDis/speed # CB edit # time[-1] - (20/speed) # find t where SOCME ~ 20" before end of plot
        
        disReferenced_input = str(input('Would you like to type in known distance points (y/n)? '))
        if disReferenced_input == 'y':
            disReferenced = True
        elif disReferenced_input == 'n':
            disReferenced = False
        else: # just in case
            disReferenced = False
            
        if disReferenced == True:
            startDisRef = (int(input('Start point x (in): ')))
            endDisRef = (int(input('End point x (in): ')))
              
        ''' '''
    maxPt = max(forcePushed)
    # draw cut off lines
    cutStart = [start, start]
    cutEnd = [end, end]
    cutLine = [0, maxPt]
    ax.plot(cutStart,cutLine, color = 'red') # start cut off line
    ax.plot(cutEnd, cutLine, color = 'red') # end cut off line
    
    
    # plot dis vs forcePushed    
    if encoderWorked == True:
        ax.plot(distanceTraveled, forcePushed, color='midnightblue')
        ax.set_xlabel('Distance (cm)')
        snap_cursor = SnaptoCursor(ax, distanceTraveled, forcePushed) # create snap cursor object
    # plot time vs forcePushed
    else:
        ax.plot(timeElapsed, forcePushed, color='midnightblue')
        ax.set_xlabel('Time (ms)')
        snap_cursor = SnaptoCursor(ax, timeElapsed, forcePushed) # create snap cursor object
        
    title3 = '\n*click outside plot if red lines good*'
    fig.suptitle(varietyAndPlotnameAndDetail + '\nCut off edges: click start x pt, then end x pt.' + title3)
    #ax.set_title('*click outside plot if red lines good*')
    ax.set_ylabel('Force (N)')
    
    snap = fig.canvas.mpl_connect('motion_notify_event', snap_cursor.mouse_move) # update snap cursor upon mouse movement

    xCut = [] # stores where to cut off ends of plot (eliminate edge effects)
    def click(event): # get x coord once mouse is pressed
        x = event.xdata
        if x is None:
            print('red lines')
            xCut.append((start))
            xCut.append((end))
        else:
            print('x clicked = %1.2f' % x)
            xCut.append((x))
          #  self.fig.canvas.mpl_disconnect(cid)
        if len(xCut) >= 2:
            fig.canvas.mpl_disconnect(cid)
            fig.canvas.mpl_disconnect(snap)
            fig.canvas.set_window_title('InitialPlot')
            if encoderWorked == True:
                savename = varietyAndPlotnameAndDetail + '_' + str(round(xCut[0],1)) + '-' + str(round(xCut[1],1)) + '_raw.PNG'
            elif encoderWorked == False and disReferenced == True:
                savename = varietyAndPlotnameAndDetail + '_' + str(round(xCut[0],1)) + '-' + str(round(xCut[1],1)) + '_disref' + '_raw.PNG'
            elif encoderWorked == False and disReferenced == False:
                savename = varietyAndPlotnameAndDetail + '_' + str(round(xCut[0],1)) + '-' + str(round(xCut[1],1)) + '_timebased' + '_raw.PNG'
            else:
                savename = varietyAndPlotnameAndDetail + '_' + str(round(xCut[0],1)) + '-' + str(round(xCut[1],1)) + '_else' + '_raw.PNG'
            ax.plot([xCut[0],xCut[0]],cutLine, color = 'orange', linewidth=1, linestyle="--") # start cut off line
            ax.plot([xCut[1],xCut[1]], cutLine, color = 'orange', linewidth=1, linestyle="--") # end cut off line
            #print("Initial plot show...")
            #plt.show()
            #print("Initial plot shown.")
            if not os.path.exists(documentationFolder):
              os.makedirs(documentationFolder) # Create documentationFolder because it does not exist
            print("did")
            plt.savefig(documentationFolder + '\\' + savename)
            print("did2")
            plt.close(block)
            print("xCut = ",xCut)
        return xCut # return start & end x (dis. or time) pts
    
    cid = fig.canvas.mpl_connect('button_press_event', click) # connects click event
    print("cid")

    #clicked = snap_cursor.click()
    #print('clicked', snap_cursor.click.coords)
    plt.show() # never getting past this
    #plt.show(block=False) # never getting past this
    print("did4")
    '''
    if encoderWorked == False and len(xCut) >=2:  # applu tCut values to xCut
        i=0
        while xCut[0]>timeElapsed[i]: # since the encoderFailed, xCut is initially the start and end time, and will be converted to tCut
            i = i+1
            print(i)
            
        j=0
        while xCut[1]>timeElapsed[j]: # 
            j = j+1
            print(j)
   
        disNew=[]
        disNew = [0]*len(timeElapsed) # initialize list length
        if disReferenced == True:
            disNew[i]=startDisRef # assign startDisRef value to the disNew list at the index of start time
            disNew[j]=endDisRef # assign EndDisRef value to the disNew list at the index of end time

            
            ## unused portion of disref will stay zeros
            n=i  
            k=0.000000000
            while n<=j:
                disNew[n]=startDisRef+k*(endDisRef-startDisRef)
                k=k+(1.000000000/(j-i))
                n=n+1
                print(n)

            while n<(len(time)-1):
                disNew[n] = 0 ## fill in the unused portion with zeros
                n=n+1
                print(n)
            print('troubleshoot 6 , time[i] = ', time[i])  
            print('i = ',i , ', j = ', j)    
            xCut = [startDisRef,endDisRef] # change xCut values to referenced startDisRef and endDisRef         
    '''
    print("encoderWorked = ",encoderWorked)
    print("disReferenced = ",disReferenced)
    if encoderWorked == True:
        return xCut
    elif encoderWorked == False and disReferenced == True:
        return xCut, disReferenced, disNew, i, j
    elif disReferenced == False:
        disNew = []
        return xCut, disReferenced, disNew, i, j
    print("Complete initial plot.")
    print("xCut, disReferenced, disNew,i,j = ", xCut, disReferenced, disNew,i,j)


###############################################################################

def choosePeaks(xData, forcePushed, xCut, varietyAndPlotnameAndDetail, encoderWorked, disReferenced, documentationFolder):
    
    def nearest_pt(pt): # get nearest dis index to starting pt in disCut
        idx = (np.abs(np.asarray(xData)- pt)).argmin()
        #print('idx ', idx)
        return idx

    startIdx = nearest_pt(xCut[0]) # starting index
    print('startIdx = ',startIdx) # , dis[startIdx])
    endIdx = nearest_pt(xCut[1])
    print('Closest distance pts: ', [xData[startIdx] , xData[endIdx]]) 
    xCenter = xData[startIdx:endIdx]
    fCenter = forcePushed[startIdx:endIdx]
    
    fig, ax = plt.subplots()
    fig.canvas.set_window_title('ChoosePeaks')
    fig.suptitle(varietyAndPlotnameAndDetail + '\nSelect Force Peaks, *click outside when done*')
    #fig.suptitle(varietyAndPlotnameAndDetail + '\nCut off edges: click start x pt, then end x pt.' + title3)
    #ax.set_title('*click outside when done*')
    ax.plot(xCenter, fCenter) # needed?
    maxPt = max(forcePushed)
    ax.set_xlim(min(xCenter)-5, max(xCenter)+5)
    ax.set_ylabel('Force/row (lbs.)')
    if encoderWorked == True or disReferenced == True:
        ax.set_xlabel('Distance (in.)')
    else:
        ax.set_xlabel('Time (s)')
            
    cursor = Cursor(ax) # create snap cursor object
    cursorMove = fig.canvas.mpl_connect('motion_notify_event', cursor.mouse_move) # update snap cursor upon mouse movement

    peaks = [] # force peaks
    xPeaks = [] # x (distance) pt of force peak
    def click(event): # get x coord once mouse is pressed
        y, x = event.ydata, event.xdata
        if y is None:
            fig.canvas.mpl_disconnect(cid)
            fig.canvas.mpl_disconnect(cursorMove)
            # auto save file
            # example: CF452_24hr_4_23-156_disref_clicks.PNG
            if encoderWorked == True:
                savename = varietyAndPlotnameAndDetail + '_' + str(round(xCut[0],1)) + '-' + str(round(xCut[1],1)) + '_clicks.PNG'
            elif encoderWorked == False and disReferenced == True:
                savename = varietyAndPlotnameAndDetail + '_' + str(round(xCut[0],1)) + '-' + str(round(xCut[1],1)) + '_disref' + '_clicks.PNG'
            elif encoderWorked == False and disReferenced == False:
                savename = varietyAndPlotnameAndDetail + '_' + str(round(xCut[0],1)) + '-' + str(round(xCut[1],1)) + '_timebased' + '_clicks.PNG'
            plt.savefig(documentationFolder + '\\' + savename)
            print("choosePeaks: ",savename)
            plt.close()
        else:
            # print('Force clicked = %1.2f at %1.2f' % (y, x)) # hide, CB
            peaks.append((y))
            xPeaks.append((x))
            ax.scatter(x, y, color='red')
            
        if peaks == []:
            quit()
            
        return peaks # return start & end dis pts
    
    cid = fig.canvas.mpl_connect('button_press_event', click) # connects click event    
    
    plt.show()
    #startDis = np.where(dis == disCut[0]) # get index
    print('xPeaks = ', xPeaks)
    return peaks, xPeaks

    # lists of numbers, from analysis choice
    xCutL = ['xCut(in)'] # Distance, analysis range
    tCutL = ['tCut(sec)']# Time, analysis range

# MAIN
class peakclick:
    # peaks_force,peaks_distance,peaks_time = peakclick.input(GUI.forcePushed,GUI.distanceTraveled,GUI.timeElapsed,varietyAndPlotnameAndDetail,address)
    def peakclick(forcePushed,distanceTraveled,timeElapsed,varietyAndPlotnameAndDetail,address,averageVelocity):
        documentationFolder = address + '\\' + 'documentation'
        if max(distanceTraveled) > 10: # Assess if the encoder worked or not. Assuems that if it worked, the max value would exceeed 1 inch.
            encoderWorked = True # 
        else: encoderWorked = False

        print('Encoder? ', encoderWorked)
        print('max(distanceTraveled) = ', str(max(distanceTraveled)))
        print(varietyAndPlotnameAndDetail)

        if useInitialPlot == True:
            if encoderWorked == False:
                xCut, disReferenced, disNew,i,j = initialPlot(distanceTraveled, forcePushed, timeElapsed, encoderWorked, varietyAndPlotnameAndDetail, documentationFolder,averageVelocity)
            elif encoderWorked == True:
                xCut = initialPlot(distanceTraveled, forcePushed, timeElapsed, encoderWorked,varietyAndPlotnameAndDetail, documentationFolder,averageVelocity)
                disReferenced = False
        else:
            xCut = [min(distanceTraveled),max(distanceTraveled)]
            tCut = [min(timeElapsed),max(timeElapsed)]
            disReferenced = False
            
        if encoderWorked == True:
            print('Distance cut at: ', xCut) # cut forcePushed and horz!!! 
            getPeaks = choosePeaks(distanceTraveled, forcePushed, xCut,varietyAndPlotnameAndDetail,encoderWorked, disReferenced,documentationFolder)
            print("getPeaks =",getPeaks) 
        elif encoderWorked == False and disReferenced == True:
            print('troubleshoot702')
            print('Distance cut at: ', xCut)
            getPeaks = choosePeaks(disNew, forcePushed, xCut,varietyAndPlotnameAndDetail,encoderWorked, disReferenced, documentationFolder)
            print("getPeaks =",getPeaks)
        else: #elif encoderWorked == False and disReferenced == False:
            xCut=tCut
            print('Time cut at: ', xCut)
            getPeaks = choosePeaks(timeElapsed, forcePushed, xCut,varietyAndPlotnameAndDetail,encoderWorked, disReferenced, documentationFolder)
            print("getPeaks =",getPeaks)

        saveCSV(varietyAndPlotnameAndDetail,address)
        return self.peaks_force,self.peaks_distance,self.peaks_time

    def saveCSV(self,varietyAndPlotnameAndDetail,address):
        print("not yet saved. develop.")
        filename_peaks_csv = address + "/" + varietyAndPlotnameAndDetail + "_peaks.csv"
        ''' write CSV'''
        data_peaks = [self.peaks_force,self.peaks_distance,self.peaks_time]
        columns_data_peaks = zip_longest(*data_peaks)
        with open(filename_peaks_csv,'w',newline='') as f:
            writer = csv.writer(f)
            writer.writerows(columns_data_peaks)
        ''' end: write CSV '''
        
    
    
