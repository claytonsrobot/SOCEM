%comparison_2020_2021_plotting.m
%% overview data
x20 = T21Socem.("EI-M (lbs*in^2)");
y = T20Socem.("EI-M (lbs*in^2)");
plot(x20,x20,'bo',y,y,'ro')
mean(T20Socem.("EI-M (lbs*in^2)"))
mean(T21Socem.("EI-M (lbs*in^2)"))
mean(T20Socem.("ave. height (in.)"))
mean(T21Socem.("Avg height (in)"))

%% Plot to see shared varieties
varietylist21 = unique(T21Socem.Variety);
varietylist20 = unique(T20Socem.name);
varietiesShared=intersect(string(varietylist20),string(varietylist21));
colormat = [0, 0.4470, 0.7410; 0.8500, 0.3250, 0.0980;0.9290, 0.6940, 0.1250;0.4940, 0.1840, 0.5560;77/255 190/255 70/255;0/255 0/255 0/255];
shapemat = string({'o','x','+','*','s','d','v','^','<','>','p','h','h'});
plot([0],[0],'*','Color',colormat(1,:))
hold on
plot([0],[0],'*','Color',colormat(2,:))
plot([0],[0],'*','Color',colormat(3,:))
plot([0],[0],'o','Color',[0,0,0])
plot([0],[0],'x','Color',[0,0,0])

for i=1:numel(varietiesShared)
x20=table2array(T20Socem(varietiesShared{i}==string(T20Socem.name),find(T20Socem.Properties.VariableNames==("EI-M (lbs*in^2)"))));
y20=table2array(T20Socem(varietiesShared{i}==string(T20Socem.name),find(T20Socem.Properties.VariableNames==("ave. height (in.)"))));

x21=table2array(T21Socem(varietiesShared{i}==string(T21Socem.Variety),find(T21Socem.Properties.VariableNames==("EI-M (lbs*in^2)"))));
y21=table2array(T21Socem(varietiesShared{i}==string(T21Socem.Variety),find(T21Socem.Properties.VariableNames==("Avg height (in)"))));
plot(x20,y20,shapemat(1),'Color',colormat(i,:))
plot(x21,y21,shapemat(2),'Color',colormat(i,:))
end

axis([4,18,4,18])
legend(varietiesShared{1},varietiesShared{2},varietiesShared{3},'2020', '2021','Location','northwest')

title('SOCEM EI, 2020 and 2021 Comparison, Repeated Varieties')
xlabel('EI-M (lbs*in^2)')
ylabel('Avg height (in)')

%% plot all SOCEM data from both years
hold off
plot(T20Socem.("EI-M (lbs*in^2)"),T20Socem.("ave. height (in.)"),shapemat(1),'Color',colormat(1,:))
hold on
plot(T21Socem.("EI-M (lbs*in^2)"),T21Socem.("Avg height (in)"),shapemat(2),'Color',colormat(1,:))
title('SOCEM EI, 2020 and 2021 Comparison')
xlabel('EI-M (lbs*in^2)')
ylabel('Avg height (in)')

legend('2020', '2021','Location','northwest')

%% plot all SOCEM data from both years
hold off
plot(EI_SOCEM2020,AveEI_Instron2020,'*','Color',colormat(1,:))
hold on
plot(EI_SOCEM2020_barleyC,AveEI_Instron2020_barleyC,'s','Color',colormat(6,:))
plot(EI_SOCEM2021b,AveEI_Instron2021,'o','Color',colormat(2,:))


title('SOCEM EI vs Instron EI, 2020 and 2021 Comparison')
xlabel('SOCEM EI-M (N*mm^2)')
ylabel('Instron AvgEI (N*mm^2)')


axis([0,7*10^4,0,5*10^4])

[bmc,m,b,c,Rsq20,RMSE,SSE,lm,f0,string2020] = linearFitting(EI_SOCEM2020,AveEI_Instron2020,1,1,0,colormat(1,:));
hold on
[bmc,m,b,c,Rsq20_barley,RMSE,SSE,lm,f0,string2020_barley] = linearFitting(EI_SOCEM2020_barleyC,AveEI_Instron2020_barleyC,1,1,0,colormat(6,:));
[bmc,m,b,c,Rsq21,RMSE,SSE,lm,f0,string2021] = linearFitting(EI_SOCEM2021b,AveEI_Instron2021,1,1,0,colormat(2,:));

legend(strcat('Wheat 2020 (',sprintf('%i',numel(EI_SOCEM2020)),' plots)'),strcat('Barley 2020 (',sprintf('%i',numel(EI_SOCEM2020_barleyC)),' plots)'), strcat('Wheat 2021 (',sprintf('%i',numel(EI_SOCEM2021b)),' plots)'),'Best Fit Wheat 2020','Best Fit Barley 2020','Best Fit Wheat 2021','Location','northwest')
str2020 = {'2020 Wheat data:'; 'f(x) = m*x + b'; string2020{2}; extractBefore(string2020{3},20)};
str2020_barley = {'2020 Barley data:'; 'f(x) = m*x + b'; string2020_barley{2}; extractBefore(string2020_barley{3},20)};
str2021 = {'2021 Wheat data:';'f(x) = m*x + b'; string2021{2}; extractBefore(string2021{3},20)};
ha20=annotation(gcf,'textbox',[0.18,0.13,1,1],'String',str2020,'EdgeColor','none','FitBoxToText','on','verticalalignment', 'bottom', 'color','k');
ha20_barley=annotation(gcf,'textbox',[0.37,0.13,1,1],'String',str2020_barley,'EdgeColor','none','FitBoxToText','on','verticalalignment', 'bottom', 'color','k');
ha21=annotation(gcf,'textbox',[0.55,0.13,1,1],'String',str2021,'EdgeColor','none','FitBoxToText','on','verticalalignment', 'bottom', 'color','k');

%% plot all SOCEM data from both years, in combined vectors
hold off
plot([EI_SOCEM2020;EI_SOCEM2021b],[AveEI_Instron2020;AveEI_Instron2021],'*','Color',colormat(1,:))
hold on


title('SOCEM EI vs Instron EI, 2020 and 2021 Comparison')
xlabel('SOCEM EI-M (N*mm^2)')
ylabel('Instron AvgEI (N*mm^2)')


axis([0,7*10^4,0,5*10^4])

[mbc,m,b,c,Rsq20,RMSE,SSE,lm,f0,stringcombo] = linearFitting([EI_SOCEM2020;EI_SOCEM2021],[AveEI_Instron2020;AveEI_Instron2021],1,1,0);
hold on

legend('2020 and 2021 plots','Best fit, combined','Location','northwest')
strcombo = {'combined data:'; 'f(x) = m*x + b'; stringcombo{2}; extractBefore(stringcombo{3},20)};
hacombo=annotation(gcf,'textbox',[0.18,0.13,1,1],'String',strcombo,'EdgeColor','none','FitBoxToText','on','verticalalignment', 'bottom', 'color','k');

%% plot all SOCEM data from both years, in combined vectors, with barley
hold off
plot([EI_SOCEM2020;EI_SOCEM2020_barleyC;EI_SOCEM2021b],[AveEI_Instron2020;AveEI_Instron2020_barleyC;AveEI_Instron2021],'*','Color',colormat(1,:))
hold on
numpoints=numel([AveEI_Instron2020;AveEI_Instron2020_barleyC;AveEI_Instron2021]);

title('SOCEM EI vs Instron EI, 2020 and 2021 Comparison, Wheat and Barley')
xlabel('SOCEM EI-M (N*mm^2)')
ylabel('Instron AvgEI (N*mm^2)')


axis([0,7*10^4,0,5*10^4])

[mbc,m,b,c,Rsq20,RMSE,SSE,lm,f0,stringcombo] = linearFitting([EI_SOCEM2020;EI_SOCEM2020_barleyC;EI_SOCEM2021b],[AveEI_Instron2020;AveEI_Instron2020_barleyC;AveEI_Instron2021],1,1,0,colormat(1,:));
hold on

legend(strcat('2020 and 2021 plots, (',string(numpoints),' plots)'),'Best fit, combined','Location','northwest')
strcombo = {'combined data:'; 'f(x) = m*x + b'; stringcombo{2}; extractBefore(stringcombo{3},20)};
hacombo=annotation(gcf,'textbox',[0.54,0.13,1,1],'String',strcombo,'EdgeColor','none','FitBoxToText','on','verticalalignment', 'bottom', 'color','k');

