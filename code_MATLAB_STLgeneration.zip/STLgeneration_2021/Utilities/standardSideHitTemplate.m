% standardSideHitTemplate.m
% Author: Clayton Bennett
% Date: April 21, 2022
% Purpose: Assume standard row width and interrow width, create 3D plots
% without side hit data
function [sideDistance_squareForm,sideForce_squareForm] = standardSideHitTemplate()
sideDistance_squareForm =[0, 0, 5, 5, 10, 10, 15, 15, 20, 20, 25, 25, 30];
sideForce_squareForm = [0, 1,   1, 0, 0, 1,    1, 0,   0, 1,  1, 0, 0];
sideForce_squareForm = (1/3).*sideForce_squareForm;




