'''
fileSort_timeBasedVsDistanceBased
Author: Clayton Bennett
Created: 14 February 2022
Last edited:  14 February 2022

Purpose:
    Before running SOCEM_Data_Analysis_Vn.py, identify which files the encoder worked and did not work for.
    Then, figure out which plots are represented by files in both folders.
    For these plots, distance values can be determined from the encoderWorkedYes files and applied to the encoderWorkedNo files.

'''

# needed libraries
import math
import pandas as pd
from pandas import ExcelFile
from pandas import ExcelWriter
# import peakutils
import matplotlib.pyplot as plt
from matplotlib.widgets import Cursor
# from peakutils.plot import plot as pplot
import numpy as np
from numpy import trapz
#import scipy
#from scipy import simps
from datetime import date
import os
import shutil
import xlsxwriter
#from BuildFolders import buildfolders

fileSort = 'y' # 'y' or 'n'

topFolder = r'E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\Data - Instron and SOCEM\SOCEM_DATA_2021'
analysisDirectory =  '\\August5,6,10,13_CorrectedHeights_FirstHits_Copy\\' # EDIT HERE
folderToProcess = topFolder + analysisDirectory + 'cleanRaw' # moved out
addressYes = topFolder + analysisDirectory + 'encoderWorkedYes' # Distance based
addressNo = topFolder + analysisDirectory + 'encoderWorkedNo' # Time based
#buildfolders(analysisDirectory)
# import each file in folder and check if max distance value was above 1. If yes, assume encoder worked, if no,assume it did not.

plotHeightSpreadsheet = r'E:\Instron Wheat Testing 2021\plotHeights2021.xlsx'
df2 = pd.read_excel(plotHeightSpreadsheet)
varietyList = df2.iloc[0]
varietyList = varietyList.to_numpy().tolist()
plotList = df2.iloc[1]
plotList = plotList.to_numpy().tolist()

plotnameListYes = []
plotnameListNo = []
plotnameListOverlap = []



# MAIN FUNCTION

if fileSort == 'y':
    os.chdir(addressYes)
    [os.remove(f) for f in os.listdir()]
    os.chdir(addressNo)
    [os.remove(f) for f in os.listdir()]

for filename in os.listdir(folderToProcess): # loop through files in folder

    file = str(folderToProcess+'/'+filename)
    print('\n' + file)    
    testplotname = os.path.basename(os.path.normpath(filename))
    print(testplotname)
    plotnameText = filename.split("_",2)[1] # works for RAW files only
    plotnameText = plotnameText.replace(".xlsx","")
    plotnameText = plotnameText.upper()
    plotnamesList = plotList
    plotIdx = plotnamesList.index(plotnameText) # where does the filename match the concat of 
    varietyText = varietyList[plotIdx] 
    print(varietyText + '\n' + plotnameText)
    varietyAndPlotnameText = (varietyText + ', ' + plotnameText)
    df = pd.read_excel(file) # convert Excel into pandas df
    dis = np.array(df['Distance (in.)'])

    if max(dis) > 1: # 
        encoderWorked = 'y' # 
    else: encoderWorked = 'n'

    print('Encoder? ', encoderWorked)
    print('max(dis) = ', str(max(dis)))
    if encoderWorked == 'y': # or distReferenced == 'y':
        plotnameListYes.append(str(plotnameText))
        if fileSort == 'y':
            #os.rename(file, addressYes+'/'+filename) # move file
            shutil.copy(file, addressYes)
            print('SOCEM data file copied to encoderWorkedYes folder.')
    elif encoderWorked == 'n':
        plotnameListNo.append(str(plotnameText))
        if fileSort == 'y':
            #os.rename(file, addressNo+'/'+filename) # move file
            shutil.copy(file, addressNo)
            print('SOCEM data file copied to encoderWorkedNo folder.')


plotnameListOverlap = sorted(list(set(plotnameListYes).intersection(plotnameListNo)))
plotnameListNoDistanceData = sorted(list(set(plotnameListNo).difference(plotnameListYes)))
plotnameListAllDistanceData = sorted(list(set(plotnameListYes).difference(plotnameListNo)))

print('\n' + "These plots are represented in both the encoderWorkedYes and the encoderWorkedNo folders:")
print(str(plotnameListOverlap))
print('\n' + 'These plots have no encoder data:')
print(str(plotnameListNoDistanceData))
print('\n' + 'These plots have complete distance data:')
print(str(plotnameListAllDistanceData))


