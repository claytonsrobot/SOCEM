Designer: Clayton bennett
Fabrication method: Laser cut wood
Purpose: This part is meant to store the Arduino and the load cell for the SOCEM, while also supporting a storage box that size on top of this wooden cabinet.

Wood parts differ in thickness. All parts expect one are 1/4" thick. The midPlate is 1/8" thick.

Fabrication method: Lasercut wood, assembled with wood glue, finished with wood stain.
To lasercut, import these DXF files into CorelDraw (in the Rapid Prototpying lab Gauss-Johnson, UIdaho)
Or, import the DXF files into some other software interface that allows you to prepare for laser cutting.

Parts include:

1/4" thick:
(x1) base_spineContact_Z-plane
(x1) top_storageBoxMount_Z-plane
(x1) sideWalls_Y-plane_noSlot
(x1) sideWalls_Y-plane_slot
(x1) spineBoltBoard_X-plane 
(x2) support_triangle_Y-plane
(x2) support_triangle_Y-plane_backWall

1/8" thick:
(x1) midPlate_drawerSupport
Drawer components, shown separately.


The existing DXF files can be used, or new ones can be generated using Solidworks.
The dimensions of the Solidpart files are tied to the values in the equations text file: dimensions_keyboardTray.txt
TAKE HEED! The dimensions very much rely on the thickness of the wood.

You may, however, use wood of a different thickness, though you will probably have to troubleshoot the solidworks files.
Change the "thickness_board" value to whatever material you have.
Before or after doing this, open your solidworks assembly file.
Update the assembly file, to adjust the parts.
Right click on each part to export a new DXF file for each part.