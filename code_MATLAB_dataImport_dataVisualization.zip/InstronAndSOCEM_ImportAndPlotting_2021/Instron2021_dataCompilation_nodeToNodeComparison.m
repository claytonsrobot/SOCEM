 Author: Clayton Bennett
% Date 31 January 2022
% Title: Instron2021_dataCompilation_nodeToNodeComparison.m
% Description: Pulls in overview files for stem by stem data analysis.
%   Goal: Box plots to show spread from each variety.
%   Pulls in diameter data for each stem.
format compact
%% Import data

directory_script = 'D:\Instron Wheat Testing 2021\MatlabCode';
directory_data = 'D:\Instron Wheat Testing 2021\InstronData2021\Node Comparison\'; % overview files and height data lives here
diameterSpreadsheet = 'D:\Instron Wheat Testing 2021\DiameterMeasurements_01312022.xlsx'; % most recent diameter measurement file
varietyNamesSpreadsheet = 'D:\Instron Wheat Testing 2021\varietyNames2021.xlsx';
plotHeightsSpreadsheet = 'D:\Instron Wheat Testing 2021\plotHeights2021.xlsx';

% If '\' is not input by the user as the final character in the directory
% assignment, add  it.
% 
if (directory_data(end)~='\')
    directory_data = strcat(directory_data,'\');
end

if (directory_script(end)~='\')
    directory_script = strcat(directory_script,'\');
end
% %%

cd(directory_data)

list_csvfiles = dir('*.csv');
n_plots = numel(list_csvfiles)'; % How many overview files are there in the directory?
n_nodes_guess = n_plots*10;
idxs_names = zeros(n_plots,1);
for i=1:n_plots
    idxs_names(i)=i*6+1-6;
end
tc=struct2cell(list_csvfiles);
names_overviewfiles = tc(idxs_names');
%% Prepare the table, T
varnames = {'i','j','Stem','Node','Variety','Plot','OverviewFile','Stiffness','Strength',...
    'Modulus','DisplacementAtMaxLoad','EI','NodeMajorDiameter','NodeMinorDiameter',...
    'InternodeMajorDiameter','InternodeMinorDiameter',...
    'NodeArea','InternodeArea','NodeAreaHollow','InternodeAreaHollow','Volume','VolumeHollow',...
    'RawDisplacement','RawForce',....
    'PlotHeightArray','BreakType','StiffnessChoice','Notes'};

T = cell2table(cell(n_nodes_guess,numel(varnames)), 'VariableNames', varnames); % Create table T.
T.i = nan(height(T),1); % Prepare column "i" to be numbers.
T.j = nan(height(T),1); % Prepare column to be numbers.
T.Stem = nan(height(T),1); % Prepare column "Stem" to be numbers.
T.Node = nan(height(T),1); % Prepare column to be numbers.
T.Variety = strings([height(T),1]); % Prepare column to be strings.
T.Plot = strings([height(T),1]); % Prepare column "Plot" to be strings.
T.OverviewFile = strings([height(T),1]); % Prepare column "OverviewFile" to be strings.
T.Stiffness = nan(height(T),1); % Prepare column "LoadDeflection" to be numbers.
T.Strength = nan(height(T),1); % Prepare column "MaxLoad" to be numbers.
T.Modulus = nan(height(T),1); % Prepare column to be numbers.
T.DisplacementAtMaxLoad = nan(height(T),1); % Prepare column "DisplacementAtMaxLoad" to be numbers.
T.NodeMajorDiameter = nan(height(T),1); % mm
T.NodeMinorDiameter = nan(height(T),1); % mm
T.InternodeMajorDiameter = nan(height(T),1); % mm
T.InternodeMinorDiameter = nan(height(T),1); % mm
T.NodeArea = nan(height(T),1); % mm^2
T.InternodeArea = nan(height(T),1); % mm^2
T.NodeAreaHollow = nan(height(T),1); % mm^2
T.InternodeAreaHollow = nan(height(T),1); % mm^2
T.Volume = nan(height(T),1); % mm^3
T.VolumeHollow = nan(height(T),1); % mm^3
%T.RawDisplacement = nan(height(T),1);
%T.RawForce = nan(height(T),1);
%T.PlotHeightsArray = nan(height(T),1);
T.EI = nan(height(T),1);
T.BreakType = strings([height(T),1]);
T.StiffnessChoice = strings([height(T),1]);
T.Notes = strings([height(T),1]);
%% Import overview data, and populate stem, overviewfile, and plot

handle_waitbar_overviewFiles=waitbar(0,strcat('Data is being imported from ',string(n_plots),' overview Instron files. Computer speed, go!'));

idx=1;
for j=1:n_plots
    
    [ndata_notUsed, text_notUsed, c_overviewDataPullIn] = xlsread(strcat(directory_data,string(names_overviewfiles(j)))); %c is of class cell
    fprintf('%d.', j)
    waitbar(j/n_plots,handle_waitbar_overviewFiles)

            clear StiffnessChoicesArray StiffnessSlopesArray
            nodeCountPerPlot=length(c_overviewDataPullIn(7:end,13));
            
            OverviewFile = string(names_overviewfiles(j));
            Plot = eraseBetween(OverviewFile,min(strfind(OverviewFile,'_')),strlength(OverviewFile)); %for non-cyclic tests
            Plot = extractAfter(Plot,1);
            
            StiffnessChoicesArray = c_overviewDataPullIn(7:end,20);
            try
                StiffnessSlopesArray = cell2mat(c_overviewDataPullIn(7:end,[3:6,8:11]));
            catch
                StiffnessSlopesArray = cell2mat(c_overviewDataPullIn(7:end,3));
                msg = 'Numbers missing in slope array. Default to auto slope.'
                j
            end
            nodeCountPerPlot=length(c_overviewDataPullIn(7:end,13));
            StiffnessSlopesList = zeros(nodeCountPerPlot,1);
            
            for n_node=1:nodeCountPerPlot
                if string(StiffnessChoicesArray(n_node,:))==string('Auto slope')
                    StiffnessSlopesList(n_node) = StiffnessSlopesArray(n_node,1);
                elseif StiffnessChoicesArray(n_node,:)==string('Average all')
                    StiffnessSlopesList(n_node) = mean(StiffnessSlopesArray(n_node,:));
                elseif StiffnessChoicesArray(n_node,:)==string('2nd lowest')
                    StiffnessSlopesList(n_node) = max(mink(StiffnessSlopesArray(n_node,:),2));
                else 
                    StiffnessSlopesList(n_node) = StiffnessSlopesArray(n_node,1);
                end
            end
            
            i_rangeStart=idx;
            i_rangeEnd=idx+nodeCountPerPlot-1;
            idx=idx+nodeCountPerPlot;
            T.j(i_rangeStart:i_rangeEnd)=j;
            T.Plot(i_rangeStart:i_rangeEnd) = Plot;
            T.OverviewFile(i_rangeStart:i_rangeEnd)=OverviewFile;
            T.Stiffness(i_rangeStart:i_rangeEnd) = StiffnessSlopesList; % N/mm
            T.Strength(i_rangeStart:i_rangeEnd) = cell2mat(c_overviewDataPullIn(7:end,13)); %N, max forces from each stalk
            T.Modulus(i_rangeStart:i_rangeEnd) = T.Stiffness(i_rangeStart:i_rangeEnd).*0.9182; %0.9182 comes from assumptions made about wall thickness and standard diameter, which is not accurate. Diameter measurentsd were recorded.
            T.Stem(i_rangeStart:i_rangeEnd) = string(c_overviewDataPullIn(7:end,18)); %stem
            T.Node(i_rangeStart:i_rangeEnd) = string(c_overviewDataPullIn(7:end,19)); %node
            T.BreakType(i_rangeStart:i_rangeEnd) = string(c_overviewDataPullIn(7:end,17)); %breaktype
            T.StiffnessChoice(i_rangeStart:i_rangeEnd) = string(c_overviewDataPullIn(7:end,20)); 
            T.Notes(i_rangeStart:i_rangeEnd) = string(c_overviewDataPullIn(7:end,21)); %notes 
            
end
close(handle_waitbar_overviewFiles)

n_nodes = i_rangeEnd; % after loop os complete, the number of the final row is the count of total rows.
T((n_nodes+1):end,:)=[];
section6of7 = "Overview values have been imported."
%% Import variety names
[ndata_notUsed, text_notUsed, c_varietyDataPullIn] = xlsread(plotHeightsSpreadsheet); %c is of type cell 
columnIdx = 0;
size_c = size(c_varietyDataPullIn);
for i=1:n_nodes
    for k=1:size_c(2)
        if T.Plot(i)==string(c_varietyDataPullIn(3,k))
            columnIdx=k;
        end
    end
%     if not(columnIdx==0)
         T.Variety(i) = cell2mat(c_varietyDataPullIn(2,columnIdx));
%     end
    
end
% reorder table to organize by Variety names
T=sortrows(T,5,'ascend'); %sort by variety name
%% assign T.i, after reordering for variety names

for i=1:n_nodes
    T.i(i)=i;
end
%% Import diameter data
 
[ndata_notUsed, text_notUsed, c_diameterDataPullIn] = xlsread(diameterSpreadsheet); %c is of type cell 
cellblock=0;
size_c = size(c_diameterDataPullIn);
for i=1:n_nodes
    for k=1:size_c(1)
        if T.Plot(i)==string(c_diameterDataPullIn(k,2))
            cellblock=k;
        end
    end
    nodeCountPerPlot=sum(T.j==T.j(i));
    diameterMat = cell2mat(c_diameterDataPullIn(cellblock:(cellblock+nodeCountPerPlot-1),15:18));
    
    i_rangeStart=find(T.j==T.j(i),1,'first');
    i_rangeEnd=i_rangeStart+nodeCountPerPlot-1;
    T.NodeMajorDiameter(i_rangeStart:i_rangeEnd) = diameterMat(:,1); %
    T.NodeMinorDiameter(i_rangeStart:i_rangeEnd) = diameterMat(:,2); %
    T.InternodeMajorDiameter(i_rangeStart:i_rangeEnd) = diameterMat(:,3); %
    T.InternodeMinorDiameter(i_rangeStart:i_rangeEnd) = diameterMat(:,4); %

end
%% Modulus of elasticity calculation, based on diameter
% Modulus (Auto Young's) [N/mm^2] is calculated from the Auto Slope [N/mm] and assumed specimen dimensions of 3 mm OD, 0.4 mm wall thickness, 8 mm height/span.

T.EI=T.Stiffness.*(80^3)/48; % N*
%% Area and Volume Calcuations, elliptical
%T.NodeArea=(T.NodeMajorDiameter./2).*(T.NodeMinorDiameter./2).*pi;
%T.InternodeArea=(T.InternodeMajorDiameter./2).*(T.InternodeMinorDiameter./2).*pi;
nodeWallThicknessPercentGuess = .55;  % based on how much air vs how much stem
internodeWallThicknessPercentGuess = .12; 
%T.NodeAreaHollow=((T.NodeMajorDiameter-2.*T.NodeMajorDiameter.*nodeWallThicknessPercentGuess)./2).*((T.NodeMinorDiameter-2.*T.NodeMinorDiameter.*nodeWallThicknessPercentGuess)./2).*pi; % Assumes wall thicknesses are a quarter of the node diameter
%T.NodeAreaHollow=((T.InternodeMajorDiameter-2.*T.InternodeMajorDiameter.*internodeWallThicknessPercentGuess)./2).*((T.InternodeMinorDiameter-2.*T.InternodeMinorDiameter.*internodeWallThicknessPercentGuess)./2).*pi; % Assumes wall thicknesses are a quarter of the node diameter
% heightVolumeAssumed = 5; %mm
%[T.Volume(i),T.NodeArea(i)] = volumenode(5,4.5,3.5,3.2,1,1); % calculus
for i=1:height(T)
[T.Volume(i),T.VolumeHollow(i),T.NodeArea(i),T.NodeAreaHollow(i),T.InternodeArea(i),T.InternodeAreaHollow(i)] = volumenode(T.NodeMajorDiameter(i),T.NodeMinorDiameter(i), T.InternodeMajorDiameter(i),T.InternodeMinorDiameter(i),nodeWallThicknessPercent,internodeWallThicknessPercent); % calculus
end
% 
% start by assuming wall thicknesses are the same
%% Import plot heights

columnIdx = 0;
size_c = size(c_varietyDataPullIn);
for i=1:n_nodes
    for k=1:size_c(2)
        if T.Plot(i)==string(c_varietyDataPullIn(3,k)) % there is only one c_varietyDataPullIn, which has already been imported
            columnIdx=k;
        end
    end
    Heights = cell2mat(c_varietyDataPullIn(4:11,columnIdx));
    T.PlotHeightArray(i)=mat2cell(Heights,length(Heights));
    
end
%% Import raw data arrays from individual data files
% This is slow, because each file must be opened, recorded, and closed. That's okay.
% This import method should work for all individual Instron files.

handle_waitbar_individualFiles=waitbar(0,strcat('Arrays are being imported from ',string(height(T)),'individual Instron files. It is slow. But it is probably faster than you.')); % develop this more

for i = 1:height(T)

    waitbar(i/height(T),handle_waitbar_individualFiles)
    individualFileFolder = replace(T.OverviewFile(i),"2.csv","Exports\");
    individualFileName = replace(T.OverviewFile(i),"_2",strcat("_",string(T.Stem(i))));
    stringcatIndividualFileName = strcat(directory_data,individualFileFolder,individualFileName);
    [ndata_notUsed, text_notUsed, c_rawDataPullIn] = xlsread(stringcatIndividualFileName); %c is of type cell 
    
    % %% Remove first value from each imported column.
    Displacement = cell2mat(c_rawDataPullIn(3:end,2));
    Force = cell2mat(c_rawDataPullIn(3:end,3));
    %Time = cell2mat(c_rawDataPullIn(3:end,1)); % Not necessary to pull in time
    
    
    for k=1:length(Force)
        if Force(k)==max(Force)
            rowIdx=k;
        end
    end
    T.DisplacementAtMaxLoad(i)=Displacement(rowIdx);
    
    % %% Store entire arrays for each Instron test into each row j of table T.
    T.RawDisplacement(i)=mat2cell(Displacement,length(Displacement));
    T.RawForce(i)=mat2cell(Force,length(Force));
    %T.Time(i)=mat2cell(Time,length(Time));
    
end

close(handle_waitbar_individualFiles)

%  Up to this point, most things apply to importing only individual
% %%      files.
section4of7 = "Arrays have been imported from individual files."

% %% Find and assign DisplacementAtMaxLoad
% for i = 1:height(T)
%     Force=T.RawForce(i);
%     Displacement = T.RawDisplacement(i);
%     %Force=T.Force(i);
%     %Displacement = T.Displacement(i);
%     for k=1:length(Force)
%         if Force==max(Force)
%             rowIdx=k;
%         end
%     end
%     T.DisplacementAtMaxLoad(i)=Displacement(rowIdx);
% end
%% Descriptions and units, table T
% %% Is scalable only if in metric and these are the expected variables. +*#*#*#*#*#*+
T.Properties.VariableUnits = {'','','','', '', '','','N/mm','N','N/mm^2','mm','N*mm','mm','mm','mm','mm','mm^2','mm^2','mm^2','mm^2','mm^3','mm^3','mm','N','mm','','',''};
%T.Properties.VariableDescriptions{'Time'} = 'Array of time values during INSTRON test.';
T.Properties.VariableDescriptions{'RawDisplacement'} = 'Array of displacement values during INSTRON test.';
T.Properties.VariableDescriptions{'RawForce'} = 'Array of force values during INSTRON test.';
T.Properties.VariableDescriptions{'Stiffness'} = 'Slopes were carefully chosen from assessment of 9 linear elastic region fits. Generally the Auto slope was used.';
T.Properties.VariableDescriptions{'Modulus'} = 'Automatically generated overview value based on INSTRON method. This number requires an input for cross sectional area of the plant, which was not measured. Hypothetically, a coefficient can be discovered for adjustment, based on the span of the INSTRON at the time of testing.';
T.Properties.VariableDescriptions{'Strength'} = 'Max load.';
T.Properties.VariableDescriptions{'EI'} = 'EI=Stiffness*(TestSpan^3)/48, where Testspan = 80 mm.';
T.Properties.VariableDescriptions{'DisplacementAtMaxLoad'} = 'Displacement at max load.';
T.Properties.VariableDescriptions{'BreakType'} = 'Choices: CRUSHED, SNAPPED, or SPLINTERED.';
T.Properties.VariableDescriptions{'Variety'} = 'Genetic variety. 4 plots per variety were tested when possible, in 2021.';
T.Properties.VariableDescriptions{'Plot'} = 'Indicates reference location of experimental plot within the Baldus Rd field, 2021.';
T.Properties.VariableDescriptions{'NodeMajorDiameter'} = 'Node diameter in direction of Instron travel.';
T.Properties.VariableDescriptions{'NodeMinorDiameter'} = 'Node diameter in direction perpindicular to Instron travel.';
T.Properties.VariableDescriptions{'InternodeMajorDiameter'} = 'Internode diameter in direction of Instron travel.';
T.Properties.VariableDescriptions{'InternodeMinorDiameter'} = 'Internode diameter in direction perpindicular to Instron travel.';
T.Properties.VariableDescriptions{'NodeArea'} = 'Elliptical area for Node, if not hollow';
T.Properties.VariableDescriptions{'InternodeArea'} = 'Elliptical area for Internode, if not hollow';
T.Properties.VariableDescriptions{'Volume'} = 'Volume between Node and Internode ellipses, if not hollow.';
T.Properties.VariableDescriptions{'StiffnessChoice'} = 'Slopes were carefully chosen from assessment of 9 linear elastic region fits: Average all, 2nd lowest, Auto slope, Max, Min. Generally the Auto slope was used.';
%% Create Table Tn for Node Comparison Analysis
node1Count=sum(T.Node==1);
node2Count=sum(T.Node==2);
node3Count=sum(T.Node==3);
comparisonCount = node1Count + node3Count; % includes comparisons between Node1,Node2 and Node2,Node3

% Create new table for node comparison, with # of stems (not # of nodes) as the # of rows
varnames = {'is','j','Stem','NodeRelation','Variety','Plot','OverviewFile','StiffnessDifference',...
'StiffnessPercentDifference','StrengthDifference','StrengthPercentDifference',...
'ModulusDifference','ModulusPercentDifference','EIDifference','EIPercentDifference',...
'DisplacementAtMaxLoadDifference','DisplacementAtMaxLoadPercentDifference',...
'NodeMajorDiameterDifference','NodeMajorDiameterPercentDifference','NodeMinorDiameterDifference',...
'NodeMinorDiameterPercentDifference','InternodeMajorDiameterDifference',...
'InternodeMajorDiameterPercentDifference','InternodeMinorDiameterDifference',...
'InternodeMinorDiameterPercentDifference','BreakTypeVector',...
'StifferThicker'}; %stiffferThcker = color of scatterSquare
Tn = cell2table(cell(comparisonCount,numel(varnames)), 'VariableNames', varnames); % Create table Tn.
Tn.is = nan(height(Tn),1); % Prepare column to be numbers.
Tn.j = nan(height(Tn),1); % Prepare column to be numbers.
Tn.Stem = nan(height(Tn),1); % Prepare column to be numbers.
Tn.NodeRelation = strings([height(Tn),1]); % Prepare column to be numbers.
Tn.Variety = strings([height(Tn),1]); % Prepare column to be strings.
Tn.Plot = strings([height(Tn),1]); % Prepare column to be strings.
Tn.OverviewFile = strings([height(Tn),1]); % Prepare column to be strings.
Tn.StiffnessDifference = nan(height(Tn),1); % Prepare column to be numbers.
Tn.StiffnessPercentDifference = nan(height(Tn),1); % Prepare column to be numbers.
Tn.StrengthDifference = nan(height(Tn),1); % Prepare column to be numbers.
Tn.StrengthPercentDifference = nan(height(Tn),1); % Prepare column to be numbers.
Tn.ModulusDifference = nan(height(Tn),1); % Prepare column to be numbers.
Tn.ModulusPercentDifference = nan(height(Tn),1); % Prepare column to be numbers.
Tn.EIDifference = nan(height(Tn),1); % Prepare column to be numbers.
Tn.EIPercentDifference = nan(height(Tn),1); % Prepare column to be numbers.
Tn.DisplacementAtMaxLoadDifference = nan(height(Tn),1); % Prepare column to be numbers.
Tn.DisplacementAtMaxLoadPercentDifference = nan(height(Tn),1); % Prepare column to be numbers.
Tn.NodeMajorDiameterDifference = nan(height(Tn),1); % Prepare column to be numbers.
Tn.NodeMajorDiameterPercentDifference = nan(height(Tn),1); % Prepare column to be numbers.
Tn.NodeMinorDiameterDifference = nan(height(Tn),1); % Prepare column to be numbers.
Tn.NodeMinorDiameterPercentDifference = nan(height(Tn),1); % Prepare column to be numbers.
Tn.InternodeMajorDiameterDifference = nan(height(Tn),1); % Prepare column to be numbers.
Tn.InternodeMajorDiameterPercentDifference = nan(height(Tn),1); % Prepare column to be numbers.
Tn.InternodeMinorDiameterDifference = nan(height(Tn),1); % Prepare column to be numbers.
Tn.InternodeMinorDiameterPercentDifference = nan(height(Tn),1); % Prepare column to be numbers.
Tn.BreakTypeVector = strings([height(Tn),1]); % Prepare column to be strings.
Tn.StifferThicker = nan(height(Tn),1); % Prepare column to be numbers. Color.
%% Populate comparison table, Tn
StiffnessTaper_Node1to2 = zeros(node1Count,1);
StiffnessTaperPercentage_Node1to2 = zeros(node1Count,1);
StrengthTaper_Node1to2 = zeros(node1Count,1);
StrengthTaperPercentage_Node1to2 = zeros(node1Count,1);
NodeMajorDiameterTaper_Node1to2 = zeros(node1Count,1);
NodeMajorDiameterTaperPercentage_Node1to2 = zeros(node1Count,1);

k=1;
is=1;
for i=1:(n_nodes-1)
    if T.Node(i)==1 && T.Node(i+1)==2 && T.Stem(i) == T.Stem(i+1)
        Tn.is(is) = is;
        Tn.j(is) = T.j(i);
        Tn.Stem(is) = T.Stem(i);
        Tn.NodeRelation(is) = 'Node1,Node2';
        Tn.Variety(is) = T.Variety(i);
        Tn.Plot(is) = T.Plot(i);
        Tn.OverviewFile(is) = T.OverviewFile(i);
        Tn.StiffnessDifference(is) = T.Stiffness(i) - T.Stiffness(i+1);
        Tn.StiffnessPercentDifference(is) = (T.Stiffness(i) - T.Stiffness(i+1))/T.Stiffness(i);
        Tn.StrengthDifference(is) = T.Strength(i) - T.Strength(i+1);
        Tn.StrengthPercentDifference(is) = (T.Strength(i) - T.Strength(i+1))/T.Strength(i);
        Tn.ModulusDifference(is) = T.Modulus(i) - T.Modulus(i+1);
        Tn.ModulusPercentDifference(is) = (T.Modulus(i) - T.Modulus(i+1))/T.Modulus(i);
        Tn.EIDifference(is) = T.EI(i) - T.EI(i+1);
        Tn.EIPercentDifference(is)  = (T.EI(i) - T.EI(i+1))/T.EI(i);
        Tn.NodeMajorDiameterDifference(is) = T.NodeMajorDiameter(i) - T.NodeMajorDiameter(i+1);
        Tn.NodeMajorDiameterPercentDifference(is) = (T.NodeMajorDiameter(i) - T.NodeMajorDiameter(i+1))/T.NodeMajorDiameter(i);
        Tn.BreakTypeVector(is) =  strcat(T.BreakType(i),',',T.BreakType(i+1));
        StiffnessTaper_Node1to2(k) = T.Stiffness(i) - T.Stiffness(i+1);
        StiffnessTaperPercentage_Node1to2(k) = (T.Stiffness(i) - T.Stiffness(i+1))/T.Stiffness(i);
        StrengthTaper_Node1to2(k) = T.Strength(i) - T.Strength(i+1);
        StrengthTaperPercentage_Node1to2 = (T.Strength(i) - T.Strength(i+1))/T.Strength(i);
        NodeMajorDiameterTaper_Node1to2(k) = T.NodeMajorDiameter(i) - T.NodeMajorDiameter(i+1);
        NodeMajorDiameterTaperPercentage_Node1to2 = (T.NodeMajorDiameter(i) - T.NodeMajorDiameter(i+1))/T.NodeMajorDiameter(i);
        k=k+1; % once complete, k should equal node1Count
        is=is+1;
     elseif T.Node(i)==2 && T.Node(i+1)==3 && T.Stem(i) == T.Stem(i+1)
        Tn.is(is) = is;
        Tn.j(is) = T.j(i);
        Tn.Stem(is) = T.Stem(i);
        Tn.NodeRelation(is) = 'Node2,Node3';
        Tn.Variety(is) = T.Variety(i);
        Tn.Plot(is) = T.Plot(i);
        Tn.OverviewFile(is) = T.OverviewFile(i);
        Tn.StiffnessDifference(is) = T.Stiffness(i) - T.Stiffness(i+1);
        Tn.StiffnessPercentDifference(is) = (T.Stiffness(i) - T.Stiffness(i+1))/T.Stiffness(i);
        Tn.StrengthDifference(is) = T.Strength(i) - T.Strength(i+1);
        Tn.StrengthPercentDifference(is) = (T.Strength(i) - T.Strength(i+1))/T.Strength(i);
        Tn.ModulusDifference(is) = T.Modulus(i) - T.Modulus(i+1);
        Tn.ModulusPercentDifference(is) = (T.Modulus(i) - T.Modulus(i+1))/T.Modulus(i);
        Tn.EIDifference(is) = T.EI(i) - T.EI(i+1);
        Tn.EIPercentDifference(is)  = (T.EI(i) - T.EI(i+1))/T.EI(i);
        Tn.NodeMajorDiameterDifference(is) = T.NodeMajorDiameter(i) - T.NodeMajorDiameter(i+1);
        Tn.NodeMajorDiameterPercentDifference(is) = (T.NodeMajorDiameter(i) - T.NodeMajorDiameter(i+1))/T.NodeMajorDiameter(i);
        Tn.BreakTypeVector(is) =  strcat(T.BreakType(i),',',T.BreakType(i+1));
        k=k+1; % once complete, k should equal node1Count
        is=is+1;
    end
end
%% Create derived node comparison tables, each direction for each element, remove rows
T_stifferLow=Tn;
%keepList=[];
removeList=[];
for is = 1:comparisonCount
    if Tn.StiffnessPercentDifference(is) < 0
        removeList(end+1) = is;
        T_stifferLow.removeRef(is)=1;
        %     elseif Tn.StiffnessPercentDifference(is) > 0
        %         keepList(end+1) = is;
        %     elseif
        %         Tn.StiffnessPercentDifference(is) == 0 % highly unlikely
    end
    
end
T_stifferLow(removeList,:)=[];
%T_stifferLow=T_stifferLow(keepList,:);
height(T_stifferLow) == sum(Tn.StiffnessDifference>0) % validty check



% function form, for example
% [tableWithRowsRemoved] = trows(tableOriginal,tableNewName,columnOfComparison,thresholdNumber,lessGreaterOrEqual)
tableOriginal = Tn; % = Y
tableNewName = T_stifferHigh;
columnOfComparison = Tn.StiffnessPercentDifference; % = G, = string
thresholdNumber = 0;
lessGreaterOrEqual_keep = 'pos'; % 'pos', 'neg', 'equal' 
% create table T_stifferHigh of all rows in Tn where 
G = Tn.StiffnessPercentDifference; % point of positive or negative comparison
Y = Tn; % for generalizability
removeList=[];
for is = 1:comparisonCount
    if G(is) > 0 % which to remove
        removeList(end+1) = is;
    end
end
Y(removeList,:)=[];
height(Y) == sum(G>0) % validty check
T_stifferHigh = Y; % reassign from general variable
%% Function code ideas and information
% function block notation, can be inside of script, i think anywhere, above
% or below.
% Node, can copy text of downloaded functions from other users into script,
% rather than keeping file in same direectory as script.
% Example of Function block:
%            function [mean,stdev] = stat(x)
%            %STAT Interesting statistics.
%            n = length(x);
%            mean = avg(x,n);
%            stdev = sqrt(sum((x-avg(x,n)).^2)/n);

% Inline functions:
% Example 1:
% h = @(arglist)anonymous_function
% sqr = @(n) n.^2;
% x = sqr(3) % x = 9
% Example 2:
% C = {@sin, @cos, @tan};
% C{2}(pi) % = -1
% C{3}(pi) % = -1.2246e-16

% function_handle: (help function_handle)
%      Example 1 - Construct a handle, f, to the HUMPS function, and pass this 
%      handle to FMINBND. (MATLAB maps a specific implementation of the HUMPS
%      function to the handle f at the time the handle is created, and not at
%      the time f is called.)
%  
%          f = @humps;
%          x = fminbnd(f,1,2);
%  
%      Example 2 - Call a function by means of the function handle, h, that
%      was passed as an argument.
%  
%      function trigPlot(h, val)
%      if isa(h, 'function_handle')   % Verify that h is a function handle.
%         A = h(val);                 % Call the function mapped to handle h.
%         plot(A)                     % Plot the resulting data.
%         end
%% Node Comparison Analysis

% general form
% Y = StiffnessTaper_Node1to2;
% numStems_lowNodeStiffer = sum(Y>0);
% numStems_higherNodeStiffer = sum(Y<0);
% avgDifference_lowNodeStiffer=sum((Y>0).*Y)/sum(Y>0); % accurate, confirmed
% avgDifference_higherNodeStiffer=sum((Y<0).*Y)/sum(Y<0); % accurate, confirmed
% sumDifferences_lowNodeStiffer=sum((Y>0).*Y);
% sumDifferences_higherNodeStiffer=sum((Y<0).*Y);
% ratioDifferences_lowNodeStifferOverHigherNodeStiffer = abs(sumDifferences_lowNodeStiffer/sumDifferences_higherNodeStiffer);

% Node 1 to Node 2, Stiffness
Y = StiffnessTaper_Node1to2;
numStems_lowNodeStiffer = sum(Y>0);
numStems_higherNodeStiffer = sum(Y<0);
avgDifference_lowNodeStiffer=sum((Y>0).*Y)/sum(Y>0); % accurate, confirmed
avgDifference_higherNodeStiffer=sum((Y<0).*Y)/sum(Y<0); % accurate, confirmed
sumDifferences_lowNodeStiffer=sum((Y>0).*Y);
sumDifferences_higherNodeStiffer=sum((Y<0).*Y);
ratioDifferences_lowNodeStifferOverHigherNodeStiffer = abs(sumDifferences_lowNodeStiffer/sumDifferences_higherNodeStiffer);
% what is average percentage stiffer, as a ratio of difference/stiffness of lower node?
avgPercentDifference_allStiffnesses = mean(StiffnessTaperPercentage_Node1to2);

list_lowNodeStifferPercentage = zeros(numStems_lowNodeStiffer,1);
list_higherNodeStifferPercentage = zeros(numStems_higherNodeStiffer,1);
klow=1;
khigh=1;
for is=1:node1Count 
    if Tn.StiffnessDifference(is)> 0 && Tn.NodeRelation(is) == 'Node1,Node2'
        %list_lowNodeStifferPercentage(klow) = 
        klow = klow + 1;
    elseif StiffnessTaperPercentage_Node1to2(is)< 0
        list_higherNodeStifferPercentage(khigh) = StiffnessTaper_Node1to2(is);
        khigh = khigh + 1;
    end
end

% these equations might be wrong
avgStiffnessPercentDifference_pos = sum((Tn.StiffnessPercentDifference>0).*(Tn.StiffnessPercentDifference))/sum(Tn.StiffnessPercentDifference>0);
avgStiffnessPercentDifference_neg = sum((Tn.StiffnessPercentDifference<0).*(Tn.StiffnessPercentDifference))/sum(Tn.StiffnessPercentDifference<0);
avgStiffnessPercentDifference_all = mean(Tn.StiffnessPercentDifference);
avgStiffnessDifference_pos = sum((Tn.StiffnessDifference>0).*(Tn.StiffnessDifference))/sum(Tn.StiffnessDifference>0);
avgStiffnessDifference_neg = sum((Tn.StiffnessDifference<0).*(Tn.StiffnessDifference))/sum(Tn.StiffnessDifference<0);
avgStiffnessDifference_all = mean(Tn.StiffnessDifference);
stdStiffnessDifference_all = std(Tn.StiffnessDifference);
maxStiffnessDifference_all = max(Tn.StiffnessDifference);
minStiffnessDifference_all = min(Tn.StiffnessDifference);
medianStiffnessDifference_all = median(Tn.StiffnessDifference);
avgStiffness = mean(T.Stiffness);
compareToAveStiffnessDifferenaceAll = avgStiffnessPercentDifference_all*avgStiffness;

Y = StrengthTaper_Node1to2;
numStems_lowNodeStronger = sum(StrengthTaper_Node1to2>0);
numStems_higherNodeStronger = sum(StrengthTaper_Node1to2<0);
avgDifference_lowNodeStronger=sum((StrengthTaper_Node1to2>0).*StrengthTaper_Node1to2)/sum(StrengthTaper_Node1to2>0);
avgDifference_higherNodeStronger=sum((StrengthTaper_Node1to2<0).*StrengthTaper_Node1to2)/sum(StrengthTaper_Node1to2<0);

Y = NodeMajorDiameterTaper_Node1to2;
numStems_lowNodeGreaterDiameter = sum(NodeMajorDiameterTaper_Node1to2>0);
numStems_higherNodeGreaterDiameter = sum(NodeMajorDiameterTaper_Node1to2<0);
avgDifference_lowNodeGreaterDiameter=sum((NodeMajorDiameterTaper_Node1to2>0).*NodeMajorDiameterTaper_Node1to2)/sum(NodeMajorDiameterTaper_Node1to2>0);
avgDifference_higherNodeGreaterDiameter=sum((NodeMajorDiameterTaper_Node1to2<0).*NodeMajorDiameterTaper_Node1to2)/sum(NodeMajorDiameterTaper_Node1to2<0);
%% Node Comparison Analysis, Better

i_purple=[];
i_yellow=[];
i_crimson=[];
i_blue=[];
i_pink=[];
i_green=[];
i_black=[];

i=1;
k=1;
while i<height(T)
    if T.Node(i)==1 && T.Node(i+1)==2 % Look not only third nodes
        % purple (stiffness down, diameter up), yellow (stiffness up, diameter down), red (both go up), blue (both go down)
        if T.Stiffness(i) > T.Stiffness(i+1) && T.NodeMajorDiameter(i) < T.NodeMajorDiameter(i+1)
            Tn.StifferThicker(k) = 12;
            i_purple(end+1)=i;
        elseif T.Stiffness(i) < T.Stiffness(i+1) && T.NodeMajorDiameter(i) > T.NodeMajorDiameter(i+1)
            Tn.StifferThicker(k) = 21;
            i_yellow(end+1)=i;
        elseif T.Stiffness(i) < T.Stiffness(i+1) && T.NodeMajorDiameter(i) < T.NodeMajorDiameter(i+1)
            Tn.StifferThicker(k) = 22;
            i_crimson(end+1)=i;
        elseif T.Stiffness(i) > T.Stiffness(i+1) && T.NodeMajorDiameter(i) > T.NodeMajorDiameter(i+1)
            Tn.StifferThicker(k) = 11; 
            i_blue(end+1)=i;
        elseif T.NodeMajorDiameter(i) == T.NodeMajorDiameter(i+1) && T.Stiffness(i) > T.Stiffness(i+1)
            Tn.StifferThicker(k) = 10;
            i_pink(end+1)=i;
        elseif T.NodeMajorDiameter(i) == T.NodeMajorDiameter(i+1) && T.Stiffness(i) < T.Stiffness(i+1)
            Tn.StifferThicker(k) = 20;
            i_green(end+1)=i;
        elseif T.Stiffness(i) == T.Stiffness(i+1) && T.NodeMajorDiameter(i) > T.NodeMajorDiameter(i+1)
            Tn.StifferThicker(k) = 01;
            i_black(end+1)=i;
        elseif T.Stiffness(i) == T.Stiffness(i+1) && T.NodeMajorDiameter(i) > T.NodeMajorDiameter(i+1)
            Tn.StifferThicker(k) = 02;
            i_black(end+1)=i;
        end
        i=i+2;
        k=k+1;
    else % for third stems
        msg = strcat('third stem at',{' T.'},string(i),{', Tn.'},string(k));
        i=i+1;
        k=k+1;
    end
end
%% Purple compared to NodeMajorDiam over InternodeMajorDiam of Second Node
%% PivotTable: Purple compared to NodeArea over InternodeArea of Second Node
% idxListPurple = ((Tn.StifferThicker==12).*Tn.is); 
% %(idxListPurple==0) = []; % remove zeros
% k=1;
% r=0;
% while k < (length(idxListPurple)-r)
%     if idxListPurple(k)==0
%         idxListPuple(k) = [];
%         r=r+1;
%     else
%         k = k+1;
%     end
% end
i = T.i; % whole llist, or use height(T) or length(T) when a table column such as T.i does not exist
y = T.NodeArea./T.InternodeArea;
meanValue=mean(y);
medianValue=median(y);
threshold = 0.70; % currently unused
thresholdValue = (max(y)-min(y))*threshold+min(y);
i_yMoreThanAvg = (y>meanValue).*i;
i_yMoreThanMost = (y>medianValue).*i;
i_yMoreThanThreshold = (y>thresholdValue).*i;
nodeList = T.Node;
idxTrack = i;
% find indices where areaRatioMoreThavAvg ==0
% remove those positions from said matrix and from nodeList

idxZeros = i_yMoreThanMost==0;
i_yMoreThanMost(idxZeros) = [];
nodeList(idxZeros) = [];
idxTrack(idxZeros) = [];


%[] = sorttows()

%%

i_node1 = (T.Node==1).*T.i;
i_node2 = (T.Node==2).*T.i;

% here's how to remove zeros, no loop required, friggin A.
idxZeros = i_node2==zeros;
i_node2(idxZeros)=[];
% proportionally more (100/168) nodes that are thicker yet stiffer have an
% area ratio (NodeArea/InternodeArea) that is above the median.
%
% plot idea: Subplot1: node 1's versus avg areaRatio
            % Subplot2: node 2's versus avg areaRatio
% remove zeros
%i_node2 = (T.Node==2).*T.i;
% remove zeros
%% Vision, Future work
% I want to see node comparison trends for each plot and genetic variety
% Do some genetic varieties tend to have stiffer 2nd nodes, for example?
% A trend of stronger second nodes would probably correlate not with
% genetics, but with plots that are taller or shorter during growing. We
% cannot know their growth height, but that would probably correlate with
% diameter (lower diameter for lower height, assuming the dwarfing is
% homogenous).
% Anyways, do node comparison trends correlate with diameter size ranges?
%% Data Processing Above This Line ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
%% Plots Generated Below This Line .......................................
%% Scatter, Stiffness Percent Difference vs Diameter Percent Difference 
plot(Tn.StiffnessPercentDifference,Tn.NodeMajorDiameterPercentDifference,'d')
%% CHURCH: ScatterSquares, Stiffness vs Diameter values
%close(hf1,hf2)
hold off
hf1 = figure(1);
hold off
plot([0 1],[0 0],'-','Color',[0,0.4470,0.7410],'LineWidth',5) % blue
hold on
plot([0 1],[0 0],'-','Color',[0.6350,0.0780,0.1840],'LineWidth',5) % crimson
plot([0 1],[0 0],'-','Color',[0.4940,0.1840,0.5560],'LineWidth',5) % purple
plot([0 1],[0 0],'-','Color',[0.9290,0.6940,0.1250],'LineWidth',5) % yellow
plot([0 1],[0 0],'-','Color',[255/255 153/255 200/255],'LineWidth',5) % pink
plot([0 1],[0 0],'-','Color',[77/255 190/255 70/255],'LineWidth',5) % green

[abc,a,b,c,rsq,rmse,sse]=exponentialFitting(T.NodeMajorDiameter,T.Stiffness,0,1,1);

i_purple=[];
i_yellow=[];
i_crimson=[];
i_blue=[];
i_pink=[];
i_green=[];
i_black=[];
hold on
i=1;
k=1;
countShown=0;
T=Tn;
while i<height(T)
    if T.Node(i)==1 && T.Node(i+1)==2
       
        X=[T.NodeMajorDiameter(i+1),T.NodeMajorDiameter(i+1),T.NodeMajorDiameter(i),T.NodeMajorDiameter(i),T.NodeMajorDiameter(i+1)];
        Y=[T.Stiffness(i),T.Stiffness(i+1),T.Stiffness(i+1),T.Stiffness(i),T.Stiffness(i)];
        % if statement to decide color
        % purple (stiffness down, diameter up), yellow (stiffness up, diameter down), red (both go up), blue (both go down)
        if T.Stiffness(i) > T.Stiffness(i+1) && T.NodeMajorDiameter(i) < T.NodeMajorDiameter(i+1)
            T.StifferThicker(i) = 12;
            colormat = [0.4940,0.1840,0.5560]; %purple
%             colormat = [255/255 255/255 255/255]; %white override, covers up other data, sad. 
            linewidth = 1;
%             linewidth = 0.1;
            countShown = countShown+1; 
            i_purple(end+1)=i;
        elseif T.Stiffness(i) < T.Stiffness(i+1) && T.NodeMajorDiameter(i) > T.NodeMajorDiameter(i+1)
            T.StifferThicker(i) = 21;
            colormat = [0.9290,0.6940,0.1250]; %yellow
            colormat = [255/255 255/255 255/255]; %white override, covers up other data, sad.
            linewidth = 1;
            linewidth = 0.1;
%             countShown = countShown+1;
            i_yellow(end+1)=i;
            
        elseif T.Stiffness(i) < T.Stiffness(i+1) && T.NodeMajorDiameter(i) < T.NodeMajorDiameter(i+1)
            T.StifferThicker(i) = 22;
            colormat = [0.6350,0.0780,0.1840]; %crimson
            colormat = [255/255 255/255 255/255]; %white override, covers up other data, sad.
            linewidth = 1;
            linewidth = 0.1;
%             countShown = countShown+1;
            i_crimson(end+1)=i;
             
        elseif T.Stiffness(i) > T.Stiffness(i+1) && T.NodeMajorDiameter(i) > T.NodeMajorDiameter(i+1)
            T.StifferThicker(i) = 11;
            colormat = [0,0.4470,0.7410]; %blue
            colormat = [255/255 255/255 255/255]; %white override, covers up other data, sad.
            linewidth = 1;
            linewidth = 0.1;
%             countShown = countShown+1;
            i_blue(end+1)=i;
             
        elseif T.NodeMajorDiameter(i) == T.NodeMajorDiameter(i+1) && T.Stiffness(i) > T.Stiffness(i+1)
            T.StifferThicker(i) = 10;
            colormat = [255/255 153/255 200/255]; %pink
            colormat = [255/255 255/255 255/255]; %white override, covers up other data, sad. 
            linewidth = 1;
            linewidth = 0.1;
%             countShown = countShown+1;
            i_pink(end+1)=i;
             
        elseif T.NodeMajorDiameter(i) == T.NodeMajorDiameter(i+1) && T.Stiffness(i) < T.Stiffness(i+1)
            T.StifferThicker(i) = 20;
            colormat = [77/255 190/255 70/255]; %green
            colormat = [255/255 255/255 255/255]; %white override, covers up other data, sad. 
            linewidth = 1;
            linewidth = 0.1;
%             countShown = countShown+1; 
            i_green(end+1)=i;
        
        elseif T.Stiffness(i) == T.Stiffness(i+1)
            T.StifferThicker(i) = 00;
            colormat = [255/255 255/255 255/255]; %black
            colormat = [255/255 255/255 255/255]; %white override, covers up other data, sad. 
            linewidth = 1;
            linewidth = 0.1;
%             countShown = countShown+1; 
            i_black(end+1)=i;
        end
        i=i+2;
        k=k+1;
    else % for third stems
        msg = 'help';
        i=i+1;
    end
    
    hold on
    plot(X,Y,'-.',X(3),Y(1),'*','Color',colormat,'LineWidth',linewidth,'MarkerSize',10)
    %plot(X,Y,'-','Color',colormat)
end
updateLegendVector = zeros(k,1);
updateLegendVector([1,3,5,7])=1;
title('Stiffness Taper and Diameter Taper, Nodes 1 and 2, Wheat 2021, Instron')
xlabel('Diameter (mm)')
ylabel('Stiffness (N/mm)')
axis([1.5,4.5,0,5])
stringTotalStems = k-2;
hleg=legend({'Node 1 Stiffer, Node 1 Thicker','Node 2 Stiffer, Node 2 Thicker','Node 1 Stiffer, Node 2 Thicker','Node 2 Stiffer, Node 1 Thicker','Node 1 Stiffer, Same Diameter','Node 2 Stiffer, Same Diameter'},'AutoUpdate','off','Location','west','LineWidth',1);
hleg.Title.String='Color meaning';
htext1 = text(1.6,4.4,{strcat(string(countShown),' stems are shown of the',{' '},string(stringTotalStems),' stems tested in the Node to Node Comparison experiment.')},'EdgeColor','k');
text(1.6,4.6,'Each box represents one stem. The asterisk is the 1st node, and the opposite corner is the 2nd node.','EdgeColor','k')
% add 4th order poly trendlines, two, one for each node
%%
% pie chart, one day this will be inset and it will be beautiful
hf2=figure(2);
explode = [0 0 0 0 0 0];
hpie = pie([sum(i_blue),sum(i_crimson),sum(i_purple),sum(i_yellow),sum(i_pink),sum(i_green)],explode);
hleg=legend({'Node 1 Stiffer, Node 1 Thicker','Node 2 Stiffer, Node 2 Thicker','Node 1 Stiffer, Node 2 Thicker','Node 2 Stiffer, Node 1 Thicker','Node 1 Stiffer, Same Diameter','Node 2 Stiffer, Same Diameter'},'AutoUpdate','off','Location','west');
hpie(1).FaceColor = [0,0.4470,0.7410];
hpie(2).Position = 0.5*hpie(2).Position;
hpie(3).FaceColor = [0.6350,0.0780,0.1840];
hpie(4).Position = 0.5*hpie(4).Position;
hpie(5).FaceColor = [0.4940,0.1840,0.5560];
hpie(6).Position = 0.5*hpie(6).Position;
hpie(7).FaceColor = [0.9290,0.6940,0.1250];
hpie(8).Position = 0.5*hpie(8).Position;
hpie(9).FaceColor = [255/255 153/255 200/255];
hpie(10).Position = 0.65*hpie(10).Position;
hpie(11).FaceColor = [77/255 190/255 70/255];
hpie(12).Position = 0.9*hpie(12).Position;
title('Stiffness Taper and Diameter Taper, Nodes 1 and 2, Wheat 2021, Instron')

% % 'Color',[0,0.4470,0.7410]) % blue
% % 'Color',[0.6350,0.0780,0.1840]) % crimson
% % 'Color',[0.4940,0.1840,0.5560]) % purple
% % 'Color',[0.9290,0.6940,0.1250]) % yellow
% % 'Color',[255/255 153/255 200/255]) % pink
%% Vertical Lines


avgY = mean(T.NodeMajorDiameter);
Xperdiff_list = Tn.StiffnessPercentDifference;
Ydiff_list = Tn.NodeMajorDiameterDifference;
Yperdiff_list = Tn.NodeMajorDiameterPercentDifference;
for is=1:node1Count
    X = Xperdiff_list(is);
    Y1 = Ydiff_list(is)/Yperdiff_list(is);
    Y2 = Y1 - Ydiff_list(is);
    if Y1 > Y2 % low node bigger, black line
        formatString = 'k-d';
    elseif Y1 < Y2 % low node smaller, red line
        formatString = 'r-d';
    elseif Y1 == Y2 % same size node, blue dot
        formatString = 'b*';
    end
plot([X,X],[Y1,Y2],formatString);
end

axis([-0.5,0.5,1.5,4.5]) %manual set
plot([mean(Xperdiff_list),mean(Xperdiff_list)],[-20,20],':k') %vertical line at average X axis
plot([-20,20],[avgY,avgY],':k') %horizontal line at average Y axis

title('Node 1 to Node 2 Comparison, Wheat 2021, Instron')
xlabel('Stiffness % Difference, [(N/mm)/(N/mm)]')
ylabel('Diameter (mm)')
string1 = 'Black vertical lines mean that Node 1 had a bigger Node Major Diameter.';
string2 = 'Red vertical lines mean that Node 2 had a bigger Node Major Diameter.';
string3 = 'Blue dots mean that Node 1 and Node 2 had the same Node Major Diameter.';
text(2,2,{string1,string1,string1})
legend('Node 1 Thicker','','Node 2 Thicker','location','southeast')
%% Plot vertical lines, Stiffness%diff vs Diameter values
close(gcf)
hold on
avgY = mean(T.NodeMajorDiameter);
Xperdiff_list = Tn.StiffnessPercentDifference;
Ydiff_list = Tn.NodeMajorDiameterDifference;
Yperdiff_list = Tn.NodeMajorDiameterPercentDifference;
for is=1:node1Count
    X = Xperdiff_list(is);
    Y1 = Ydiff_list(is)/Yperdiff_list(is);
    Y2 = Y1 - Ydiff_list(is);
    if Y1 > Y2 % low node bigger, black line
        formatString = 'k-d';
    elseif Y1 < Y2 % low node smaller, red line
        formatString = 'r-d';
    elseif Y1 == Y2 % same size node, blue dot
        formatString = 'b*';
    end
plot([X,X],[Y1,Y2],formatString);
end

axis([-0.5,0.5,1.5,4.5]) %manual set
plot([mean(Xperdiff_list),mean(Xperdiff_list)],[-20,20],':k') %vertical line at average X axis
plot([-20,20],[avgY,avgY],':k') %horizontal line at average Y axis

title('Node 1 to Node 2 Comparison, Wheat 2021, Instron')
xlabel('Stiffness % Difference, [(N/mm)/(N/mm)]')
ylabel('Diameter (mm)')
string1 = 'Black vertical lines mean that Node 1 had a bigger Node Major Diameter.';
string2 = 'Red vertical lines mean that Node 2 had a bigger Node Major Diameter.';
string3 = 'Blue dots mean that Node 1 and Node 2 had the same Node Major Diameter.';
text(2,2,{string1,string1,string1})
legend('Node 1 Thicker','','Node 2 Thicker','location','southeast')
%% Plot vertical lines, Diameter%diff vs Stiffness values
close(gcf)
hold on
avgY = mean(T.Stiffness);
Xperdiff_list = Tn.NodeMajorDiameterPercentDifference;
Ydiff_list = Tn.StiffnessDifference;
Yperdiff_list = Tn.StiffnessPercentDifference;
for is=1:node1Count
    X = Xperdiff_list(is);
    Y1 = Ydiff_list(is)/Yperdiff_list(is);
    Y2 = Y1 - Ydiff_list(is);
    if Y1 > Y2 % low node bigger, black line
        formatString = 'k-';
    elseif Y1 < Y2 % low node smaller, red line
        formatString = 'r-';
    elseif Y1 == Y2 % same size node, blue dot
        formatString = 'b*';
    end
plot([X,X],[Y1,Y2],formatString);
end

axis([-0.2,0.2,0,5])
plot([mean(Xperdiff_list),mean(Xperdiff_list)],[-20,20],':k') %vertical line at average X axis
plot([-20,20],[avgY,avgY],':k') %horizontal line at average Y axis


title('Node 1 to Node 2 Comparison, Wheat 2021, Instron')
xlabel('Diameter % Difference [mm/mm]')
ylabel('Stiffness [N/mm]')
string1 = 'Black vertical lines mean that Node 1 is stiffer.';
string2 = 'Red vertical lines mean that Node 2 is stiffer.';
string3 = 'Blue dots mean that Node 1 and Node 2 had the same stiffness.';
text(-0.175,4.75,{string1,string2,string3})
legend('Node 1 Stiffer','Node 2 Stiffer','location','southeast')
%% Plot vertical lines, Diameter%diff vs Strength values
close(gcf)
hold on
avgY = mean(T.Strength);
Xperdiff_list = Tn.NodeMajorDiameterPercentDifference;
Ydiff_list = Tn.StrengthDifference;
Yperdiff_list = Tn.StrengthPercentDifference;
for is=1:node1Count
    X = Xperdiff_list(is);
    Y1 = Ydiff_list(is)/Yperdiff_list(is);
    Y2 = Y1 - Ydiff_list(is);
    if Y1 > Y2 % low node bigger, black line
        formatString = 'k-d';
    elseif Y1 < Y2 % low node smaller, red line
        formatString = 'r-d';
    elseif Y1 == Y2 % same size node, blue dot
        formatString = 'b*';
    end
plot([X,X],[Y1,Y2],formatString);
end

axis([-0.2,0.2,0,18])
plot([mean(Xperdiff_list),mean(Xperdiff_list)],[-20,20],':k') %vertical line at average X axis
plot([-20,20],[avgY,avgY],':k') %horizontal line at average Y axis


title('Node 1 to Node 2 Comparison, Wheat 2021, Instron')
xlabel('Diameter % Difference [mm/mm]')
ylabel('Max Force [N]')
string1 = 'Black vertical lines mean that Node 1 is stronger.';
string2 = 'Red vertical lines mean that Node 2 is stronger.';
string3 = 'Blue dots mean that Node 1 and Node 2 had the same strength.';
text(-0.175,17,{string1,string2,string3})
legend('Node 1 Stronger','','','','','Node 2 Stronger','location','southeast')
%% Stiffness, Node Comparison, Bar Pie and Histogram
hold off
close(gcf)
hold on
avgY = mean(T.NodeMajorDiameter);
Xperdiff_list = Tn.StiffnessPercentDifference;
Ydiff_list = Tn.NodeMajorDiameterDifference;
Yperdiff_list = Tn.NodeMajorDiameterPercentDifference;
for is=1:node1Count
    X = Xperdiff_list(is);
    Y1 = Ydiff_list(is)/Yperdiff_list(is);
    Y2 = Y1 - Ydiff_list(is);
    if Y1 > Y2 % low node bigger, black line
        formatString = 'k-d';
    elseif Y1 < Y2 % low node smaller, red line
        formatString = 'r-d';
    elseif Y1 == Y2 % same size node, blue dot
        formatString = 'b*';
    end
plot([X,X],[Y1,Y2],formatString);
end

pos1 = [0.05 0.05 0.35 0.35];
pos2 = [0.05 0.55 0.35 0.35];
pos3 = [0.4 0.05 0.5 0.95];
Y = StiffnessTaper_Node1to2;
%subplot(2,2,1)
subplot('Position',pos2)
bar(Y)
stringTaper = strcat('Each bar represents one stem');
text(2,-1.6,stringTaper)
text(60,-1,string(avgDifference_higherNodeStiffer))
text(50,1,string(avgDifference_lowNodeStiffer))
hold on
plot([0,comparisonCount],[avgDifference_lowNodeStiffer,avgDifference_lowNodeStiffer])
plot([0,(numStems_lowNodeStiffer+numStems_higherNodeStiffer)],[avgDifference_higherNodeStiffer,avgDifference_higherNodeStiffer])
%xlim([- 8])
ylim([-2 2])
title_string='Stiffness Node to Node Comparison, Wheat 2021, Instron';
title(title_string,"HorizontalAlignment",'left','VerticalAlignment','bottom')

%subplot(2,2,2)
subplot('Position',pos3)
explode=[0 1];
hpie = pie([sum(Y>0),sum(Y<0)],explode);
legend({'# Stem with stiffer low node','# Stem with stiffer higher node'},'Location','southeast')
hpie(1).FaceColor = [165/255 165/255 165/255];
hpie(2).Position = 0.5*hpie(2).Position;
hpie(3).FaceColor = [90/255 155/255 213/255];
hpie(4).Position = 0.5*hpie(4).Position;

%subplot(2,2,3)
%subplot(2,2,[1,4])
%pie([avgDifference_lowNodeStiffer*10,avgDifference_higherNodeStiffer*10],{'Avg stiffness difference when low node is stiffer','Avg stiffness difference when higher node is stiffer'});

%subplot(2,2,3)
subplot('Position',pos1)
histogram(Y)
xlim([-2 2])
ylim([0 50])
%% Stiffness Percent, Node Comparison, Bar Pie and Histogram
hold off
close(gcf)
hold on
avgY = mean(T.NodeMajorDiameter);
Xperdiff_list = Tn.StiffnessPercentDifference;
Ydiff_list = Tn.NodeMajorDiameterDifference;
Yperdiff_list = Tn.NodeMajorDiameterPercentDifference;
for is=1:node1Count
    X = Xperdiff_list(is);
    Y1 = Ydiff_list(is)/Yperdiff_list(is);
    Y2 = Y1 - Ydiff_list(is);
    if Y1 > Y2 % low node bigger, black line
        formatString = 'k-d';
    elseif Y1 < Y2 % low node smaller, red line
        formatString = 'r-d';
    elseif Y1 == Y2 % same size node, blue dot
        formatString = 'b*';
    end
plot([X,X],[Y1,Y2],formatString);
end

pos1 = [0.05 0.05 0.35 0.35];
pos2 = [0.05 0.55 0.35 0.35];
pos3 = [0.4 0.05 0.5 0.95];
Y = StiffnessTaper_Node1to2;
%subplot(2,2,1)
subplot('Position',pos2)
bar(Y)
stringTaper = strcat('Each bar represents one stem');
text(2,-1.6,stringTaper)
text(60,-1,string(avgDifference_higherNodeStiffer))
text(50,1,string(avgDifference_lowNodeStiffer))
hold on
plot([0,comparisonCount],[avgDifference_lowNodeStiffer,avgDifference_lowNodeStiffer])
plot([0,(numStems_lowNodeStiffer+numStems_higherNodeStiffer)],[avgDifference_higherNodeStiffer,avgDifference_higherNodeStiffer])
%xlim([- 8])
ylim([-2 2])
title_string='Stiffness Node to Node Comparison, Wheat 2021, Instron';
title(title_string,"HorizontalAlignment",'left','VerticalAlignment','bottom')

%subplot(2,2,2)
subplot('Position',pos3)
explode=[0 1];
hpie = pie([sum(Y>0),sum(Y<0)],explode);
legend({'# Stem with stiffer low node','# Stem with stiffer higher node'},'Location','southeast')
hpie(1).FaceColor = [165/255 165/255 165/255];
hpie(2).Position = 0.5*hpie(2).Position;
hpie(3).FaceColor = [90/255 155/255 213/255];
hpie(4).Position = 0.5*hpie(4).Position;

%subplot(2,2,3)
%subplot(2,2,[1,4])
%pie([avgDifference_lowNodeStiffer*10,avgDifference_higherNodeStiffer*10],{'Avg stiffness difference when low node is stiffer','Avg stiffness difference when higher node is stiffer'});

%subplot(2,2,3)
subplot('Position',pos1)
histogram(Y)
xlim([-2 2])
ylim([0 50])
%% DEFUNCT Stiffness, Node Comparison, Bar Pie and Histogram
hold off
pos1 = [0.05 0.05 0.35 0.35];
pos2 = [0.05 0.55 0.35 0.35];
pos3 = [0.4 0.05 0.5 0.95];
Y = StiffnessTaper_Node1to2;
%subplot(2,2,1)
subplot('Position',pos2)
bar(Y)
stringTaper = strcat('Each bar represents one stem');
text(2,-1.6,stringTaper)
text(60,-1,string(avgDifference_higherNodeStiffer))
text(50,1,string(avgDifference_lowNodeStiffer))
hold on
plot([0,(numStems_lowNodeStiffer+numStems_higherNodeStiffer)],[avgDifference_lowNodeStiffer,avgDifference_lowNodeStiffer])
plot([0,(numStems_lowNodeStiffer+numStems_higherNodeStiffer)],[avgDifference_higherNodeStiffer,avgDifference_higherNodeStiffer])
%xlim([- 8])
ylim([-2 2])
title_string='Stiffness Node to Node Comparison, Wheat 2021, Instron';
title(title_string,"HorizontalAlignment",'left','VerticalAlignment','bottom')

%subplot(2,2,2)
subplot('Position',pos3)
explode=[0 1];
hpie = pie([sum(Y>0),sum(Y<0)],explode);
legend({'# Stem with stiffer low node','# Stem with stiffer higher node'},'Location','southeast')
hpie(1).FaceColor = [165/255 165/255 165/255];
hpie(2).Position = 0.5*hpie(2).Position;
hpie(3).FaceColor = [90/255 155/255 213/255];
hpie(4).Position = 0.5*hpie(4).Position;

%subplot(2,2,3)
%subplot(2,2,[1,4])
%pie([avgDifference_lowNodeStiffer*10,avgDifference_higherNodeStiffer*10],{'Avg stiffness difference when low node is stiffer','Avg stiffness difference when higher node is stiffer'});

%subplot(2,2,3)
subplot('Position',pos1)
histogram([StiffnessTaper_Node1to2])
xlim([-2 2])
ylim([0 50])
%% Strength, Node Comparison, Bar Pie and Histogram
hold off
Y = StrengthTaper_Node1to2;
subplot(2,2,1)
bar(Y)
stringTaper = strcat('Each bar represents one stem');
text(2,6,stringTaper)
hold on
plot([0,(numStems_lowNodeStronger+numStems_higherNodeStronger)],[avgDifference_lowNodeStronger,avgDifference_lowNodeStronger])
plot([0,(numStems_lowNodeStronger+numStems_higherNodeStronger)],[avgDifference_higherNodeStronger,avgDifference_higherNodeStronger])
title_string='Strength Node to Node Comparison, Wheat 2021, Instron';
title(title_string,"HorizontalAlignment",'left','VerticalAlignment','bottom')

subplot(2,2,2)
pie([sum(Y>0),sum(Y<0)])
legend({'Stronger low node','Stronger higher node'})

%subplot(2,2,3)
%pie([avgDifference_lowNodeStronger*10,avgDifference_higherNodeStronger*10],{'Avg strength difference when low node is stronger','Avg strength difference when higher node is stronger'});

subplot(2,2,4)
histogram(StrengthTaper_Node1to2)
%% Diameter, Node Comparison, Bar Pie and Histogram
hold off
Y = NodeMajorDiameterTaper_Node1to2;    
subplot(2,2,1)
bar(Y)
stringTaper = strcat('Each bar represents one stem');
text(2,6,stringTaper)
hold on
plot([0,(numStems_lowNodeGreaterDiameter+numStems_higherNodeGreaterDiameter)],[avgDifference_lowNodeGreaterDiameter,avgDifference_lowNodeGreaterDiameter])
plot([0,(numStems_lowNodeGreaterDiameter+numStems_higherNodeGreaterDiameter)],[avgDifference_higherNodeGreaterDiameter,avgDifference_higherNodeGreaterDiameter])
title_string=({'Major Diameter Node to Node Comparison';'Wheat 2021, Instron'});
title(title_string,'VerticalAlignment','bottom')
%title(title_string,"HorizontalAlignment",'left','VerticalAlignment','bottom')

subplot(2,2,2)
pie([sum(Y>0),sum(Y<0)])
legend({'Greater diameter low node','Greater diameter higher node'})

%subplot(2,2,3)
%pie([avgDifference_lowNodeGreaterDiameter*10,avgDifference_higherNodeGreaterDiameter*10],{'Avg diameter difference when low node has greater diameter','Avg strength difference when higher node has greater diameter'});

subplot(2,2,4)
histogram(NodeMajorDiameterTaper_Node1to2)
%% Histograms for Stiffness, Strength, and Diameter
hold off
n_bins = 15;
subplot(3,1,1)
x = StiffnessTaper_Node1to2;
histogram(x,n_bins)
xlim([-2 2])
ylim([0 45])
title('deltaStiffness = (Stiffness_N_o_d_e_1) - (Stiffness_N_o_d_e_2)',"HorizontalAlignment","center")
xlabel('[N/mm]')
text(-1.5,60,'Comparison of Nodes on the Same Stem, Wheat 2021, Instron','EdgeColor','k')
text(-1.8,35,strcat(string(node1Count),' stems were measured.'))

subplot(3,1,2)
x = StrengthTaper_Node1to2;
histogram(x,n_bins)
xlim([-8 8])
ylim([0 45])
title('deltaStrength = (Strength_N_o_d_e_1) - (Strength_N_o_d_e_2)',"HorizontalAlignment","center")
xlabel('[N]')
text(-7.5,35,{'"Node 1" is lowest testable node.','"Node 2" is the next node up.'})

subplot(3,1,3)
x = StrengthTaper_Node1to2;
histogram(x,n_bins)
histogram(NodeMajorDiameterTaper_Node1to2,n_bins)
xlim([-0.5 0.5])
ylim([0 45])
title('deltaDiameter = (MajorDiameter_N_o_d_e_1) - (MajorDiameter_N_o_d_e_2)',"HorizontalAlignment","center")
xlabel('[mm]')
%% Stiffness vs Diameters, Low node 
countPoints=node1Count;
% Stiffness vs Node Major Diameter, Scatter, Auto Fit
hold off
subplot(2,2,1)
x = zeros(node1Count,1);
y = x;
k=1;
for i=1:height(T)
    if T.Node(i)==1
        x(k)=T.NodeMajorDiameter(i);
        y(k)=T.Stiffness(i);
        k=k+1;
    end
end
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(countPoints),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel('Node Major Diameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Node Major Diameter, Wheat 2021, Instron')

%%Stiffness vs Node Minor Diameter, Scatter, Auto Fit
hold off
subplot(2,2,2)
x = zeros(node1Count,1);
y = x;
k=1;
for i=1:height(T)
    if T.Node(i)==1
        x(k)=T.NodeMinorDiameter(i);
        y(k)=T.Stiffness(i);
        k=k+1;
    end
end
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(countPoints),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel('Node Minor Diameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Node Minor Diameter, Wheat 2021, Instron')

% Stiffness vs Internode Major Diameter, Scatter, Auto Fit
hold off
subplot(2,2,3)
x = zeros(node1Count,1);
y = x;
k=1;
for i=1:height(T)
    if T.Node(i)==1
        x(k)=T.InternodeMajorDiameter(i);
        y(k)=T.Stiffness(i);
        k=k+1;
    end
end
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(countPoints),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel(' Internode Major Diameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Internode Major Diameter, Wheat 2021, Instron')

% Stiffness vs Internode Minor Diameter, Scatter, Auto Fit
hold off
subplot(2,2,4)
x = zeros(node1Count,1);
y = x;
k=1;
for i=1:height(T)
    if T.Node(i)==1
        x(k)=T.InternodeMinorDiameter(i);
        y(k)=T.Stiffness(i);
        k=k+1;
    end
end
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(countPoints),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel('Internode MinorDiameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Internode Minor Diameter, Wheat 2021, Instron')
%% Stiffness vs Diameters, Higher node 
countPoints=node2Count;
% Stiffness vs Node Majortext(0.4,35,strcat(string(node1Count),' stems were measured.')) Diameter, Scatter, Auto Fit
hold off
subplot(2,2,1)
x = zeros(node2Count,1);
y = x;
k=1;
for i=1:height(T)
    if T.Node(i)==2
        x(k)=T.NodeMajorDiameter(i);
        y(k)=T.Stiffness(i);
        k=k+1;
    end
end
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(countPoints),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel('Node Major Diameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Node Major Diameter, Wheat 2021, Instron')

%%Stiffness vs Node Minor Diameter, Scatter, Auto Fit
hold off
subplot(2,2,2)
x = zeros(node2Count,1);
y = x;
k=1;
for i=1:height(T)
    if T.Node(i)==2
        x(k)=T.NodeMinorDiameter(i);
        y(k)=T.Stiffness(i);
        k=k+1;
    end
end
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(countPoints),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel('Node Minor Diameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Node Minor Diameter, Wheat 2021, Instron')

% Stiffness vs Internode Major Diameter, Scatter, Auto Fit
hold off
subplot(2,2,3)
x = zeros(node2Count,1);
y = x;
k=1;
for i=1:height(T)
    if T.Node(i)==2
        x(k)=T.InternodeMajorDiameter(i);
        y(k)=T.Stiffness(i);
        k=k+1;
    end
end
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(countPoints),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel(' Internode Major Diameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Internode Major Diameter, Wheat 2021, Instron')

% Stiffness vs Internode Minor Diameter, Scatter, Auto Fit
hold off
subplot(2,2,4)
x = zeros(node2Count,1);
y = x;
k=1;
for i=1:height(T)
    if T.Node(i)==2
        x(k)=T.InternodeMinorDiameter(i);
        y(k)=T.Stiffness(i);
        k=k+1;
    end
end
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(countPoints),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel('Internode MinorDiameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Internode Minor Diameter, Wheat 2021, Instron')
%% Strength vs Diameters, Low node 
%% Strength vs Diameters, Higher node 
%% Diameters vs Diameters, Low node 
%% Diameters vs Diameters, Higher node 
%% Stiffness vs Strength, Low node 
hold off

x = zeros(node1Count,1);
y = x;
k=1;
for i=1:height(T)
    if T.Node(i)==1
        x(k)=T.Stiffness(i);
        y(k)=T.Strength(i);
        k=k+1;
    end
end
p = polyfit(x,y,1);
% Evaluate the fitted polynomial p and plot:
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
legend('data','linear fit')
%mslope=p(1);
%yint=p(2);
%yfit=p(1)*x+p(2);
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(node1Count),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel('Stiffness [N/mm]')
ylabel('Max Force [N]')
title('Stiffness vs Strength, Wheat 2021, Instron, Low Node')
string1 = {strcat(string(n_plots),' plots were tested.')};
text(3,5,string1)
%% Stiffness vs Strength, Higher node
hold off

x = zeros(node2Count,1);
y = x;
k=1;
for i=1:height(T)
    if T.Node(i)==2
        x(k)=T.Stiffness(i);
        y(k)=T.Strength(i);
        k=k+1;
    end
end


p = polyfit(x,y,1);
% Evaluate the fitted polynomial p and plot:
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
legend('data','linear fit')
%mslope=p(1);
%yint=p(2);
%yfit=p(1)*x+p(2);
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(node2Count),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel('Stiffness [N/mm]')
ylabel('Max Force [N]')
title('Stiffness vs Strength, Wheat 2021, Instron, Higher Node')
string1 = {strcat(string(n_plots),' plots were tested.')};
text(3,5,string1)
%% Stiffness vs Strength, Scatter, Auto Fit
hold off
x = T.Stiffness;
y = T.Strength;
p = polyfit(x,y,1);
% Evaluate the fitted polynomial p and plot:
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
legend('data','linear fit')
%mslope=p(1);
%yint=p(2);
%yfit=p(1)*x+p(2);
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(n_nodes),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel('Stiffness [N/mm]')
ylabel('Max Force [N]')
title('Stiffness vs Strength, Wheat 2021, Instron')
string1 = {strcat(string(n_plots),' plots were tested.')};
text(3,5,string1)
%% Stiffness vs DisplacementAtMaxLoad, Scatter, Play with line direction for fun.
% % Fit a polynomial p of degree 1 to the (x,y) data:
% hold off
% title('Max Load vs Displacement at Max Load, Wheat 2021, Instron')
% for j=45%1:n_plots
%     x = T.DisplacementAtMaxLoad((j*10-9):(j*10));
%     y = T.Stiffness((j*10-9):(j*10));
% %     [Y,I]=sortrows(y);
% %     X=x(I);
%     [X,I]=sortrows(x);
%     Y=y(I);
% % X=x;
% % Y=y;
%     
%     plot(X,Y,'--*')
%     hold on
% end
% %legend({'52 Experimental Wheat Plots'},'Location','Northeast')
% xlabel('Displacement at max load [mm]')
% ylabel('Stiffness [N/mm]')
%% Stiffness,Strength, Displacement vs DisplacementAtMaxLoad, Scatter, Auto Fit
% Stiffness vs DisplacementAtMaxLoad, Scatter, Auto Fit
hold off
subplot(3,1,1)
x = T.DisplacementAtMaxLoad;
y = T.Stiffness;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(n_nodes),' Experimental Wheat Stems'),stringFit},'Location','Northeast')
xlabel('Displacement at max load [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Displacement at Max Load, Wheat 2021, Instron')

% Strength vs DisplacementAtMaxLoad, Scatter, Noisy.
hold off
subplot(3,1,2)
x = T.DisplacementAtMaxLoad;
y = T.Strength;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(n_nodes),' Experimental Wheat Stems'),stringFit},'Location','Northeast')
xlabel('Displacement at max load [mm]')
ylabel('Max Load [N]')
title('Strength vs Displacement at Max Load, Wheat 2021, Instron')

% Node Major Diameter vs DisplacementAtMaxLoad, Scatter, Noisy.
hold off
subplot(3,1,3)
x = T.DisplacementAtMaxLoad;
y = T.NodeMajorDiameter;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(n_nodes),' Experimental Wheat Stems'),stringFit},'Location','Northeast')
xlabel('Displacement at max load [mm]')
ylabel('Diameter [mm]')
title('Diameter (Node Major) vs Displacement at Max Load, Wheat 2021, Instron')
%% Stiffness vs Diameters, Scatter Subplots, Auto Fit
% Stiffness vs Node Major Diameter, Scatter, Auto Fit
hold off
subplot(2,2,1)
x = T.NodeMajorDiameter;
y = T.Stiffness;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel('Node Major Diameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Node Major Diameter, Wheat 2021, Instron')

%%Stiffness vs Node Minor Diameter, Scatter, Auto Fit
hold off
subplot(2,2,2)
x = T.NodeMinorDiameter;
y = T.Stiffness;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel('Node Minor Diameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Node Minor Diameter, Wheat 2021, Instron')

% Stiffness vs Internode Major Diameter, Scatter, Auto Fit
hold off
subplot(2,2,3)
x = T.InternodeMajorDiameter;
y = T.Stiffness;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel(' Internode Major Diameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Internode Major Diameter, Wheat 2021, Instron')

% Stiffness vs Internode Minor Diameter, Scatter, Auto Fit
hold off
subplot(2,2,4)
x = T.InternodeMinorDiameter;
y = T.Stiffness;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')
xlabel('Internode MinorDiameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Internode Minor Diameter, Wheat 2021, Instron')
%% Stiffness vs Node Major Diameter (>3mm), Scatter, Auto Fit
hold off
NodeMajorDiameter_above3 = [T.NodeMajorDiameter];
StiffnessSlope_some = [T.Stiffness];
i=1;
while i<=length(NodeMajorDiameter_above3)
    if NodeMajorDiameter_above3(i)<3
        NodeMajorDiameter_above3(i)=[];
        StiffnessSlope_some(i)=[];
        i;
    else
        i=i+1;
    end
end

x = NodeMajorDiameter_above3;
y = StiffnessSlope_some;
p = polyfit(x,y,1);
% Evaluate the fitted polynomial p and plot:
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
legend('data','linear fit')
%mslope=p(1);
%yint=p(2);
%yfit=p(1)*x+p(2);
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({'520 Experimental Wheat Stems',stringFit},'Location','Northwest')

xlabel('Node Major Diameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness and Node Major Diameter Correlation, Wheat 2021, Instron')

string1 = {'Only data from stems with a diameter >3mm included.'};
text(3.1,0.5,string1,'BackgroundColor','w','EdgeColor','k')
%% Stiffness vs Node Major Diameter, through 0, mirrored, Scatter Subplots, parabolic fit
hold off
x1 = T.NodeMajorDiameter;
y = T.Stiffness;
x2= -1.*x1;
%x3 = (linspace(0,0))';
%y3 = (linspace(0,0))';
%X = [x1;x2;x3];
%Y = [y;y;y3];
X = [x1;x2];
Y = [y;y];

%p = polyfit(X,Y,2);
%f = polyval(p,X);
%plot(X,Y,'o',X,f,'-')
plot(X,Y,'o')
%rsq=corr(x,y)^2;
%stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
%legend({strcat(string(n_stems),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel('Node Major Diameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Node Major Diameter, Wheat 2021, Instron')

hold on
plot([7,7],[-20,55])
legend('raw data','D=7mm')
axis([-10,10,-2 50])
%% Strength vs Node Major Diameter, through 0, mirrored, Scatter Subplots, parabolic fit
hold off
x1 = T.NodeMajorDiameter;
y = T.Stiffness;
x2= -1.*x1;
%x3 = (linspace(0,0,100))';
%y3 = (linspace(0,0,100))';
%X = [x1;x2;x3];
%Y = [y;y;y3];
X = [x1;x2];
Y = [y;y];
[X,I]=sortrows(X);
Y=Y(I);

p = polyfit(X,Y,4);
f = polyval(p,X);
plot(X,Y,'o',X,f,'-')
%plot(X,Y,'o')
rsq=string('');
%rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(n_nodes),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel('Node Major Diameter [mm]')
ylabel('Stiffness [N/mm]')
title('Stiffness vs Node Major Diameter, Wheat 2021, Instron')

hold on
plot([7,7],[-20,120])

scatter([0],[0])
%legend('raw data','D=7mm','(0,0)')
axis([1.8,4.7,-0.5,7])
%% Strength vs Diameters, Scatter Subplots, Auto Fit
% Strength vs Node Major Diameter, Scatter, Auto Fit
hold off
subplot(2,2,1)
x = T.NodeMajorDiameter;
y = T.Strength;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(n_nodes),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel('Node Major Diameter [mm]')
ylabel('Strength [N]')
title('Strength vs Node Major Diameter, Wheat 2021, Instron')

% Strength vs Node Minor Diameter, Scatter, Auto Fit
hold off
subplot(2,2,2)
x = T.NodeMinorDiameter;
y = T.Strength;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(n_nodes),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel('Node Minor Diameter [mm]')
ylabel('Strength [N]')
title('Strength vs Node Minor Diameter, Wheat 2021, Instron')

% Strength vs Internode Major Diameter, Scatter, Auto Fit
hold off
subplot(2,2,3)
x = T.InternodeMajorDiameter;
y = T.Strength;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(n_nodes),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel(' Internode Major Diameter [mm]')
ylabel('Strength [N]')
title('Strength vs Internode Major Diameter, Wheat 2021, Instron')

% Strength vs Internode Minor Diameter, Scatter, Auto Fit
hold off
subplot(2,2,4)
x = T.InternodeMinorDiameter;
y = T.Strength;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(n_nodes),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel('Internode MinorDiameter [mm]')
ylabel('Strength [N]')
title('Strength vs Internode Minor Diameter, Wheat 2021, Instron')
%% Diameters vs Diameter, Scatter, Auto Fit
% Node Major Diam vs Node Minor Diam, Scatter, Auto Fit
hold off
subplot(2,2,1)
x = T.NodeMinorDiameter;
y = T.NodeMajorDiameter;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(n_nodes),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel('Node Minor Diameter [mm]')
ylabel('Node Major Diameter [mm]')
title('Node Major Diameter vs Node Minor Diameter, Wheat 2021')

% Node Major Diam vs Internode Major Diam, Scatter, Auto Fit
hold off
subplot(2,2,2)
x = T.InternodeMajorDiameter;
y = T.NodeMajorDiameter;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(n_nodes),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel('Internode Major Diameter [mm]')
ylabel('Node Major Diameter [mm]')
title('Node Major Diameter vs Internode Major Diameter, Wheat 2021')

% Node Major Diam vs Internode Minor Diam, Scatter, Auto Fit
hold off
subplot(2,2,3)
x = T.InternodeMinorDiameter;
y = T.NodeMajorDiameter;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(n_nodes),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel('Internode Minor Diameter [mm]')
ylabel('Node Major Diameter [mm]')
title('Node Major Diameter vs Internode Minor Diameter, Wheat 2021')

% Internode Major Diam vs Internode Minor Diam, Scatter, Auto Fit
hold off
subplot(2,2,4)
x = T.InternodeMinorDiameter;
y = T.InternodeMajorDiameter;
p = polyfit(x,y,1);
f = polyval(p,x);
plot(x,y,'o',x,f,'-')
rsq=corr(x,y)^2;
stringFit = strcat('y=',string(p(1)),'*x+',string(p(2)),', R^2 = ',string(rsq));
legend({strcat(string(n_nodes),' Experimental Wheat Stems'),stringFit},'Location','Northwest')
xlabel('Internode Minor Diameter [mm]')
ylabel('Internode Major Diameter [mm]')
title('Internode Major vs Internode Minor Diameter, Wheat 2021')
%% Box plots - Diameters, by Plot and Variety
% Attmept to create labels for tight boxplots, to only show one reduntant
% variety label.
labelList=T.Variety;
labelIdx=zeros(length(labelList),1);
k=1;
labelIdx(1)=k;
for i=2:length(labelList)
    if labelList(i-1)==labelList(i)
        labelIdx(i)=0;
    else
        k=k+1;
        labelIdx(i)=k;
    end
end

for i =1:length(labelIdx)
    if labelIdx(i)==0
        labelList(i)=NaN;
    end
end

% Box plot - Node Major Diameters, by Plot and Variety
hold off
subplot(2,2,1)
boxplot(T.NodeMajorDiameter,T.Plot,'labels',T.Variety+','+T.Plot,'labelverbosity','minor')%
%boxplot(T.NodeMajorDiameter,T.Plot,'labels',labelList,'labelverbosity','minor')%
ylabel('Diameter [mm]') % 
title('Node Major Diameters, each Wheat Plot, 2021')
xtickangle(70)
hold on
% show vertical lines to separate variety groups
x1=4.5;
xn=x1;
for k=1:12
    plot([xn,xn],[-100,100],'-k')
    xn=xn+4;
end
htext=text(45,-1,'10 stems were measured from each of the 52 plots.','BackgroundColor','w','EdgeColor','k'); 

% Box plot - Node Minor Diameter, by Plot and Variety
hold off
subplot(2,2,2)
boxplot(T.NodeMinorDiameter,T.Plot,'labels',T.Variety+','+T.Plot,'labelverbosity','major')%
ylabel('Diameter [mm]') % 
title('Node Minor Diameters, each Wheat Plot, 2021')
xtickangle(70)
hold on
% show vertical lines to separate variety groups
x1=4.5;
xn=x1;
for k=1:12
    plot([xn,xn],[-100,100],'-k')
    xn=xn+4;
end
%htext=text(35,4.5,'10 stems were measured from each of the 52 plots.','BackgroundColor','w','EdgeColor','k'); 

% Box plot - Internode Major Diameter, by Plot and Variety
hold off
subplot(2,2,3)
boxplot(T.InternodeMajorDiameter,T.Plot,'labels',T.Variety+','+T.Plot,'labelverbosity','minor')%
ylabel('Diameter [mm]') % 
title('Internode Major Diameters, each Wheat Plot, 2021')
xtickangle(70)
hold on
% show vertical lines to separate variety groups
x1=4.5;
xn=x1;
for k=1:12
    plot([xn,xn],[-100,100],'-k')
    xn=xn+4;
end
%htext=text(35,4.5,'10 stems were measured from each of the 52 plots.','BackgroundColor','w','EdgeColor','k'); 

% Box plot - Internode Minor Diameter, by Plot and Variety
hold off
subplot(2,2,4)
boxplot(T.InternodeMinorDiameter,T.Plot,'labels',T.Variety+','+T.Plot,'labelverbosity','major')%
ylabel('Diameter [mm]') % 
title('Internode Minor Diameters, each Wheat Plot, 2021')
xtickangle(70)
hold on
% show vertical lines to separate variety groups
x1=4.5;
xn=x1;
for k=1:12
    plot([xn,xn],[-100,100],'-k')
    xn=xn+4;
end
%htext=text(35,4.5,'10 stems were measured from each of the 52 plots.','BackgroundColor','w','EdgeColor','k'); 
%% Box plot - Four diameter measurements
hold off
diameterMatrix = zeros(height(T),4);
diameterMatrix(:,1)=[T.NodeMajorDiameter];
diameterMatrix(:,2)=[T.NodeMajorDiameter];
diameterMatrix(:,3)=[T.InternodeMajorDiameter];
diameterMatrix(:,4)=[T.InternodeMinorDiameter];
diameterLabels = {'Node Major','Node Minor','Internode Major','Internode Minor'};
boxplot(diameterMatrix,diameterLabels)
% boxplot(T.NodeMajorDiameter,0)%
% boxplot(T.NodeMinorDiameter,0)
% boxplot(T.InternodeMajorDiameter,0)
% boxplot(T.InternodeMajorDiameter,0)
ylabel('Diameter [mm]') % 
title('Diameter Measurements, for each Wheat Plot, 2021')
%xtickangle(70)
%% Box plot - Stiffness Percent Difference, Node Comparison, by Plot
hold off
boxplot(Tn.StiffnessPercentDifference,Tn.Plot,'labels',Tn.Variety+','+Tn.Plot,'labelverbosity','minor')%,T.InternodeMajorDiameter,T.InternodeMinorDiameter)
ylabel('% Difference [(N/mm)/(N/mm)]') % 
title('Stiffness Percent Difference, Node Comparison, for each Wheat Plot, 2021')
xtickangle(70)

hold on
% show vertical lines to separate variety groups
% This is still broken
x1=4.5; %assumes first variety shown has four plots represented
xn=x1;
for is=1:height(Tn)
    plot([xn,xn],[-100,100],'-k')
    %xn=xn+4;
    %if Tn.Variety(is)~=Tn.Variety(is+1)
    %    xn = Tn.Variety(is+1) - xn
    %end
%     if xn<k
%         xn=xn+sum(Tn.Plot(is)==Tn.Plot)
%     end
    if xn<is && Tn.Variety(is)~=Tn.Variety(is+1) %&& xn<k
        xn=xn+sum(Tn.Plot(is)==Tn.Plot)
    end
end

% plot horizontal line at zero
plot([0,height(Tn)],[0,0],'o--')
%% Box plot - Stiffness, by Plot
hold off
boxplot(T.Stiffness,T.Plot,'labels',T.Variety+','+T.Plot,'labelverbosity','minor')%,T.InternodeMajorDiameter,T.InternodeMinorDiameter)
ylabel('Stiffness [N/mm]') % 
title('Stiffness, for each Wheat Plot, 2021')
xtickangle(70)

hold on
% show vertical lines to separate variety groups
x1=4.5;
xn=x1;
for k=1:12
    plot([xn,xn],[-100,100],'-k')
    xn=xn+4;
end

htext=text(36,5.9,'10 stems were measured from each of the 52 plots.','BackgroundColor','w','EdgeColor','k');
%% Box plot - Strength, by Plot
hold off
boxplot(T.Strength,T.Plot,'labels',T.Variety+','+T.Plot,'labelverbosity','minor')%,T.InternodeMajorDiameter,T.InternodeMinorDiameter)
ylabel('Strength [N]') % 
title('Max Force, for each Wheat Plot, 2021')
xtickangle(70)

hold on
% show vertical lines to separate variety groups
x1=4.5;
xn=x1;
for k=1:12
    plot([xn,xn],[-100,100],'-k')
    xn=xn+4;
end

htext=text(36,22,'10 stems were measured from each of the 52 plots.','BackgroundColor','w','EdgeColor','k');
%% Box plot - Strength, total
hold off
boxplot(T.Strength,1)
ylabel('Max Force [N]') % 
xlabel('') % 
title('Strength of 520 Stems, from 52 Plots, Wheat 2021, Instron')
%% Box plot - Stiffness, total
hold off
boxplot(T.Stiffness,1)
ylabel('Stiffness [N/mm]') % 
xlabel('') % 
title('Stiffness of 520 Stems, from 52 Plots, Wheat 2021, Instron')
%% PLOTTING generated abive this line ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
%% FUNCTIONS store below this line .......................................
%% End matter
cd(directory_script)


