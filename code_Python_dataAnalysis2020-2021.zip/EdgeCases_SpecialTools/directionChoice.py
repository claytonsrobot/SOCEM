import math
import pandas as pd
from pandas import ExcelFile
from pandas import ExcelWriter
# import peakutils
import matplotlib.pyplot as plt
from matplotlib.widgets import Cursor
# from peakutils.plot import plot as pplot
import numpy as np
from datetime import date
import os

folderToProcess = r'C:/Users/clayton/OneDrive - University of Idaho/AqMEQ/SOCEM/SAVED_DATA_2021/August23/cleanRaw'

filenames = os.listdir(folderToProcess)
filename = filenames[1]
print(filename)


stringsEast = ['forward', 'east']
stringsSouth = ['side','perpindicular','leftToRight','south']
stringsWest = ['backwards','reverse','west']
stringsNorth = ['north', 'rightToLeft']
if (stringsEast[0] in filename) or (stringsEast[1] in filename):
    direction = 'forward'
    rows = 3
    print(direction)
    
elif (stringsWest[0] in filename) or (stringsWest[1] in filename) or (stringsWest[2] in filename):
    direction = 'reverse'
    rows = 3
    print(direction)
    
elif (stringsSouth[0] in filename) or (stringsSouth[1] in filename) or (stringsSouth[2] in filename) or (stringsSouth[3] in filename):
    direction = 'leftToRight'
    rows = 6
    print(direction)

elif (stringsNorth[0] in filename) or (stringsNorth[1] in filename):
    direction = 'rightToLeft'
    rows = 6
    print(direction)

else:
    direction = 'forward'
    rows = 3
    print(direction)







