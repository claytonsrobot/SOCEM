% Title: InstronDataPlotter
% Purpose: Print plots for rich INSTRON data, and input overview data, to check validity.
% Author: Clayton Bennett
% Date created: 2 August 2021
% Last updated: 2 August 2021

% User notes: Meant to be run manually section-by-section.
% Not all sections will apply to all datasets.
%% Set where graphs will be saved.
directory; % type in manually. Where raw Instron files live, pulled in in previous scripts.
directory_processingCode = ('C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\ProcessingCode\'); % not thoroughly modular, if the script location changes.
directory_saveGraphs = strcat(directory,'MATLABGraphs\loopTest\'); %modular

%% Instron Data overviews, function version
% Plots all possible comparisons for each axes list for each table.
list_IAxes={'I.AveEI','I.AveMaxLoad','I.AveMaxMoment','I.AveDisplacementAtMaxLoad'};
list_TAxes={'T.DisplacementAtMaxLoad','T.EI','T.LoadDeflectionSlope','T.MaxLoad','T.MaxMoment'};
list_axes={list_IAxes,list_TAxes};

toggle_save = 0; % 1 for save, 0 for don't save

cd(directory_processingCode) % To return to the directory where this script lives.

for l=1:numel(list_axes)
    for a=1:numel(list_axes{l})
        for b=1:numel(list_axes{l})
            if a ~= b
                [handle_plot_tableData,filenametext]=plot_tableData(list_axes{l}{a},list_axes{l}{b},toggle_save,directory_saveGraphs,T,I); % only change first three inputs: xdata, ydata, toggle_save
                cd(directory_processingCode) % To return to the directory where this script lives.
            end
        end
    end
end

%filenametext=plot_tableData('I.AveEI','I.AveMaxMoment',0,directory_saveGraphs,T,I); % only change first three inputs: xdata, ydata, toggle_save
%cd(directory_processingCode) % To return to the directory where this script lives.

close(handle_plot_tableData) % supressed 11/29/2021
%close
%% Sandbox: cycle through all vargnames
%% Instron Data overviews, script version

% I want to autpomatically generate the title, axis labels, and filename.

        % %% Edit these things:
        xdata='I.AveEI'; % Making it a string is necessary.
        ydata='I.AveLoadDeflectionSlope';
        %I.AveDisplacementAtMaxLoad
        string_table = 'I';
        toggle_save = 1;
        % %%%

% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %%

% %% Vars necessry to be in the workspace:
directory_saveGraphs;
directory_processingCode;

% %%%

% %%
% Important plots, from table T:
% LoadDeflectionSlope vs MaxLoad
%I.e. LoadDeflectionSlope vs MaxMoment
%I.e. EI vs MaxMoment
% See InstronCOlumnMagic_3.m for calculation details
% %% %%

cd(directory_saveGraphs) % To control where the graphs are saved.

% Use eval() to pull in whichever X and Y was listed above. YES!!
handle_plot= plot(eval(xdata),eval(ydata),'b+');

set(handle_plot,'XDataSource',xdata)
set(handle_plot,'YDataSource',ydata)

string_title=strcat(xdata,'_.versus_.',ydata);
title(string_title)

%columnX=;
%xunit=I.Properties.VariableUnits(columnX);
%I.Properties.VariableNames

string_xlabel = strcat(extractAfter(xdata,'.')); % Assumes the data comes from a table
string_ylabel = strcat(extractAfter(ydata,'.')); % Assumes the data comes from a table

for column = 1:numel(eval(string_table).Properties.VariableNames)
    if string(eval(string_table).Properties.VariableNames(column)) == string_xlabel
       string_xlabel = string(strcat(string_xlabel,'_.(',eval(string_table).Properties.VariableUnits(column),')'));
    elseif string(eval(string_table).Properties.VariableNames(column)) == string_ylabel
       string_ylabel = string(strcat(string_ylabel,'_.(',eval(string_table).Properties.VariableUnits(column),')'));
    end
end

% HOW DO I ADD A SPACE IN TEXT? Instead of an underscore and a period, which works well enough.

xlabel(string_xlabel)
ylabel(string_ylabel)

% This doesn't help me, because I can manually list the name, though it
% does make it easier to read and is a candidate.
handle_xlabel = get(gca,'XLabel');
handle_ylabel = get(gca,'YLabel');

fig = gcf;
filenametext = strcat(erase(string_title,'.'),'.png');

% Sometimes, you might not want to save the image to a file.
if toggle_save == 'yes' | toggle_save == 1 
    exportgraphics(fig, filenametext,'Resolution',300)
end

cd(directory_processingCode) % To return to the directory where this script lives.

%% Individual Instron graphs, with raw data and Load Deflection slope.
% Is T.Modulus from the overview files valid? It should be. Plot it.
% T.LoadDeflectionSlope from the overview files is not trusted and has been
%   replaced.
% Plot the new T.LoadDelfectionSlope (N/mm), which is a function of
% T.Modulus (MPa)
% Don't use this.
directory_saveGraphs = strcat(directory,'MATLABGraphs\');
cd(directory_saveGraphs) % To control where the graphs are saved.
for t=1:height(T)
    %plot(cell2mat(T.Time(t)),cell2mat(T.Force(t)))
    plot(cell2mat(T.Displacement(t)),cell2mat(T.Force(t)));
    hold on
    plot([0,T.DisplacementAtMaxLoad(t)],[0,T.LoadDeflectionSlope(t)*T.DisplacementAtMaxLoad(t)],'r-')
    title(strcat('Plot:',T.Plot(t),',Stem:',string(T.Stem(t)),',Run:',string(T.Run(t))));
    xlabel('Deflection (mm)');
    ylabel('Force (N)');
    fig =  gcf;
    filename_plot = strcat(string(T.Plot(t)),'_stem',string(T.Stem(t)),'_run',string(T.Run(t)),'.png');
    exportgraphics(fig, filename_plot,'Resolution',300)

    filename_plot
    
    hold off
end
cd(directory_processingCode) % To return to the directory where this script lives.
%% Whole plot graphs
directory_processingCode = ('C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\ProcessingCode\'); % not thoroughly modular, if the script location changes.
directory_saveGraphs = strcat(directory,'MATLABGraphs\'); %modular
cd(directory_saveGraphs) % To control where the graphs are saved.

%if cyclic_workspace == 'non-cyclic' ||
    for t=1:height(T)
        %plot(cell2mat(T.Time(t)),cell2mat(T.Force(t)))
        plot(cell2mat(T.Displacement(t)),cell2mat(T.Force(t)));
        % add in legend, inidividual numbers, and averages
        
        if t == height(T) % final pass, where t+1 > height(t)
            title(strcat('Plot:',T.Plot(t)));
            xlabel('Deflection (mm)');
            ylabel('Force (N)');
            fig =  gcf;
            exportgraphics(fig, strcat(string(T.Plot(t)),'.png'),'Resolution',300)
            directory_saveGraphs = strcat(directory,'individualGraphs\');
            hold off
            
        elseif T.Plot(t) == T.Plot(t+1)
            hold on
            %string_textbox = sprintf(append(string_textbox,'\n',string(T.Stem(t)),',',sprintf('%4.2f',T.LoadDeflectionSlope(t)),',',sprintf('%4.2f',T.EI(t))));
        elseif T.Plot(t) ~= T.Plot(t+1)
            title(strcat('Plot:',T.Plot(t)));
            xlabel('Deflection (mm)');
            ylabel('Force (N)');
            %handle_legend = legend(); % How do I accumulate each Stem?
            %dim_textbox = [.2 .7 .3 .2];
            %string_textbox = sprintf(append(string_textbox,'\n',string(T.Stem(t)),',',sprintf('%4.2f',T.LoadDeflectionSlope(t)),',',sprintf('%4.2f',T.EI(t))));
            %handle_textbox = annotation('textbox',dim_textbox,'String',string_textbox);
            % CONTINUE WORKING HERE
            fig =  gcf;
            exportgraphics(fig, strcat(string(T.Plot(t)),'.png'),'Resolution',300)
            directory_saveGraphs = strcat(directory,'individualGraphs\');
            hold off
            %close gcf
            %dim_textbox = [.2 .7 .3 .2];
            %string_textbox = sprintf('Stem, LoadDeflectionSlope, EI');
            %clear handle_textbox
            
        end
    end
%end
cd(directory_processingCode) % To return to the directory where this script lives.
%% Whole Stem graphs, with repated runs, for cyclic tests
for t=1:height(T)
    %plot(cell2mat(T.Time(t)),cell2mat(T.Force(t)))
    plot(cell2mat(T.Displacement(t)),cell2mat(T.Force(t)));
    if T.Stem(t) == T.Stem(t+1)
        hold on
    elseif T.Stem(t) ~= T.Stem(t+1)
        title(strcat('Plot:',T.Plot(t),',Stem:',string(T.Stem(t))));
        xlabel('Deflection (mm)');
        ylabel('Force (N)');
        fig =  gcf;
        exportgraphics(fig, strcat(string(T.Plot(t)),'_stem',string(T.Stem(t)),'.png'),'Resolution',300)
        directory_saveGraphs = strcat(directory,'individualGraphs\');
        hold off
    end
end
%% All data in directory overview
% Different colors for differnt variety types