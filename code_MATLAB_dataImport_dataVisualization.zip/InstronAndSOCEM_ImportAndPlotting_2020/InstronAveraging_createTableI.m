% InstronAveraging_creatgeTableI
%% header
% Author: Clayton Bennett
% Updated: 3/25/2021
% Purpose: Create table I, the formatted wheat Instron file, prepared for
%   comparison.
% User notes: 
%   - The purpose of this script is to take the prepared Instron
%       data file and to prepare it further for comparison to the SOCEM 
%       data file.
%   - All sections are meant to be run one at a time.
%   - Once complete, I will be ready to be used by
%       "InstronSocemComparisonPlotting.m"
%   - Table T is required to exist in the MATLAB workspace. It can be found
%       by loading "wheatInstron2020_IndividualAndOverview.mat".
%% Initialize Table
% WARNING DO NOT RUN THIS AGAIN
% Commented out for security
% varnames = {'Name','Plot','AveLoadDeflectionSlope','StdLoadDeflectionSlope','AveMaxLoad','StdMaxLoad','AveDisplacementAtMaxLoad','StdDisplacementAtMaxLoad','AveMaxMoment','StdMaxMoment','AveMaxEI','StdMaxEI'};
% I = cell2table(cell(64,12), 'VariableNames', varnames);%, 'RowNames', rownames);
% I.Name = strings([height(I),1]);
% I.Plot = strings([height(I),1]);

%% name formatting, prep for comparison
% T is the table from 'wheatInstron2020_IndividualAndOverview.mat'
for k=1:height(T)
T.Plot{k}=strrep(T.Plot{k},'clearfield','CF');
T.Plot{k}=strrep(T.Plot{k},'hardwinter','HW');
T.Plot{k}=strrep(T.Plot{k},'softwinter','SW');
T.Plot{k}=erase(T.Plot{k},'b');
end

%% Identify different plot names, Pass from T to I
 % for some plotname, look at all of the numbers some column,
 % average them and std them, assigning these to tables of some index with
 % a matching plotname
 % Repeat for multple columns before moving on to the next plotname
 % T has ~544 rows, I has ~64 rows
i=1;
for k=1:height(T)
     if T.Stem{k}==1
         I.Plot{i}=T.Plot{k};
         i=i+1;
     end
end
%% 
idx_plot=zeros(height(T),1);
listLDS=[];
listML=[];
listDML=[];

for k=1:height(I)
    idx_plot=zeros(height(T),1);
    listLDS=[];
    listML=[];
    listMM=[];
    listDML=[];
    listEI=[];
    for i=1:height(T)
        if I.Plot{k}==T.Plot{i}
            Tplot=T.Plot{i}
            Iplot=I.Plot{k}
            idx_plot(i)=1;
            listLDS(end+1)=T.LoadDeflectionSlope(i);
            listML(end+1)=T.MaxLoad(i);
            listMM(end+1)=T.MaxMoment(i);
            listDML(end+1)=T.DisplacementAtMaxLoad(i);
            listEI(end+1)=T.EI(i);
        end
    end
    I.AveDisplacementAtMaxLoad{k}=mean(listDML);
    I.StdDisplacementAtMaxLoad{k}=std(listDML);
    I.AveLoadDeflectionSlope{k}=mean(listLDS);
    I.StdLoadDeflectionSlope{k}=std(listLDS);
    I.AveEI{k}=mean(listEI);
    I.StdEI{k}=std(listEI);
    I.AveMaxLoad{k}=mean(listML);
    I.StdMaxLoad{k}=std(listML);
    I.AveMaxMoment{k}=mean(listMM);
    I.StdMaxMoment{k}=std(listMM);

end
%% Reformat, cell to string
for k=1:height(T)
    T.Plot{k}=string(T.Plot(k));
end
%% Units and descriptions
%varnames = {'Name','Plot','AveLoadDeflectionSlope','StdLoadDeflectionSlope','AveMaxLoad','StdMaxLoad','AveDisplacementAtMaxLoad','StdDisplacementAtMaxLoad','AveMaxMoment','StdMaxMoment','AveEI','StdEI'};
I.Properties.VariableUnits = {'', '', 'N/mm', 'N/mm', 'N', 'N', 'mm', 'mm', 'N*mm', 'N*mm', 'N*mm^2', 'N*mm^2'};
I.Properties.VariableDescriptions{'AveLoadDeflectionSlope'} = '';
I.Properties.VariableDescriptions{'StdLoadDeflectionSlope'} = '';
I.Properties.VariableDescriptions{'AveDisplacementAtMaxLoad'} = '';
I.Properties.VariableDescriptions{'StdDisplacementAtMaxLoad'} = '';
I.Properties.VariableDescriptions{'AveEI'} = '';
I.Properties.VariableDescriptions{'StdEI'} = '';
I.Properties.VariableDescriptions{'AveMaxLoad'} = '';
I.Properties.VariableDescriptions{'StdMaxLoad'} = '';
I.Properties.VariableDescriptions{'AveMaxMoment'} = '';
I.Properties.VariableDescriptions{'StdMaxMoment'} = '';

%% Identify missing plots and 
k=1;
while k<=height(S)
    if I.Plot{k}==S.Plot{k}
        I.Name{k}=S.Name{k};
        k=k+1;
    else
        notInvolved=S.Plot{k}
        k=k+1;
    end
    
end
listNames={'CF416','HW323','SW326'}; % plots not represented in the SOCEM data
% Deleted rows manually
listNames2 = {'SW229','SW338','SW224','SW428','SW115','SW106','HW410'}; % Plots from SOCEM data not represented in INSTRON data
% Deleted rows manually
%% Check for SOCEM data not represented in Instron data
% socemVsLodging_Wheat2020_metric_missingRemoved57
for i=1:height(S) %run through each row of the Socem table S
    idx=zeros(64,1);
    for k=1:height(I) % for each row of Socem table S, run through all rows of Instron table I, comparing plot names
        
        if I.Plot{k}==S.Plot{i} % if the name matches:
            idx(i)=1; % then count it as a match, in a way that can be summed for each row of Instron table I
        end
    end
    if sum(idx)==0 % if the sum of counts is zero, meanings that the SOCEM plot at row i does not have the same name as any Instron plot in table I:
        i % then display index of Socem table
        S.Plot{i} % then display name of SOCEM plot that is not in Instron data
    end

end
%% formatting
I.Name = convertStringsToChars(I.Name);
I.Plot = convertStringsToChars(I.Plot);
I=sortrows(I); % Sort I by the first column, then the second column, to math the given order for the Socem rows
%% check plot lineup
% here, table M is the SOCEM data table, in the workspace
for k=1:57
    if M.Plot{k}==I.Plot{k}
        M.Plot{k}
    else
        k
    end
    
end


%% reformat for ease of numerical access
I.AveMaxLoad=cell2mat(I.AveMaxLoad);
I.AveEI=cell2mat(I.AveEI);
I.AveLoadDeflectionSlope=cell2mat(I.AveLoadDeflectionSlope);
I.AveMaxMoment=cell2mat(I.AveMaxMoment);
I.StdMaxLoad=cell2mat(I.StdMaxLoad);
I.StdEI=cell2mat(I.StdEI);
I.StdLoadDeflectionSlope=cell2mat(I.StdLoadDeflectionSlope);
I.StdMaxLoad=cell2mat(I.StdMaxLoad);
I.StdDisplacementAtMaxLoad=cell2mat(I.StdDisplacementAtMaxLoad);

