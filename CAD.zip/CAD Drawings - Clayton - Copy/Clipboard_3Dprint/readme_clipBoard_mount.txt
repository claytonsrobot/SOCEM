Designer: Clayton Bennett
Fabrication: 3D printing, with nylon filament
The purpose of this part is to attach a clipboard to a GoPro wrist mount.

Cut clipboard to 5.2" x 3.2", or greater.
Use brass threaded insert in the 3D printed part.
Drill small holles in the clipboard aligned with holes in 3D printed part.
Use cap head bolts to attach clipboard to 3D printed part.
Attach 3D printed part to wrist mount using included bolt in wrist mount kit.

GoPro wrist mount: https://www.amazon.com/SUREWO-Rotating-Compatible-Session-Campark/dp/B07H4MSW9Q/ref=sr_1_1_sspa?crid=11S2K9R43YBAZ&keywords=gopro+wrist+mount&qid=1665981147&qu=eyJxc2MiOiIzLjc4IiwicXNhIjoiMy4xOSIsInFzcCI6IjIuOTEifQ%3D%3D&sprefix=go+pro+wrist+moun%2Caps%2C146&sr=8-1-spons&psc=1
clipboard: https://www.amazon.com/AmazonBasics-DHCB001-6-Hardboard-Clipboard-6-Pack/dp/B07FF3R4XQ/ref=sr_1_1_sspa?crid=2F0VVFZ4OCQOJ&keywords=clipboard&qid=1665981191&qu=eyJxc2MiOiI3LjEwIiwicXNhIjoiNi4yOSIsInFzcCI6IjUuODMifQ%3D%3D&sprefix=clipboard%2Caps%2C157&sr=8-1-spons&psc=1