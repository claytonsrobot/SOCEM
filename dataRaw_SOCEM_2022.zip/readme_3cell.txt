We took the middle portion ran 1 pass Seahawk sws210 named it side 1
