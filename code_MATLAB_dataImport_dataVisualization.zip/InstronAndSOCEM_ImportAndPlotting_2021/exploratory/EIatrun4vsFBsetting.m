%% EI for Run==4 vs fb setting
% filterdata.m
% Author: Clayton Bennett
% Purpose: View and/or separate out data by heuristic

%% fuction version
% Create X and Y plottable values for two different groups. Can nest.
directory_code = ('D:\Instron Wheat Testing 2021\MatlabCode\exploratory'); % not thoroughly modular, if the script location changes.
directory_codeTools = ('D:\Instron Wheat Testing 2021\MatlabCode\');
directory_saveGraphs = ('D:\Instron Wheat Testing 2021\SAVED_DATA_2021\graphs\'); %modular
cd(directory_saveGraphs) % To control where the graphs are saved.
cd(directory_codeTools)

initialtable = Tall;

string_table = 'usetable';
string_xdata = 'usetable.ForceBarHeight';
string_ydata = 'usetable.EIM';
xdata = eval(string_xdata);
ydata = eval(string_ydata);


string_titleBack = {'EI vs FB Height, 4th runs, SOCEM 2021'};% preceded by variety name
string_exportfilenamedetail = {'varietyEI,allPlots'};


%mat_ax = [0.8,4.2,0,18];

%% label maker
string_xlabel = strcat(extractAfter(string_xdata,'.')); % Assumes the data comes from a table
string_ylabel = strcat(extractAfter(string_ydata,'.')); % Assumes the data comes from a table
for column = 1:numel(eval(string_table).Properties.VariableNames)
    if string(eval(string_table).Properties.VariableNames(column)) == string_xlabel
       string_xlabel = string(strcat(string_xlabel,'_.(',eval(string_table).Properties.VariableUnits(column),')'));
    elseif string(eval(string_table).Properties.VariableNames(column)) == string_ylabel
       string_ylabel = string(strcat(string_ylabel,'_.(',eval(string_table).Properties.VariableUnits(column),')'));
    end
end

%%
varieties = unique(initialtable.Variety);

col1 = "j";
keep1 = 4;
heur1 = initialtable(keep1 == initialtable.(col1),:);

col2 = "Plot";
toss2 = {'SW429'};
%heur2 = heur1(not(toss2 == heur1.(col2)),:);
heur2=heur1;
for i=1:length(toss2)
    heur2 = heur2(not(toss2{i}==heur2.(col2)),:);
end

col3 = "Hour";
keep3 = 0;
heur3 = heur2(keep3 == heur2.(col3),:);

usetable = heur2;

x = usetable.ForceBarHeight;
y = usetable.EIM;

%plot(xdata,ydata,'*-')
[abc,a,b,c,rsq,rmse,sse,lm,f0,string1]=linearFitting(xdata,ydata,1,1,1);
ha=annotation(gcf,'textbox',[0.121,0.78,1,1],'String',string1,'EdgeColor','none','FitBoxToText','on','verticalalignment', 'bottom', 'color','k');
    
%hleg = legend(legendstring);
string_title = strcat(string_titleBack);
title(string_title)
xlabel(string_xlabel)
ylabel(string_ylabel)

%stringtxt = {['While R^2 is only 0.38, this'],['suggests that force bar height setting'],['impacts EI, which it should not.']};
%text(2.1,7,stringtxt)
%axis(mat_ax)
%xticks([1,2,3,4])

cd(directory_code)
