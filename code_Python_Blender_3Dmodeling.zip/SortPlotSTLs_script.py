'''
Title: SortPlotSTLs.py
Author: Clayton Bennett
Date created: 6/14/2022

Description: Refernce STL files in a directory based on a text identifier. Pull in name list. Sort names beased on uniqueness, for type (CF, HW, SW) and for genetici variety.

Inputs: Directory, text identifier.
Modifiers: X spacing between plots of the same genetic variety. X spacing between plots of the same type bu different genetic variety. Y spacing between types.
Outputs: X and Y coorinates for each STL origin.

Steps:
1) Make list of each plot, correlated to lists of varieties and types. These will be in alphabetical order by variety, and then by plot number. Each plot (example: SW429) in a given genetic variety (example: Purl) will be of the same type (CF, HW, SW)
2) Identify unique types (CF, HW, SW). For each element in this list, add a unique y coordinate (list name: yType)
3) Identify and count unique varieties in each type. For type with max number of unique varieties, assign that number of xbasecoord entries to be in denomination of xSpacingVarieties (list name: xbasecoord)
4) For each type, look at each variety. For each variety, identify list of plots. For all indicies in a type, apply the yType value to the ycoord list. For the first plot in each variety, assign the xbasecoord value to its index xcoord.
5) At this point, the xcoord list only shows the xbasecoord values, with xSpacingVarities, and all other entries being 0. Look for zeros, and assign to that index the value of xSpacingPlots plus the value of the previous index xcoord.


Improvements:
Don't trust which order they came in. Make an OG arbitary list, a target sorted list, and the intermediates.
'''
import sys
import os
import math
#import mathutils
import numpy as np

def unique(listIn):
    listUnique = []
    for x in listIn:
        if x not in listUnique:
            listUnique.append(x)
    return listUnique


#def plotcoordinates(textIdentifier, directory):
    
textIdentifier = "_50x50_EI_nearest_sideHitExperiment.stl"
textIdentifier = "_50x50_EI_nearest_baseExperiment.stl"
textIdentifier = "_210x210_peaksUsed_noFloor.stl"
directory = r'E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\CAD Drawings - Clayton\FieldMap'

xSpacingPlots = 50
xSpacingVarieties = 300
ySpacingTypes = 200

filelistIdentified = []
varietylist = []
plotlist = []
typelist = []

xcoord = []
ycoord = []

for filename in os.listdir(directory): # look at every file in the directory
    if textIdentifier in filename: # look at only files what inclue the text identifier string
        filelistIdentified.append(filename) # add each filename to an ordered list 
        textParse = filename.replace(textIdentifier,"") # look at the part of the filename that is not the text identifer string
        try: # if variety is included
            plot = textParse.split(",",2)[1] # identify the plot name based on the filename, using expected naming convention
            varietylist.append(textParse.split(",",2)[0]) # add the variety name to an ordered list. the variety name is based on the filename, using expected naming convention
        except: # if variety is NOT included
            varietylist.append("") # broken here
            plot = textParse.split("_",1)[0]
        plotlist.append(plot) # add the plot name to an ordered list. 
        typelist.append(plot[0:2]) # add the type to an ordered list. type name can be extracted from the plot name, usimg expected naming convention.
        xcoord.append(0) # fill zeros to the same number of the relevant STL files
        ycoord.append(0) # fill zeros to the same number of the relevant STL files
filenames_long =[]
for filename in filelistIdentified:
    filenames_long.append(directory+'\\'+filename) # turn the short filename into a long filename

# idenfity type and variety 
types = unique(typelist)
print(types)
varieties = unique(varietylist)
print(varieties)

numelTypes = len(types)
numelVarieties = len(varieties)

yType=[]
idx=0
for typ in types:
    yType.append(idx*ySpacingTypes)
    idx+=1

# different types will be spread out in the Y coordinate direction
trackstringY = "abcdefghijklmnopqrstuvwxyz" # this varibale is meant to track the varieties that are in each type
[a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z] = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0] # [[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],[''],['']]#
if numelTypes > 26: # extremely unlikely.
    print('The script does not expect more than 26 types of wheat. Clayton does not expect more than 3 types of wheat: CF, HW SW. There is probably an error. If not, please add a sufficient number of tracks.')


# varieties within a type will be spread out in the X coordinate direction
trackstringX = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" # this variable reflects the type that correlates with the same lowercase letter
[A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z] = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
if numelVarieties > 26: # extremely unlikely.
    print('The script does not expect more than 26 genetic varieties of wheat in one sitting. Clayton thinks 26 is a high yet reasonable number, though it is possible you have an error.')


##idx=0
##locals()[trackstring[idx]]+=1 # add a count to a tracker variable
##print(a)
##
##typelist
##varietylist
##plotlist
##xcoord
##ycoord

##for typ in typelist:
##    idx=types.index(typ)
##    ycoord.append(yType[idx])
##    locals()[trackstringY[idx]]+=1
    
#identify starting place x coord for each variety
#identify a count of plot for each variety (1-4)

xbasecoord = [0] # initialize
numelxbasecoord = 1 # initialize
typesByVariety = [] # reference for type for each unique variety
for variety in varieties:
    idx = varietylist.index(variety)
    typesByVariety.append(typelist[idx])

#get list of varities in each type: type a (CF), type b (SW), type c (Hw)
idx = 0
for typ in types: # for each unique types 
    indicies = [jdx for jdx, ty in enumerate(typelist) if ty==typ]
    allVarietiesInRow = [varietylist[kdx] for kdx in indicies]
    allPlotsInRow = [plotlist[kdx] for kdx in indicies]
    allVarietiesInRow_unique = unique(allVarietiesInRow)
    locals()[trackstringY[idx]] = allVarietiesInRow_unique
    locals()[trackstringY[idx].upper()] = typ # this is a neat trick. 
    numelVarietiesInRow = len(allVarietiesInRow_unique)
    if numelVarietiesInRow > numelxbasecoord:
        numelxbasecoord = numelVarietiesInRow 
    #idx*xSpacingVarieties

    for ldx in indicies: # assign ycoordinates
        ycoord[ldx] = yType[types.index(typ)]
        
    idx +=1

idx=1
while numelxbasecoord > len(xbasecoord):
    #print(idx,numelxbasecoord, xbasecoord)
    xbasecoord.append(idx*xSpacingVarieties)
    idx+=1

'''
# using x here is bad form, because hypothetically x could be used in in tracklistY.....but that's extrememely unlikely, and it works.
for var in trackstringY: # checks all 26 tracking characters, each representing the unique list of varieties within a given type
    #print(type(eval(x)))
    if isinstance(eval(x), list): # checks that a list is actually stored in as the character variable name before opening it.
        if len(eval(x))>0: # checks that a list is longer than 0 before opening it.
            print(str(x),'=',eval(x))
            print(str(x.upper()),'=',eval(x.upper()))
            X = x.upper() # 

            # for each variety on each row, identify the list of plots in the variety
            # for each plot in each variety, assign the x base coordinate of the variety to the x coordinate first plot, the assign the x coordinates of subsequent each plot, where the x coordinate will be xSpacingPlots plus the x coordinate of the previous plot from the same variety.
            # plotsInVariety = plotlist.index
            # BROKEN HERE
            plotsInVariety = [] # intialize, will store all plots in current each variety from the current type
            jdx = 0
            for variety in eval(x):
                idx = varietylist.index(variety) # first idx of variety in variety list
                plot = plotlist[idx]
                plotsInVariety.append(plot)
                typ = typelist[idx]
                xcoord[idx] = xbasecoord[jdx]
                jdx += 1
'''                
for typ in types: # for each unique types 
    indicies_type = [jdx for jdx, ty in enumerate(typelist) if ty==typ]
    allVarietiesInRow = [varietylist[kdx] for kdx in indicies_type]
    allPlotsInRow = [plotlist[kdx] for kdx in indicies_type]
    allVarietiesInRow_unique = unique(allVarietiesInRow)
    numelVarietiesInRow = len(allVarietiesInRow_unique)
    vdx=0
    for variety in allVarietiesInRow_unique:
        indicies_variety = [ldx for ldx, vari in enumerate(varietylist) if vari==variety]
        allPlotsInVariety = [plotlist[mdx] for mdx in indicies_variety]
        print(allPlotsInVariety)
        ndx=0
        for mdx in indicies_variety:
            if ndx==0:
                xcoord[mdx] = xbasecoord[vdx]
                baseref = mdx
                ndx+=1
            else:
                xcoord[mdx] = xcoord[baseref]+ndx*xSpacingPlots
                ndx+=1
        vdx+=1

    
for typ in types: # for each unique types 
    indicies_type = [jdx for jdx, ty in enumerate(typelist) if ty==typ]
    allVarietiesInRow = [varietylist[kdx] for kdx in indicies_type]
    allPlotsInRow = [plotlist[kdx] for kdx in indicies_type]
    allVarietiesInRow_unique = unique(allVarietiesInRow)
    numelVarietiesInRow = len(allVarietiesInRow_unique)
    vdx=0
    for variety in allVarietiesInRow_unique:
        indicies_variety = [ldx for ldx, vari in enumerate(varietylist) if vari==variety]
        allXInVariety = [xcoord[mdx] for mdx in indicies_variety]
        allYInVariety = [ycoord[mdx] for mdx in indicies_variety]
        print(allXInVariety)
        print(allYInVariety)
        
# look through xcoord list for zeros and non zeros
# first element will be a zero
# if second element is zero, add xSpacingPlots to previous element and assign
# else if second element is not zero, leave it alone, move to next element.
# if next element is zero, add xSPacing Plots to previous element and assign

# THIS DOESN"T WORK, ASSUMES ORDER
'''
idx=0
#print(xcoord)
for x in xcoord:
    #print(x)
    if idx > 0:
        if xcoord[idx]==0:
            xcoord[idx]=xcoord[idx-1]+xSpacingPlots
    idx+=1

    #return xcoord, ycoord, plotlist, varietylist, filelistIdentified
'''
print('varieties = ',varietylist)
print('plots = ',plotlist)
print('xcoord = ',xcoord)
print('ycoord = ',ycoord)






