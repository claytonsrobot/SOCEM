%% importKeyVariables.m
try
    directory_compiledData = 'D:\Instron Wheat Testing 2021\CompiledData\';
    directory_code = 'D:\Instron Wheat Testing 2021\MatlabCode';
    directory_saveGraphs = ('D:\Instron Wheat Testing 2021\SAVED_DATA_2021\graphs\'); %modular
    cd(directory_compiledData)
catch
    directory_compiledData = 'E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\Data - Instron and SOCEM\Compiled Data, Backups 2021 - mat, csv, xlsx, txt\';
    directory_code = 'E:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\Code - Matlab, Python, etc\Code - Matlab - Data Compilation\';
    %directory_saveGraphs = ('D:\Instron Wheat Testing 2021\SAVED_DATA_2021\graphs\'); %modular
    cd(directory_compiledData)
end
load('T_SOCEM_Wheat2021_August5,6,10,13.mat')
Ts=T;
Ts1=Ts(Ts.j==1,:);
Ts10=Ts1(Ts1.Hour==0,:);

load('T_InstronWheat2021_stemByStem');
Ti=T;
clear T;

min(Ts10.ForceBarHeight./Ts10.AvgHeight);

Newtons2Pounds = 0.225;
mmsqr2insqr = 1/645;



cd(directory_code)

