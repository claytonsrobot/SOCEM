import os
import EI_Interaction_Fx
import EI_No_Interaction_Fx

counter=[]
class sidehit:
    def __init__(self, start, rawdistance, rawforce, regionlength, peakforces):
        self.start = start
        self.rawdistance = rawdistance
        self.rawforce = rawforce
        self.regionlength = regionlength
        self.peakforces = peakforces

    def methodexample(self):
        print("Clayto nmade a method.")
        print("Hello, worlds.")

    def listAppend(self,listExists,newDouble):
        listExists.append(newDouble)

    def counter(self,idx):
        idx += idx
    

class forwardhit:
    def __init__(self, start, rawdistance, rawforce, clickedpeakdistances, clickedpeakforces):
        self.start = start
        self.rawdistance = rawdistance
        self.rawforce = rawforce
        self.clickedpeakdistances = clickedpeakdistances
        self.clickedpeakforces = clickedpeakforces

class cell:
    def __init__(self, start, row, avgforceforward, peakratioside, stemcount, mass, diameters, EII, EIN, EIM):
        self.start = start
        self.row = row
        self.avgforceforward = avgforceforward
        self.peakratioside = peakratioside
        self.stemcount = stemcount
        self.mass = mass
        self.diameters = diameters
        self.EII = EII
        self.EIN = EIN
        self.EIM = EIM

class overview:
    def __init__(self, forcebarheight, stemheight, forcebarlength, avgEIn,avgEIm,avgEIi, stdEIn, stdEIm, stdEIi):
        self.forcebarheight = forcebarheight
        self.stemheight = stemheight
        self.regionlength = forcebarlength
        self.avgEIn = avgEIn
        self.avgEIm = avgEIm
        self.avgEIi = avgEIi
        self.stdEIn = stdEIn
        self.stdEIm = stdEIm
        self.stdEIi = stdEIi

class plot:
    def __init__(self,overview,cell1,cell2,cell3,cell4,cell5,cell6,cell7,cell8,cell9,forwardhit,sidehit1,sidehit2,sidehit3):
        self.overview = overview
        self.cell1 = cell1
        self.cell2 = cell2
        self.cell3 = cell3
        self.cell4 = cell4
        self.cell5 = cell5
        self.cell6 = cell6
        self.cell7 = cell7
        self.cell8 = cell8
        self.cell9 = cell9
        self.forwardhit = forwardhit
        self.sidehit1 = sidehit1
        self.sidehit2 = sidehit2
        self.sidehit3 = sidehit3

regionlength = 30 # inches, standard
fb_bottom = 7
stemheight = 10 # constant for equalized plot

rawdistanceforward = [0,5,10,15,  20,25,30,35,40,45,   50,55,60,65,70,75,   80,85,90,95,100,105   ,110,115,120,125,130]
rawdistanceside = [0,2.5,  5,7.5,10,  12.5,15,17.5,  20,22.5,25,  27.5,30,32.5,  35]
# raw distance comes from SOCEM tests. Above are dummy vectors.
rawforceforward = [0.1,0.1,0.1,0.1,   1,1,4,1,5,1,   1,1,1,2.5,1,1  ,1,1,6,4,1,1  ,0.1,0.1,0.1,0.1,0.1]
rawforceside1 = [0.1,0.1,  7,8,7,  9,10,9,  4,6,4,  0.1]
rawforceside2 = [0.1,0.1,  4,5,3,  2,3,2,  8,9,8,  0.1]
rawforceside3 = [0.1,0.1,  6,7,6,  4,6,4,  9,10,9,  0.1]
# raw force comes from SOCEM test. Above are dummy vectors.
peakforcessidehit1 = [8, 10, 6]
peakforcessidehit2 = [5, 3, 9]
peakforcessidehit3 = [7, 6, 10]
# assessed peaks comes from user click assessment. Above are dummy vectors, in agreement with raw dummy vectors.
peakforcesforward = [4,5, 2.5, 6,4]
peakdistancesforward = [30,40, 65,  90,95]
# assessed peaks comes from user click assessment. Above are dummy vectors, in agreement with raw dummy vectors.
startforward = 0 # inferred
startsidehit1 = 20
startsidehit2 = 50
startsidehit3 = 80

stemcountcell1 = 37 # indivudal stems
stemcountcell2 = 48
stemcountcell3 = 29
stemcountcell4 = 12
stemcountcell5 = 8
stemcountcell6 = 22
stemcountcell7 = 35
stemcountcell8 = 30
stemcountcell9 = 50

# relies on standarization of stem heights
masscell1 = 37 # grams
masscell2 = 48
masscell3 = 29
masscell4 = 12
masscell5 = 8
masscell6 = 22
masscell7 = 35
masscell8 = 30
masscell9 = 50

## mm
diameterscell1 = [4,5,4,5,4,5,4,5,4,5]
diameterscell2 = [4,5,4,5,4,5,4,5,4,5]
diameterscell3 = [4,5,4,5,4,5,4,5,4,5]
diameterscell4 = [4,5,4,5,4,5,4,5,4,5]
diameterscell5 = [4,5,4,5,4,5,4,5,4,5]
diameterscell6 = [4,5,4,5,4,5,4,5,4,5]
diameterscell7 = [4,5,4,5,4,5,4,5,4,5]
diameterscell8 = [4,5,4,5,4,5,4,5,4,5]
diameterscell9 = [4,5,4,5,4,5,4,5,4,5]

# calculations below
peakratiosidehit1 = [peakforcessidehit1[0]/sum(peakforcessidehit1),peakforcessidehit1[1]/sum(peakforcessidehit1),peakforcessidehit1[2]/sum(peakforcessidehit1)]
peakratiosidehit2 = [peakforcessidehit2[0]/sum(peakforcessidehit2),peakforcessidehit2[1]/sum(peakforcessidehit2),peakforcessidehit2[2]/sum(peakforcessidehit2)]
peakratiosidehit3 = [peakforcessidehit3[0]/sum(peakforcessidehit3),peakforcessidehit3[1]/sum(peakforcessidehit3),peakforcessidehit3[2]/sum(peakforcessidehit3)]

indicies_region1 = []
indicies_region2 = []
indicies_region3 = []
for distancemark in peakdistancesforward:
    if (distancemark>startsidehit1) and (distancemark<(startsidehit1+regionlength)):
        indicies_region1.append(peakdistancesforward.index(distancemark))
    elif (distancemark>startsidehit2) and (distancemark<(startsidehit2+regionlength)):
        indicies_region2.append(peakdistancesforward.index(distancemark))
    elif (distancemark>startsidehit3) and (distancemark<(startsidehit3+regionlength)):
        indicies_region3.append(peakdistancesforward.index(distancemark))
        
peakforcesforward_region1 = [peakforcesforward[kdx] for kdx in indicies_region1]
peakforcesforward_region2 = [peakforcesforward[kdx] for kdx in indicies_region2]
peakforcesforward_region3 = [peakforcesforward[kdx] for kdx in indicies_region3]
avgforce_region1 = sum(peakforcesforward_region1)/len(peakforcesforward_region1)
avgforce_region2 = sum(peakforcesforward_region2)/len(peakforcesforward_region2)
avgforce_region3 = sum(peakforcesforward_region3)/len(peakforcesforward_region3)

# can names in self.name be that same as the name itself?


# classes, with inputs
sidehit1 = sidehit(20,rawdistanceside,rawforceside1,regionlength,peakforcessidehit1)
sidehit2 = sidehit(50,rawdistanceside,rawforceside2,regionlength,peakforcessidehit2)
sidehit3 = sidehit(80,rawdistanceside,rawforceside3,regionlength,peakforcessidehit3)
forward = forwardhit(0,rawdistanceforward,rawforceforward,peakdistancesforward,peakforcesforward)


# cell class preparation
start_list = [sidehit1.start,sidehit1.start,sidehit1.start,sidehit2.start,sidehit2.start,sidehit2.start,sidehit3.start,sidehit3.start,sidehit3.start]
row_list = [1,2,3,1,2,3,1,2,3]
avgforceforward_list = [avgforce_region1,avgforce_region1,avgforce_region1,avgforce_region2,avgforce_region2,avgforce_region2,avgforce_region3,avgforce_region3,avgforce_region3]
peakratioside_list = [peakratiosidehit1[0],peakratiosidehit1[1],peakratiosidehit1[2],peakratiosidehit2[0],peakratiosidehit2[1],peakratiosidehit2[2],peakratiosidehit3[0],peakratiosidehit3[1],peakratiosidehit3[2]]
stemcount_list = [stemcountcell1,stemcountcell2,stemcountcell3,stemcountcell4,stemcountcell5,stemcountcell6,stemcountcell7,stemcountcell8,stemcountcell9]
mass_list = [masscell1,masscell2,masscell3,masscell4,masscell5,masscell6,masscell7,masscell8,masscell9]
diameters_list = [diameterscell1,diameterscell2,diameterscell3,diameterscell4,diameterscell5,diameterscell6,diameterscell7,diameterscell8,diameterscell9]

EII_list = []
EIN_list = []
EIM_list = []
i=0
while i<len(avgforceforward_list):
    EII_list.append(EI_Interaction_Fx.EI_Interaction(avgforceforward_list[i]*peakratioside_list[i],fb_bottom,stemheight,1/(stemcount_list[i]/regionlength)))
    EIN_list.append(EI_No_Interaction_Fx.EI_NoInteraction(avgforceforward_list[i]*peakratioside_list[i],fb_bottom,stemheight,1/(stemcount_list[i]/regionlength)))
    EIM_list.append((EII_list[i] + EIN_list[i])/2)
    i+=1

i=0
cell1 = cell(start_list[i], row_list[i], avgforceforward_list[i], peakratioside_list[i], stemcount_list[i], mass_list[i], diameters_list[i], EII_list[i], EIN_list[i], EIM_list[i])
i+=1
cell2 = cell(start_list[i], row_list[i], avgforceforward_list[i], peakratioside_list[i], stemcount_list[i], mass_list[i], diameters_list[i], EII_list[i], EIN_list[i], EIM_list[i])
i+=1
cell3 = cell(start_list[i], row_list[i], avgforceforward_list[i], peakratioside_list[i], stemcount_list[i], mass_list[i], diameters_list[i], EII_list[i], EIN_list[i], EIM_list[i])
i+=1
cell4 = cell(start_list[i], row_list[i], avgforceforward_list[i], peakratioside_list[i], stemcount_list[i], mass_list[i], diameters_list[i], EII_list[i], EIN_list[i], EIM_list[i])
i+=1
cell5 = cell(start_list[i], row_list[i], avgforceforward_list[i], peakratioside_list[i], stemcount_list[i], mass_list[i], diameters_list[i], EII_list[i], EIN_list[i], EIM_list[i])
i+=1
cell6 = cell(start_list[i], row_list[i], avgforceforward_list[i], peakratioside_list[i], stemcount_list[i], mass_list[i], diameters_list[i], EII_list[i], EIN_list[i], EIM_list[i])
i+=1
cell7 = cell(start_list[i], row_list[i], avgforceforward_list[i], peakratioside_list[i], stemcount_list[i], mass_list[i], diameters_list[i], EII_list[i], EIN_list[i], EIM_list[i])
i+=1
cell8 = cell(start_list[i], row_list[i], avgforceforward_list[i], peakratioside_list[i], stemcount_list[i], mass_list[i], diameters_list[i], EII_list[i], EIN_list[i], EIM_list[i])
i+=1
cell9 = cell(start_list[i], row_list[i], avgforceforward_list[i], peakratioside_list[i], stemcount_list[i], mass_list[i], diameters_list[i], EII_list[i], EIN_list[i], EIM_list[i])

'''
cell1 = cell()
cell1.start = sidehit1.start
cell1.row = 1
cell1.avgforceforward = avgforce_region1
cell1.peakratioside = peakratiosidehit1
cell1.stemcount = stemcountcell1
cell1.mass = masscell1
cell1.diameters = diameterscell1
cell1.EII =EI_Interaction_Fx.EI_Interaction(avgforce_region1*peakratiosidehit1, fb_bottom, stemheight,spacing = 1/(stemcountcell1/regionlength))
cell1.EIN =EI_No_Interaction_Fx.EI_NoInteraction(avgforce_region1*peakratiosidehit1, fb_bottom, stemheight,spacing = 1/(stemcountcell1/regionlength))
cell1.EIM = (cell1.EII+cell1.EIN)/2
#EII = EI_Interaction_Fx.EI_Interaction(peaks[i], fb_bottom, hatPeaks[i],spacing) # uses clicked forces (Y axis), force bar height, horizontal plot heights, and count density
#EIN = EI_No_Interaction_Fx.EI_NoInteraction(peaks[i], fb_bottom, hatPeaks[i], spacing) # the x value of the click does nothing other than find the nearest height from horz. It is not factored in to the number of beams or the character of the beams. 
#EIM = (EII + EIN)/2

#'''

# and so on....