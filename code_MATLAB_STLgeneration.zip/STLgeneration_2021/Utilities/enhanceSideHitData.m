function [distX_new, magX_new] = enhanceSideHitData(distX,magX,dim)

% Prepare the cell by cell data for initial plotting        
        numelDuplicateColumns = round(dim/12,0);
        magX_new = [];
        for segment = 2:11
            for dup = 1:numelDuplicateColumns
                magX_new(end+1) = magX(segment);
            end
        end
        
        while numel(magX_new) <= (dim-1)
            magX_new(end+1) = magX(end);
        end
        distX_new = linspace(min(distX),max(distX),dim);
end

%% metadata
% author: Clayton Bennett
% created: 05/01/2022
% Description:
%   - Increase size of side hit data vectors to match forward hit data interpolation