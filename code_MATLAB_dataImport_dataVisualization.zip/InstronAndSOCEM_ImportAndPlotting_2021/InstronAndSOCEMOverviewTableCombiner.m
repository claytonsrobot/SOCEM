% Author: Clayton Bennett
% Title: marriage2021.m
% 26 February 2022
% Purpose: make overview tables for instron and SOCEM data from 2021 to be compared

clear Instron
clear SOCEM
varnames_I = {'i','Variety','Plot','AveEI','StdEI','AvgStrength','NodeMajDiam'};
vartypes_I = {'int64','string','string','double','double','double','double'};
Instron = table('Size',[numel(unique(Ti.Plot)),numel(varnames_I)],'VariableNames',varnames_I,'VariableTypes', vartypes_I);
%Instron = table('Size',[8,numel(varnames_I)],'VariableNames',varnames_I,'VariableTypes', vartypes_I);

varnames_S = {'i','Variety','Plot','EI'};
vartypes_S = {'int64','string','string','double'};
%SOCEM = table('Size',[40,numel(varnames_S)],'VariableNames',varnames_S,'VariableTypes', vartypes_S);
%%
string_table_SOCEM = 'Ts';
table_initial_SOCEM = eval(string_table_SOCEM);
heur0 = table_initial_SOCEM;

col1 = "j";
keep1 = 1; % EDIT HERE
heur1 = heur0(keep1 == heur0.(col1),:);

col2 = "Hour";
keep2 = 0;
heur2 = heur1(keep2 == heur1.(col2),:);

col3 = "Plot";
keep3 = {'CF246','CF147','HW319','HW122','HW412','HW418','HW211','CF452'}; % manurally seelected pretty candidates
toss3 = {'CF149','CF342','CF443','CF444','CF145','HW401','HW318','HW416','HW221','HW309'};
heur3=heur2;
for i=1:length(toss3)
    heur3 = heur3(not(toss3{i}==heur3.(col3)),:);
end

% for i=1:length(keep3)
%     heur3 = heur3(keep3{i}==heur3.(col3),:);
% end

heurfinal = heur3;
heurfinal = heur2;

Ts10sansHW=Ts10(not(contains(Ts10.Plot,"HW")),:);
heurfinal=Ts10sansHW;
heurfinal=Ts10;
SOCEM = table('Size',[height(heurfinal),numel(varnames_S)],'VariableNames',varnames_S,'VariableTypes', vartypes_S);

SOCEM.Variety = heurfinal.Variety;
SOCEM.Plot = heurfinal.Plot;
SOCEM.EI = heurfinal.EIM;

SOCEM = sortrows(SOCEM,[2,3]);
for i=1:height(SOCEM)
    SOCEM.i(i)=i;
end
%%

string_table_Instron = 'Ti';
table_initial_Instron = eval(string_table_Instron);
heur0 = table_initial_Instron;

fic1 = "Plot"; % filtercolumn
groups1 = unique(heur0.(fic1));
ngroups1 = numel(groups1);

fic2 = "EI"; % filtercolumn
%groups2 = quantile(x,3);% unique(heur0.(fic1));
%ngroups2 = numel(groups1);


Newtons2Pounds = 0.225;
mmsqr2insqr = 1/645;

branch1 = {};
for b = 1:numel(groups1)
    heur1 =  heur0(heur0.(fic1)==groups1(b),:);
    branch1{b} = heur1;
%     qs = quantile(heur1.(fic2),3);
%     branch1{b} = heur1(heur1.(fic2)>= qs(1),:);
    Instron.Variety(b)=branch1{b}.Variety(1);
    Instron.Plot(b)=branch1{b}.Plot(1);
    Instron.AveEI(b)=mean(branch1{b}.EI).*Newtons2Pounds.*mmsqr2insqr;
    Instron.StdEI(b)=std(branch1{b}.EI).*Newtons2Pounds.*mmsqr2insqr;
    Instron.AveForce(b)=mean(branch1{b}.Strength).*Newtons2Pounds;
    Instron.NodeMajDiam(b)=mean(branch1{b}.NodeMajorDiameter).*mmsqr2insqr;
end

Instron = sortrows(Instron,[2,3]);
for i=1:height(Instron)
    Instron.i(i)=i;
end

%%
%%
if size(Instron)>size(SOCEM)
idx=((1:size(Instron))'.*(ismember(Instron.Plot,SOCEM.Plot)));
i=1;
    while i<=numel(idx)
        if idx(i)==0
            idx(i)=[];
            
        else
            i=i+1;
        end
    end
end

Instron=Instron(idx,:);

for i=1:height(Instron)
    Instron.i(i)=i;
end
%%
clear T
varnames = {'Variety','Plot','EI_SOCEM','AvgEI_Instron','StdEI_Instron','AvgMaxForce_Instron','NodeMajDiam'};
vartypes = {'string','string','double','double','double','double','double'};
n = height(Instron);
T=table('Size',[n,numel(varnames)],'VariableNames',varnames,'VariableTypes',vartypes);
T.Variety = Instron.Variety;
T.Plot = Instron.Plot;
T.EI_SOCEM = SOCEM.EI;
T.AvgEI_Instron = Instron.AveEI;
T.StdEI_Instron = Instron.StdEI;
T.AvgMaxForce_Instron = Instron.AveForce;
T.NodeMajDiam = Instron.NodeMajDiam;
varunits = {'','','pound*inch^2','pound*inch^2','pound*inch^2','pound','in'};
T.Properties.VariableUnits = varunits;
%%
close gcf
string_xdata = 'T.EI_SOCEM';
string_ydata = 'T.AvgEI_Instron';
string_ydata = 'T.NodeMajDiam';

string_table = 'T';
xdata = eval(string_xdata);
ydata = eval(string_ydata);

string_titleFront = {'SOCEM EIM vs Instron EI correlaton, SOCEM 2021, Wheat'};
string_exportfilenamedetail = {'SOCEMEIMvsInstronEIcorrelaton_S1_I1234_sansHW'};
legendString = {'1st SOCEM test & Avg Instron performance (with all quartiles)', 'Linear fit: y=a+b*x'};

directory_processingCode = ('D:\Instron Wheat Testing 2021\MatlabCode\'); % not thoroughly modular, if the script location changes.
directory_saveGraphs = ('D:\Instron Wheat Testing 2021\SAVED_DATA_2021\graphs\'); %modular


string_xlabel = strcat(extractAfter(string_xdata,'.')); % 
string_ylabel = strcat(extractAfter(string_ydata,'.')); %


for column = 1:numel(eval(string_table).Properties.VariableNames)
    if string(eval(string_table).Properties.VariableNames(column)) == string_xlabel
       string_xlabel = replace(string_xlabel,'_','_.');
       string_xlabel = string(strcat(string_xlabel,'_.(',eval(string_table).Properties.VariableUnits(column),')'));
    elseif string(eval(string_table).Properties.VariableNames(column)) == string_ylabel
       string_ylabel = replace(string_ylabel,'_','_.');
       string_ylabel = string(strcat(string_ylabel,'_.(',eval(string_table).Properties.VariableUnits(column),')'));
    end
end
cd(directory_code)
[abc,a,b,c,rsq,rmse,sse,lm,f0,string1]=linearFitting(xdata,ydata,1,1,1);
ha=annotation(gcf,'textbox',[0.121,0.78,1,1],'String',string1,'EdgeColor','none','FitBoxToText','on','verticalalignment', 'bottom', 'color','k');

title(strcat(string_titleFront,string(newline),'CF and SW plots'))
xlabel(string_xlabel);
ylabel(string_ylabel);
handle_legend = legend(legendString, 'Location','best');
cd(directory_saveGraphs)
filename_plot = string(strcat(string_exportfilenamedetail,'.png'));
%exportgraphics(gcf, filename_plot,'Resolution',300)
            
hold off
cd(directory_processingCode)
%% OTHER WAY TO DO THIS, BOOK 1B %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
directory_compiled = 'D:\Instron Wheat Testing 2021\CompiledData';
directory_processingCode = ('D:\Instron Wheat Testing 2021\MatlabCode\'); % not thoroughly modular, if the script location changes.
directory_saveGraphs = ('D:\Instron Wheat Testing 2021\SAVED_DATA_2021\graphs\'); %modular


cd(directory_compiled)
load('T_SOCEM_Wheat2021_August5,6,10,13.mat');
Ts=T;
load('T_InstronWheat2021_stemByStem.mat');
Ti=T;
%%
runshown = 1;
string_exportfilenamedetail = strcat('_Run',string(runshown),'_EIcorrelation_Wheat2021');


Newtons2Pounds = 0.225;
mmsqr2insqr = 1/645;
xhope=[];
yhope=[];

xlist=[];
ylist=[];
varietylist = {};
plotlist = {};
InstronEIlist = {};
heightslist = {};
horzlist = {};
fblist = {};


for i=1:height(Ts)
    if Ts.Hour(i)==0 && Ts.j(i)==runshown
        if height(Ti(Ts.Plot(i)==Ti.Plot,:))>0
            %xlist(end+1) = Ts.EIM(i);
            xdata = Ti(Ts.Plot(i)==Ti.Plot,:).EI.*Newtons2Pounds.*mmsqr2insqr;
            %xlist(end+1) = Ts.AreaUnderCurve(i);
            ydata = Ti(Ts.Plot(i)==Ti.Plot,:).EI.*Newtons2Pounds.*mmsqr2insqr;
            %ydata = Ti(Ts.Plot(i)==Ti.Plot,:).Strength.*Newtons2Pounds;
            ydata = Ti(Ts.Plot(i)==Ti.Plot,:).NodeMajorDiameter.*mmsqr2insqr;
            qs = quantile(ydata,5);
            %ylist(end+1) = mean(ydata(ydata>= qs(2)));
            xlist(end+1) = mean(xdata);
            ylist(end+1) = mean(ydata);
            varietylist{end+1} = char(Ts.Variety(i));
            plotlist{end+1} = char(Ts.Plot(i));
            InstronEIlist{end+1} = Ti(Ts.Plot(i)==Ti.Plot,:).EI.*Newtons2Pounds.*mmsqr2insqr;
            heightslist{end+1} = Ts.StemHeightsX{i};
            horzlist{end+1} = Ts.HorzX{i};
            fblist{end+1} = Ts.ForceBarHeight(i);
        end
    end
end


Newtons2Pounds = 0.225;
mmsqr2insqr = 1/645;
%ylist = ylist.*Newtons2Pounds.*mmsqr2insqr;
colormat = [0, 0.4470, 0.7410; 0.8500, 0.3250, 0.0980;0.9290, 0.6940, 0.1250;0.4940, 0.1840, 0.5560];
varietylistunique = unique(varietylist);
for i=1:numel(unique(varietylist))
    idx = string(varietylistunique{i})==varietylist;
    x = xlist(string(varietylistunique{i})==varietylist);
    y = ylist(string(varietylistunique{i})==varietylist);
    plots = plotlist(string(varietylistunique{i})==varietylist);
    InstronEI = InstronEIlist(string(varietylistunique{i})==varietylist);
    heights = heightslist(idx);
    horzs = horzlist(idx);
    fbs = fblist(idx);
    
    xhope(i)=mean(x);
    yhope(i)=mean(y);
end
%%
    %figure()
    cd(directory_processingCode)
    close(gcf)
    subplot(2,2,1)
    [abc,a,b,c,rsq,rmse,sse,lm,f0,string1]=linearFitting(x,y,1,1,1);
    hold on
    ha1=annotation(gcf,'textbox',[0.2,.935,1,1],'String',string1,'EdgeColor','none','FitBoxToText','on','verticalalignment', 'bottom', 'color','k');
    %ha2=annotation(gcf,'textbox',[0.121,0.121,1,1],'String',strcat({'Plot:'},plots),'EdgeColor','none','FitBoxToText','on','verticalalignment', 'bottom', 'color','k');
    for j=1:length(plots)
        %text(x(j)+0.2,y(j)-0.1,plots(j))
        plot(x(j),y(j),'*','Color',colormat(j,:))
    end
    axis([0,20,0,22.5])
    title(strcat(string(varietylistunique{i}),{', SOCEM Run EI vs Instron Ave EI'}))
    xlabel(strcat({'SOCEM EI, Run '},string(runshown),{' (pounds*in^2)'}))
    ylabel('Instron Avg EI, (pounds*in^2)')
    set(gcf, 'Position', get(0, 'Screensize'));
    
    subplot(2,2,2)
    plotEIMatrix = zeros(10,numel(plots));
    plotLabels = {};
    for k = 1:numel(plots)
        plotEIMatrix(:,k)=[InstronEI{k}];
        %plotLabels{k}=plots{k};
    end
       
    boxplot(plotEIMatrix,plots,'Color',colormat)
    %boxplot(InstronEIlist{i})
    ylim([0,22.5])
    title(strcat(string(varietylistunique{i}),{', Instron EI, Each Stem'}))
    ylabel('Instron EI, (pounds*in^2), all 10 stems')
    
    % Plot 3
    subplot(2,2,3)
    
    title(strcat(string(varietylistunique{i}),{', SOCEM EI, Runs 1-4, Hour 0'}))
    xlabel('Run #')
    ylabel('SOCEM EI, (pounds*in^2)')
    table_initial = Ts;
    hold on
        col1 = "Variety";
        keep1 = string(varietylistunique{i});
        heur1 = table_initial(keep1 == table_initial.(col1),:);
        
        col2 = "Hour";
        keep2 = 0;
        heur2 = heur1(keep2 == heur1.(col2),:);
        
        heurfinal = heur2;


        fic1 = "Plot"; % filtercolumn
        groups1 = unique(heurfinal.(fic1));
        ngroups1 = numel(groups1);

        branch1 = {};
        for b = 1:numel(groups1)
            branch1{b} =  heurfinal(heurfinal.(fic1)==groups1(b),:);
        end

        fic2 = "Hour";
        groups2 = unique(heurfinal.(fic2)); % What are the different values for hours?
        ngroups2 = numel(groups1);

        branch2 = {};
        for b=1:numel(groups2)
            branch2{b} = heurfinal(heurfinal.(fic2)==groups2(b),:);
        end

        branch12 ={};
        for b2=1:numel(groups2)
            for b1 = 1:numel(groups1)
                branch12{b1,b2} = heurfinal(logical([groups1(b1)==heurfinal.(fic1)].*[groups2(b2)==heurfinal.(fic2)]),:);

            end
        end
        % plot, specific
        legendstring = {};
        for b2=1:numel(groups2)
            for b1 = 1:numel(groups1)
                if not(isempty(branch12{b1,b2}))
                    plot(branch12{b1,b2}.("j"),branch12{b1,b2}.EIM,'*-')
                    hold on
                    valueshow3 = mean(branch12{b1,b2}.ForceBarHeight);
                    valueshow4 = mean(branch12{b1,b2}.AvgHeight);
                    valueshow5 = std(branch12{b1,b2}.StemHeightsX{1});
                    topstring = sprintf('%s, fbh %0.2g in, avgh %0.2g in',groups1(b1),valueshow3,valueshow4);
                    bottomstring = sprintf('fbh/avgh = %0.2g, stdevh = %0.2g in',valueshow3/valueshow4,valueshow5);
                    legendstring{end+1} = strcat(topstring, string(newline),bottomstring);
                end
            end
        end

        hleg = legend(legendstring,'location','northeastoutside');
        ymax = max(ydata);
        ymax = 19.5;
        if not(isempty(branch12{b1,b2}))
            xmax = max(branch12{b1,b2}.("j"));
        end
        mat_ax = [0.8,double(xmax)+.2,0,ymax];
        axis(mat_ax)
        xticks([1,2,3,4,5,6,7,8])
        
        subplot(2,2,4)
        plot([0,160],[-1,-1],'-.k')
        hold on
        for k=1:numel(horzs)
            plot(horzs{k},heights{k},'*-','Color',colormat(k,:))
            hold on
        end
        for k=1:numel(horzs)
            plot([0,160],[fbs{k},fbs{k}],'-.','Color',colormat(k,:))
        end
        axis([0,160,0,12.5])
        title(strcat(string(varietylistunique{i}),{', SOCEM Plot Heights'}))
        legend('Force bar height')
        xlabel('Travel (inches)')
        ylabel('Stem height (inches)')
        

    % %% %%
    
    
    cd(directory_saveGraphs)
    filename_plot = strcat(varietylistunique{i},string_exportfilenamedetail,'.png');
    %exportgraphics(gcf, filename_plot,'Resolution',300)
    hold off
%end
cd(directory_processingCode)

%% Hope
hold off
close all
cd(directory_code)
[abc,a,b,c,rsq,rmse,sse,lm,f0,string1]=linearFitting(xhope,yhope,1,1,1);
ha1=annotation(gcf,'textbox',[0.13,.76,1,1],'String',string1,'EdgeColor','none','FitBoxToText','on','verticalalignment', 'bottom', 'color','k');
title(strcat('Socem EI vs Instron EI, one data point for each variety, results averaged'));%,string(newline),'lowest 3 stems of Instron data excluded from each plot.'))
title(strcat('Socem EI vs Stem Diameter, one data point for each variety, results averaged'));%,string(newline),'lowest 3 stems of Instron data excluded from each plot.'))
title(strcat('Instron EI vs Stem Diameter, one data point for each variety, results averaged'));%,string(newline),'lowest 3 stems of Instron data excluded from each plot.'))
xlabel('Socem EI, averaged (lbs*in^2)')
xlabel('Instron EI, averaged (lbs*in^2)')
ylabel('Instron EI, averaged (lbs*in^2)')
ylabel('Stem Diameter (in)')
for j=1:length(xhope)
    text(xhope(j)+0.2,yhope(j)-0.1,varietylistunique{j})
end

%% Hope fulfilled, outliers excluded 72!!

close gcf
exclude={'Irv','Norwest 553','MT1745','OR2160011R'};%,'Stephens'};

idxmat=ones(numel(exclude),numel(varietylistunique));
idx=ones(1,numel(varietylistunique));
idxnum =[];
for j=1:numel(exclude)
    idxmat(j,:) = not(contains(varietylistunique,exclude{j}));
end
for j=1:numel(varietylistunique)
    idx(j)=min(idxmat(:,j));
    if idx(j)==1
        idxnum(end+1)=j;
    end
end

x=xhope(idxnum);
y=yhope(idxnum);
v=varietylistunique(idxnum);
[abc,a,b,c,rsq,rmse,sse,lm,f0,string1]=linearFitting(x,y,1,1,1);
ha1=annotation(gcf,'textbox',[0.13,.7,1,1],'String',string1,'EdgeColor','none','FitBoxToText','on','verticalalignment', 'bottom', 'color','k');
title(strcat('Socem EI vs Instron EI, one data point for each variety, results averaged',string(newline),'Irv, Norwest 553, MT1745, and OR2160011R excluded,'));%,string(newline),'Lowest 3 stems of Instron data excluded from each plot.'))
title(strcat('Instron EI vs Stem Diameter, one data point for each variety, results averaged'));%,string(newline),'lowest 3 stems of Instron data excluded from each plot.'))
ylabel('Instron EI, averaged (lbs*in^2)')
ylabel('Stem Diameter (in)')
xlabel('Socem EI, averaged (lbs*in^2)')
xlabel('Instron EI, averaged (lbs*in^2)')
for j=1:length(x)
    text(x(j)+0.2,y(j)-0.1,v{j})
end





