% title: IndividualInstronTableMaker_Barley_1.m
% author: Clayton Bennett
% last edits: 21 July 2021

directory = ('C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\Barley\September 2020\');
%directory = ('C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\Barley\September 2020\Alt Method - No AutoStop, continuous\');
%directory = ('C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\Wheat\August 2020\Alt Method - No AutoStop, continuous\'); % for wheat
%directory = ('C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\Barley\September 2020\Alt Method - 5% Decrease Past Max Reading\');

%% Identify Instron files that have individual test arrays for Time, Displacement, and Force.
%filelist_individual = dir(strcat(directory,'softwinter*.csv')); % INPUT OPPORTUNITY.
filelist_individual = dir(strcat(directory,'springbarleyfeed*.csv')); % INPUT OPPORTUNITY.
file_individual = {filelist_individual.name};
% ** This will only identify files of the specified format.

%% PREPARE THE TABLE
n = numel(file_individual);
varnames = {'Plot','Stem','Run','File','OverviewFile','Time', 'Displacement','Force'};
T = cell2table(cell(n,8), 'VariableNames', varnames); 
T.Plot = strings([height(T),1]);
T.Stem = nan(height(T),1);
T.Run = nan(height(T),1);
T.File = strings([height(T),1]);
T.OverviewFile = strings([height(T),1]);
%% Populates each row of the table with the following information:
% % %
% % %   Filename
% % %       Referred to as:
% % %           File
% % %           T.File(j)
% % %           file_individual(j)
% % %
% % %   Plotname
% % %       Referred to as:
% % %           Plot
% % %           T.Plot(j)
% % %
% % %   Overview filename
% % %       Referred to as:
% % %           OverviewFile
% % %           T.OverviewFile(j)
% % %
% % %   Stem number
% % %       Referred to as:
% % %           Stem
% % %           T.Stem(j)
% % %       Based on how many stems were tested for each plot.
% % %
% % %   Run number
% % %       Referred to as:
% % %           Run
% % %           T.Run(j)
% % %       Based on how many repeated tests were run on each stem.
% % %
% % % All of this information comes directly from the filename for each
% % %   indivdual test.

for j=1:n
    File = string(file_individual(j));
    Plot = eraseBetween(File,min(strfind(File,'.')),strlength(File)); %for cyclic tests
    %Plot = eraseBetween(File,min(strfind(File,'_')),strlength(File)); %for non-cyclic tests
    Plot = strrep(Plot,'springbarleyfeed','SBF'); % for 2020 Barley
    Plot = strrep(Plot,'clearfield','CF'); % for 2020 Wheat
    Plot = strrep(Plot,'hardwinter','HW'); % for 2020 Wheat
    Plot = strrep(Plot,'softwinter','SW'); % for 2020 Wheat

    
    % %% Relate each individual test filename to its corresponding overview file.
    OverviewFile = string(strrep(File,'springbarleyfeed','0SBF'));
    OverviewFile = string(strrep(OverviewFile,'.nonnode',''));
    
    % %% Cleanup non-standard names, because they will not be seen in any
    %       overview file name.
    OverviewFile = eraseBetween(OverviewFile,strfind(OverviewFile,'_'),strfind(OverviewFile,'.csv')-1);
    
    % %% While bothering with filenames, extracted from each individual
    %       test filename the Stem number and the Run number.
    Stem = str2double(extractBetween(OverviewFile,min(strfind(OverviewFile,"."))+1,max(strfind(OverviewFile,'.'))-1)); %for cyclic tests
    %Stem = str2double(extractBetween(File,max(strfind(File,'_'))+1,strfind(File,'.csv')-1)); %for non-cyclic tests
    Run = str2double(extractBetween(File,max(strfind(File,'_'))+1,strfind(File,'.csv')-1));  %for cyclic tests
    %Run = 1; %for non-cyclic tests
    % ** THIS WILL CHANGE BASED ON NAMING CONVENTION AND EXPERIMENTAL DESIGN.
    
    % %% Store active variables, which are different for each loop, into row j of table T.
    T.File(j)=File;
    T.Plot(j)=Plot;
    T.OverviewFile(j)=OverviewFile;
    T.Stem(j)= Stem;
    T.Run(j)=Run;
    
end
%% Display first five rows of the table T, so that you know what it looks like.

        head(T,5)
        
%% Display any given row of the table T.

        %i=269; % To look at a particular row, edit the value of i.
        %T(i,:)
        
        % %% I chose not to include a column of index numbers in table T.
        % Row numbers can be seen in the Variable viewer for table T.

%% IMPORT ARRAYS FROM INDIVIDUAL FILES
% This is slow, because each file must be opened, recorded, and closed. That's okay.

for j = 1:height(T)
    [Time, Displacement,Force]=csvimport(strcat(directory, T.File{j}),'columns',{'Time','Displacement','Force'});
    
    % %% Remove first value from each imported column.
    Time=Time(2:end);
    Displacement=Displacement(2:end);
    Force=Force(2:end);
    
    % %% Store entire arrays for each Instron test into each row j of table T.
    T.Time(j)=mat2cell(str2double(erase(Time,'"')),length(Time));
    T.Displacement(j)=mat2cell(str2double(erase(Displacement,'"')),length(Time));
    T.Force(j)=mat2cell(str2double(erase(Force,'"')),length(Time));
    
end

%% Prepare the table T to import numerical and text data from overview files.
T.LoadDeflection = nan(height(T),1);
T.Modulus = nan(height(T),1);
T.MaxLoad = nan(height(T),1);
T.DisplacementAtMaxLoad = nan(height(T),1);
T.BreakType = strings([height(T),1]);
T.Notes = strings([height(T),1]);
%% SAVE PROGRESS

%T_barley = T; % INPUT OPPORTUNITY.
T_wheat99 = T; % INPUT OPPORTUNITY.

%% Go through each line in table and assign loadDeflection, Modulus, MaxLoad, DisplacementAtMaxLoad, Notes, BreakType
% This is slow, because each file must be opened, recorded, and closed. That's okay.
%
% It works! But it could be more smooth...maybe. Issue: It opens and closes
% the same Excel file multiple times. Can each Overview File stay open
% until it is complete? There is a way to do this, that involves counting
% the number of tests in the overview file and adding another loop. But!
% The current method is fullproof and scalable.

for j=1:height(T)
    [ndata, text, c] = xlsread(strcat(directory,T.OverviewFile(j))); %c is of type cell
    
            Run = T.Run(j);
            Stem = T.Stem(j);
            rowIndex = Run; % for cyclic tests
            %rowIndex = Stem; % for non-cyclic tests
            
            T.Modulus(j) = cell2mat(c(7+rowIndex-1,3)); %MPa, Young modulus, auto
            T.MaxLoad(j) = cell2mat(c(7+rowIndex-1,4)); %N, max forces from each stalk
            T.DisplacementAtMaxLoad(j) = cell2mat(c(7+rowIndex-1,5)); %mm, displacement at max
            T.Notes(j) = cell2mat(c(7+rowIndex-1,6)); %notes
            T.BreakType(j) = cell2mat(c(7+rowIndex-1,7)); %breaktype
            
            % %% If LoadDeflection(j) happens to equal NaN, i.e. if no value Load Deflection value was recorded by the Intsron.
            if ischar(cell2mat(c(7+rowIndex-1,2)))
                T.LoadDeflection(j)=str2double(cell2mat(c(7+rowIndex-1,2))); %% enters NaN inteads of '-----', if no LoadDflection value was recorded by the Instron.
            else
                T.LoadDeflection(j)= cell2mat(c(7+rowIndex-1,2)); % typical case, identifies and records LoadDelfection value
            end
            
end

%% Descriptions and units
T.Properties.VariableUnits = {'', '', '','','', 's', 'mm', 'N', 'N/mm', 'MPa', 'N', 'mm', '', ''};
T.Properties.VariableDescriptions{'Time'} = 'Array of time values during INSTRON test.';
T.Properties.VariableDescriptions{'Displacement'} = 'Array of displacement values during INSTRON test.';
T.Properties.VariableDescriptions{'Force'} = 'Array of force values during INSTRON test.';
T.Properties.VariableDescriptions{'LoadDeflection'} = 'Automatically generated overview value based on INSTRON method. In this case, the slope was taken from the Force data at displacements of 0.8 mm and 1 mm. This number is not to be trusted. In some cases, the number was not generated at all.';
T.Properties.VariableDescriptions{'Modulus'} = 'Automatically generated overview value based on INSTRON method. This number requires an input for cross sectional area of the plant, which was not measured. Hypothetically, a coefficient can be discovered for adjustment, based on the span of the INSTRON at the time of testing.';
T.Properties.VariableDescriptions{'MaxLoad'} = 'Max load, identified automatically. Should be checked for accuracy.';
T.Properties.VariableDescriptions{'DisplacementAtMaxLoad'} = 'Displacement at max load, calculated automatically. Should be checked for accuracy.';
T.Properties.VariableDescriptions{'BreakType'} = 'Choices: CRUSHED, SNAPPED, or SPLINTERED.'; 

%% SAVE PROGRESS

%T_barley = T;
T_wheat99 = T; % INPUT OPPORTUNITY.

%%  Common issues and solutions.
% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %%
% 1) Open T and look for NaN values in the Modulus, MaxLoad, and
%       DisplacementAtMaxLoad columns.
%
%       NaN values in these columns indicates that a text note was written
%       too lengthy in the Instron interface, and so the overview file
%       contains that text in unexpected places. This commonly results in
%       other columns being disturbed. 
%
%       If this is an issue, the relevant overview file needs opened and 
%       manually edited. If there is test that needs to be removed from a
%       cell, it should be able to be pasted at the end of the text within
%       the cell to its left, where the entire statement should be
%       contained.
    clear plot
% Clear this variable, so to enable the command plot()


