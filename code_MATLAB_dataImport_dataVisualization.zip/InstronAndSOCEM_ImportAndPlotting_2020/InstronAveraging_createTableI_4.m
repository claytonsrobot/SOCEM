% InstronAveraging_createTableI_4
%% header
% Author: Clayton Bennett
% Updated: 7/19/2021
% Purpose: Create table I, the formatted wheat Instron file, prepared for
%   comparison.
% User notes: 
%   - The purpose of this script is to take the prepared Instron
%       data file and to prepare it further for comparison to the SOCEM 
%       data file.
%   - All sections are meant to be run one at a time.
%   - Once complete, I will be ready to be used by
%       "InstronSocemComparisonPlotting.m"
%   - Table T is required to exist in the MATLAB workspace. It can be found
%       by loading a previously created table T; for example, 
%       "wheatInstron2020_IndividualAndOverview.mat".


%% EDITS
% Add columsns to table, for Plot name, stem number, run number

%% % Identify proper height for table I. Currently, it is manually assesed.
% Ideas on how to do this:
%   - Count number of differnt overview file names.
%   - Count how many times Stem == 1
i=1;
for k=1:height(T)
     if T.Stem(k)==1
         i=i+1;
     end
end
heightI=i-1;

%% Initialize Table
% WARNING DO NOT RUN THIS AGAIN
% Commented out for security


varnamesI = {'Variety','Plot','AveLoadDeflectionSlope','StdLoadDeflectionSlope','AveMaxLoad','StdMaxLoad','AveDisplacementAtMaxLoad','StdDisplacementAtMaxLoad','AveMaxMoment','StdMaxMoment'};
I = cell2table(cell(heightI,10), 'VariableNames', varnamesI);%, 'RowNames', rownames); %WHERE DOES 64 COME FROM
I.Variety = strings([heightI,1]);
I.Plot = strings([heightI,1]);

%% For Barley, we can go ahead and remove all but the first run, right?


%% Identify different plot names, Pass from T to I
 % for some plotname, look at all of the numbers in some column,
 % average them and std them, assigning these to tables of some index with
 % a matching plotname
 % Repeat for multple columns before moving on to the next plotname
 % T has ~544 rows, I has ~64 rows for wheat 2020;
 % T has 362 rows and I has 44 rows for barley 2020;
 % have 
i=1;
for k=1:height(T)
     if T.Stem(k)==1
         I.Plot{i}=T.Plot{k};
         i=i+1;
     end
end
i=i-1; % correct for final pass

%% Pull in variety names
% Have a csv or txt file for this express purpose.
% Create a list with two columns: plot numbers and variety names
% Source this information from breeder provided data.

% Have the reference work regardless of a letter 'b' in the Plot name.
% A letter b represents the second time a plot was run. The first time may
% have been discarded.

directory_varietyNamesFile = strcat(directory,'varietyNames.txt');
varietyNamesTable = readtable(directory_varietyNamesFile,'FileType','text');
varietyNamesTable.Variety = string(varietyNamesTable.Variety);
varietyNamesTable.Plot = string(varietyNamesTable.Plot);

for i=1:heightI
    for k=1:height(varietyNamesTable)
    	if erase(I.Plot(i),'b') == varietyNamesTable.Plot(k)
            I.Variety(i) = varietyNamesTable.Variety(k);
        end
    end
end

%% Remove rows from overshot row count
% % DEFUNCT.
% This is a good method for removing excess rows in any scenario.
% #MATLABskills.
% This isn't actually necessary if heightI is correct.


% i=1;
% while i<heightI
%     if I.Plot(i)==""
%         I(i,:)=[];
%     elseif I.Plot(i)~=""
%         i=i+1;
%     end
% end

%% Averaging scheme
% This should work for both cyclc and non-cyclic tests, with row and stem
%   number columns. 

idx_plot=zeros(height(T),1);
listLDS=[]; %load deflection slope
listML=[]; %max load
listDML=[];%dispacement at max load

for i=1:height(I)
    
    Iplot=I.Plot(i);
    % This is here to demonstrate when the name changes,
    %   to make it easier to read the loop.
    % It also makes it slightly easier to code.
    % %% %%
    
    % %% Aggregation lists:
    % Clear these lists for each row of I.
    % Each row of I represents a different plot.
    idx_plot=zeros(height(T),1);  
    listLDS=[]; %load deflection slope
    listML=[]; %max load
    listMM=[]; %max moment
    listDML=[]; %dispacement at max load
    listEI=[]; %EI
    % %% %%
    
    for k=1:height(T)
    % Look through every row of table T, looking for plot names that match
    % the current plot name from table I. Data from relevant rows in table
    % T will be collected in the aggregation lists, processed, and then
    % stored in table I.
    % %%
        
        Tplot=T.Plot(k);
        % This is here to demonstrate when the plot name changes,
        %   to make it easier to read the loop.
        % It also makes it slightly easier to code.
        % %% %%
        
        if Iplot==Tplot & T.Run(k)==1 
            idx_plot(k)=1; % Checks which rows were included. 
            % 1's are included, zeros are excluded.
            listLDS(end+1)=T.LoadDeflectionSlope(k);%T.LoadDeflection(k);%
            listML(end+1)=T.MaxLoad(k);
            listMM(end+1)=T.MaxMoment(k); %% doesn't exist yet
            listDML(end+1)=T.DisplacementAtMaxLoad(k);
            listEI(end+1)=T.EI(k);
        end
    end
    I.AveDisplacementAtMaxLoad{i}=mean(listDML);
    I.StdDisplacementAtMaxLoad{i}=std(listDML);
    I.AveLoadDeflectionSlope{i}=mean(listLDS);
    I.StdLoadDeflectionSlope{i}=std(listLDS);
    I.AveEI{i}=mean(listEI);
    I.StdEI{i}=std(listEI);
    I.AveMaxLoad{i}=mean(listML);
    I.StdMaxLoad{i}=std(listML);
    I.AveMaxMoment{i}=mean(listMM);
    I.StdMaxMoment{i}=std(listMM);

end

% Keep the Workspace tidy. Clear variables with no further use.
clear listDML listEI listLDS listML listMM Tplot Iplot

%% Alter class types.
I.AveLoadDeflectionSlope=cell2mat(I.AveLoadDeflectionSlope);
I.StdLoadDeflectionSlope=cell2mat(I.StdLoadDeflectionSlope);
I.AveMaxLoad=cell2mat(I.AveMaxLoad);
I.StdMaxLoad=cell2mat(I.StdMaxLoad);
I.AveDisplacementAtMaxLoad=cell2mat(I.AveDisplacementAtMaxLoad);
I.StdDisplacementAtMaxLoad=cell2mat(I.StdDisplacementAtMaxLoad);
I.AveMaxMoment=cell2mat(I.AveMaxMoment);
I.StdMaxMoment=cell2mat(I.StdMaxMoment);
I.AveEI=cell2mat(I.AveEI);
I.StdEI=cell2mat(I.StdEI);

%% Units and descriptions
%varnames = {'Name','Plot','AveLoadDeflectionSlope','StdLoadDeflectionSlope','AveMaxLoad','StdMaxLoad','AveDisplacementAtMaxLoad','StdDisplacementAtMaxLoad','AveMaxMoment','StdMaxMoment','AveEI','StdEI'};
I.Properties.VariableUnits = {'', '', 'N/mm', 'N/mm', 'N', 'N', 'mm', 'mm', 'N*mm', 'N*mm', 'N*mm^2', 'N*mm^2'};
I.Properties.VariableDescriptions{'AveLoadDeflectionSlope'} = '';
I.Properties.VariableDescriptions{'StdLoadDeflectionSlope'} = '';
I.Properties.VariableDescriptions{'AveDisplacementAtMaxLoad'} = '';
I.Properties.VariableDescriptions{'StdDisplacementAtMaxLoad'} = '';
I.Properties.VariableDescriptions{'AveEI'} = '';
I.Properties.VariableDescriptions{'StdEI'} = '';
I.Properties.VariableDescriptions{'AveMaxLoad'} = '';
I.Properties.VariableDescriptions{'StdMaxLoad'} = '';
I.Properties.VariableDescriptions{'AveMaxMoment'} = '';
I.Properties.VariableDescriptions{'StdMaxMoment'} = '';

%% Name formatting, prep for comparison.
% DEFUNCT

%for k=1:height(I)
% I.Plot{k}=strrep(I.Plot{k},'clearfield','CF');
% I.Plot{k}=strrep(I.Plot{k},'hardwinter','HW');
% I.Plot{k}=strrep(I.Plot{k},'softwinter','SW');
% I.Plot{k}=strrep(I.Plot{k},'springbarleyfeed','SBF');
% I.Plot{k}=erase(I.Plot{k},'b');
%end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % This part is waaaay back up the chain now
% % DEFUNCT
% 
% i=1;
% while i<heightI
%     if isempty(strfind(I.Plot(i),'.'))==0
%         stemRaw=eraseBetween(I.Plot(i),1,(strfind(I.Plot(i),'.')));
%         stemClass=class(stemRaw);
%         stemNumber=str2num(stemRaw);
%         plotName=eraseBetween(I.Plot(i),(strfind(I.Plot(i),'.')),strlength(I.Plot(i)));
%         if I.Stem(i)~=1
%             stemNumber;
%             I(i,:)=[];
%         elseif stemNumber==1
%             I.Plot(i)=plotName;
%             i=i+1;
%         end
%     else
%         i=i+1;
%     end
%     
% end
% 
% % Keep the Workspace tidy. Clear variables with no further use.
% clear stemRaw stemClass stemNumber plotName
%% manual cleanup
% % DEFUNCT
% for "SBF304.5b" case in barley
%I(6,:)=[];


%% Plot Name change
% for i=1:height(I)
%     I.Plot(i)=
% end
%% Cleanup
I = sortrows(I);
clear heightI

% summary(I)

%% Add section to remove duplicate rows in case of cyclic instances
