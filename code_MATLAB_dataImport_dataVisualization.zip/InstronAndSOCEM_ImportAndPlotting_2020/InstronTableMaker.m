     function[T]=InstronTableMaker(directory, individualFileName, overviewFileName, cyclic)

% %%
% title: InstronTableMaker_2021.m
% author: Clayton Bennett
% created: January 2021
% last edits: 27 July 2021
% %%%

% %%
% Example of function input T = InstronTableMaker(directory,'springbarleyfeed','0SBF','cyclic')
%
% Format: T = InstronTableMaker(directory,"startOfIndividualCSVFile","startOfOverviewCSVFile",'cyclic')
%
% To input multiple expected names, use a list: T = InstronTableMaker({'hardwinterwheat*.csv','clearfield*.csv','softwinterwheat*.csv'},0SBF*.csv) 
% %%%

% %%
% If modularity is to be possible, will need a way to better identify columns in overview files, rather than
%   varibale "c", used below in this script.
% Additonal schemes can be added to the fourth variable, beyond cyclic
%   versus non-cyclic. 
% %%%

clear T % The output table will be replaced when this script/function is run.
%cyclic_workspace = cyclic;
%% Save raw text for typical directories in use.

%directory = ('C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\Barley\September 2020\');
%directory = ('C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\Barley\September 2020\Alt Method - No AutoStop, continuous\');
%directory = ('C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\Barley\September 2020\Alt Method - 5% Decrease Past Max Reading\');
%directory = ('C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\Wheat\August 2020\')
%directory = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Instron Data 2020\Wheat\August 2020\Alt Method - No AutoStop, continuous\'

% %%
% If '\' is not input by the user as the final character in the directory
% assignment, add  it.
% 
if (directory(end)~='\')
    directory = strcat(directory,'\');
end
% %%%
%% Identify Instron files that have individual test arrays for Time, Displacement, and Force.
individualFileNameCSV = strcat(individualFileName,'*.csv'); % Ensure that only CSV files are looked for.
filelist_individual = dir(strcat(directory,individualFileNameCSV)); % INPUT OPPORTUNITY.
files_individual = {filelist_individual.name};
% 
% "files_indvidual" is a list of CSV files that start with
% "individualFileName". This name will be tranlated to the expected
% overview filename for each instance.
% %%%

%% PREPARE THE TABLE
n = numel(files_individual)'; % How many indivdual files are there in the directory?

varnames = {'i','Variety','Plot','Stem','Run','File','OverviewFile','Time', 'Displacement','Force'};
T = cell2table(cell(n,10), 'VariableNames', varnames); % Create table T.
T.i = nan(height(T),1); % Prepare column "i" to be numbers.
T.Variety = strings([height(T),1]);
T.Plot = strings([height(T),1]); % Prepare column "Plot" to be strings.
T.Stem = nan(height(T),1); % Prepare column "Stem" to be numbers.
T.Run = nan(height(T),1); % Prepare column "Run" to be numbers.
T.File = strings([height(T),1]); % Prepare column "File" to be strings.
T.OverviewFile = strings([height(T),1]); % Prepare column "OverviewFile" to be strings.
section1of7 = "The table T has been prepped, with index, name, and array variables initialized." % Output message.
%% Naming Interpretation, if the name refers to sample numbers, notes, etc.
% %% Variables that are managed here:
% %    Filename
% %        Referred to as:
% %            File
% %            T.File(j)
% %            file_individual(j)
% % 
% %    Plotname
% %        Referred to as:
% %            Plot
% %            T.Plot(j)
% % 
% %    Overview filename
% %        Referred to as:
% %            OverviewFile
% %            T.OverviewFile(j)
% % 
% %    Stem number
% %        Referred to as:
% %            Stem
% %            T.Stem(j)
% %        Based on how many stems were tested for each plot.
% % 
% %    Run number
% %        Referred to as:
% %            Run
% %            T.Run(j)
% %        Based on how many repeated tests were run on each stem.
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  All of this information comes directly from the filename for each
% %%      indivdual test.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for j=1:n
    
    % Identify each file name, one at a time.
    File = string(files_individual(j)); 
    % %% It's easier to read this way, for the rest of the loop.

    % %% Relate each individual test filename to its corresponding overview file.
    %
        OverviewFile = string(strrep(File,individualFileName,overviewFileName));
    %
        OverviewFile = string(strrep(OverviewFile,'.nonnode',''));
        OverviewFile = string(strrep(OverviewFile,'_UISilver',''));
    %  Add non-normal strings to be removed here, if non-normal portion
    %        of the name is not included in the overview filname
        OverviewFile = eraseBetween(OverviewFile,strfind(OverviewFile,'_'),strfind(OverviewFile,'.csv')-1);
    %  Cleanup non-standard names, because they will not be seen in any
    % %%    overview file name.
    
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % %% This section creates the variable Plot.
                %
                %       This section assumes certain naming convention and
                %       number placement.
                %
                %       For an individual file 'springbarleyfeed111.1_3.csv' in a cyclic
                %       test folder, this is 'individualFileName.Stem_Run.csv'.
                %       For an overview file 'OSBF111.1.csv' in a cyclic
                %       test folder, this is 'overviewFileName.Stem.csv'.
                %       Overview files for cyclic tests should include multiple runs of the same stem.
                %       
                %       For an individual file 'springbarleyfeed215_2.csv' in a non-cyclic
                %       test folder, this is 'individualFileName_Stem.csv'.
                %       For an overview file 'OSBF111.csv' in a non-cyclic
                %       test folder, this is 'overviewFileName.csv'.
                %       Overview files for non-cyclic tests should include multiple  stems.       
                %
                %       While bothering with filenames, extracted from each individual
                %       test filename the Stem number and the Run number.
                
                if mean(or(string(cyclic) == 'cyclic', cyclic == 1))
                    Plot = eraseBetween(File,min(strfind(File,'.')),strlength(File)); %for cyclic tests
                    Stem = str2double(extractBetween(OverviewFile,min(strfind(OverviewFile,"."))+1,max(strfind(OverviewFile,'.'))-1)); %for cyclic tests
                    Run = str2double(extractBetween(File,max(strfind(File,'_'))+1,strfind(File,'.csv')-1));  %for cyclic tests
                elseif mean(or(string(cyclic) == 'non-cyclic', cyclic == 0))
                    Plot = eraseBetween(File,min(strfind(File,'_')),strlength(File)); %for non-cyclic tests
                    Stem = str2double(extractBetween(File,max(strfind(File,'_'))+1,strfind(File,'.csv')-1)); %for non-cyclic tests
                    Run = 1; %for non-cyclic tests   
                else
                    errorMessage = "For the 4th variable, cyclic, expected values are 'cyclic', 1, 'non-cyclic', or 0"
                end
                % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Specific to SOCEM data
    Plot = strrep(Plot,'springbarleyfeed','SBF'); % for 2020 Barley
    Plot = strrep(Plot,'clearfield','CF'); % for 2020 Wheat
    Plot = strrep(Plot,'hardwinter','HW'); % for 2020 Wheat
    Plot = strrep(Plot,'softwinter','SW'); % for 2020 Wheat
    % %%
    
    % %% Store active variables, pulled from each file name, into row j of table T.
    T.i(j)=j;
    T.File(j)=File;
    T.Plot(j)=Plot;
    T.OverviewFile(j)=OverviewFile;
    T.Stem(j)= Stem;
    T.Run(j)=Run;
    % %%
    
end

section2of7 = "File names have been interpretted." % Output message.

%% Display first five rows of the table T, so that you know what it looks like.

    headT_preDataImport = head(T,5) % Display.
        
section3of7 = "Sample view of table T has been displayed."
%% IMPORT ARRAYS FROM INDIVIDUAL FILES
% This is slow, because each file must be opened, recorded, and closed. That's okay.
% This import method should work for all individual Instron files.

heightT=height(T);
handle_waitbar_individualFiles=waitbar(0,strcat('Arrays are being imported from ',string(heightT),'individual Instron files. It is slow. But it is probably faster than you.')); % develop this more

for j = 1:height(T)
    %fprintf('%d,', j); % As a functinal loading bar, this will print j, the index
    %   number of the row.
    waitbar(j/height(T),handle_waitbar_individualFiles)
    [Time, Displacement,Force]=csvimport(strcat(directory, T.File{j}),'columns',{'Time','Displacement','Force'});
    
    % %% Remove first value from each imported column.
    Time=Time(2:end);
    Displacement=Displacement(2:end);
    Force=Force(2:end);
    
    % %% Store entire arrays for each Instron test into each row j of table T.
    T.Time(j)=mat2cell(str2double(erase(Time,'"')),length(Time));
    T.Displacement(j)=mat2cell(str2double(erase(Displacement,'"')),length(Time));
    T.Force(j)=mat2cell(str2double(erase(Force,'"')),length(Time));
    
end

close(handle_waitbar_individualFiles)

%  Up to this point, most things apply to importing only individual
% %%      files.
section4of7 = "Arrays have been imported from individual files."
%% Prepare the table T, by adding more columns, to import numerical and text data from overview files.
% %% This section is possibly too custom to scale, because different
%       Instron Methods will result in different overview output variables,
%       in different cell locations within the overview spreadsheets (and
%       thus at different row and column coordinates within the variable
%       "c_overviewDataPullIn", which represents spreadsheet data for each
%       overview file).

T.LoadDeflection = nan(height(T),1); % Prepare column "LoadDeflection" to be numbers.
T.Modulus = nan(height(T),1); % Prepare column "Modulus" to be numbers.
T.MaxLoad = nan(height(T),1); % Prepare column "MaxLoad" to be numbers.
T.DisplacementAtMaxLoad = nan(height(T),1); % Prepare column "DisplacementAtMaxLoad" to be numbers.
T.BreakType = strings([height(T),1]);
T.Notes = strings([height(T),1]);

section5of7 = "The table is prepared for overview values."
%% Go through each line in table and assign loadDeflection, Modulus, MaxLoad, DisplacementAtMaxLoad, Notes, BreakType
% %% Are these variabes and this format expected for all INSTRON tests?
%           Modulus, MaxLoad, DeflectionAtMaxLoad, Notes, Breaktype
%
% This is slow, because each file must be opened, recorded, and closed. That's okay.
%
% It works! But it could be more smooth...maybe. Issue: It opens and closes
% the same Excel file multiple times. Can each Overview File stay open
% until it is complete? There is a way to do this, that involves counting
% the number of tests in the overview file and adding another loop. But!
% The current method is fullproof and scalable.

heightT=height(T);
handle_waitbar_overviewFiles=waitbar(0,strcat('Data is being imported from ',string(heightT),'overview Instron files. Computer speed, go!'));


for j=1:height(T)
%     if j==35
%         T.File(j)
%         T
%     end
    
    [ndata_notUsed, text_notUsed, c_overviewDataPullIn] = xlsread(strcat(directory,T.OverviewFile(j))); %c is of type cell %% ERROR for j=63, j=23
    fprintf('%d.', j)
    waitbar(j/height(T),handle_waitbar_overviewFiles)
    
                if mean(or(string(cyclic) == 'cyclic', cyclic == 1))
                    rowIndex = T.Run(j); % for cyclic tests
                elseif mean(or(string(cyclic) == 'non-cyclic', cyclic == 0)) 
                    rowIndex = T.Stem(j); % for non-cyclic tests
                else
                    errorMessage = "For the 4th variable, cyclic, expected values are 'cyclic', 1, 'non-cyclic', or 0"
                end

            T.Modulus(j) = cell2mat(c_overviewDataPullIn(7+rowIndex-1,3)); %MPa, Young modulus, auto
            T.MaxLoad(j) = cell2mat(c_overviewDataPullIn(7+rowIndex-1,4)); %N, max forces from each stalk
            T.DisplacementAtMaxLoad(j) = cell2mat(c_overviewDataPullIn(7+rowIndex-1,5)); %mm, displacement at max
            T.Notes(j) = cell2mat(c_overviewDataPullIn(7+rowIndex-1,6)); %notes
            T.BreakType(j) = cell2mat(c_overviewDataPullIn(7+rowIndex-1,7)); %breaktype
            
            % %% If LoadDeflection(j) happens to equal NaN, i.e. if no value Load Deflection value was recorded by the Intsron.
            if ischar(cell2mat(c_overviewDataPullIn(7+rowIndex-1,2)))
                T.LoadDeflection(j)=str2double(cell2mat(c_overviewDataPullIn(7+rowIndex-1,2))); %% enters NaN inteads of '-----', if no LoadDflection value was recorded by the Instron.
            else
                T.LoadDeflection(j)= cell2mat(c_overviewDataPullIn(7+rowIndex-1,2)); % typical case, identifies and records LoadDelfection value
            end
            
end
close(handle_waitbar_overviewFiles)

section6of7 = "Overview values have been imported."
%% Descriptions and units
% %% Is scalable only if in metric and these are the expected variables. +*#*#*#*#*#*+
T.Properties.VariableUnits = {'','','', '', '','','', 's', 'mm', 'N', 'N/mm', 'MPa', 'N', 'mm', '', ''}; 
T.Properties.VariableDescriptions{'Time'} = 'Array of time values during INSTRON test.';
T.Properties.VariableDescriptions{'Displacement'} = 'Array of displacement values during INSTRON test.';
T.Properties.VariableDescriptions{'Force'} = 'Array of force values during INSTRON test.';
T.Properties.VariableDescriptions{'LoadDeflection'} = 'Automatically generated overview value based on INSTRON method. In this case, the slope was taken from the Force data at displacements of 0.8 mm and 1 mm. This number is not to be trusted. In some cases, the number was not generated at all.';
T.Properties.VariableDescriptions{'Modulus'} = 'Automatically generated overview value based on INSTRON method. This number requires an input for cross sectional area of the plant, which was not measured. Hypothetically, a coefficient can be discovered for adjustment, based on the span of the INSTRON at the time of testing.';
T.Properties.VariableDescriptions{'MaxLoad'} = 'Max load, identified automatically. Should be checked for accuracy.';
T.Properties.VariableDescriptions{'DisplacementAtMaxLoad'} = 'Displacement at max load, calculated automatically. Should be checked for accuracy.';
T.Properties.VariableDescriptions{'BreakType'} = 'Choices: CRUSHED, SNAPPED, or SPLINTERED.';
T.Properties.VariableDescriptions{'Variety'} = '';

%% Pull in variety names
% Have a csv or txt file for this express purpose.
% Create a list with two columns: plot numbers and variety names
% Source this information from breeder provided data.

% Have the reference work regardless of a letter 'b' in the Plot name.
% A letter b represents the second time a plot was run. The first time may
% have been discarded.

directory_varietyNamesFile = strcat(directory,'varietyNames.txt');
varietyNamesTable = readtable(directory_varietyNamesFile,'FileType','text');
varietyNamesTable.Variety = string(varietyNamesTable.Variety);
varietyNamesTable.Plot = string(varietyNamesTable.Plot);

for i=1:heightT
    for k=1:height(varietyNamesTable)
    	if erase(T.Plot(i),'b') == varietyNamesTable.Plot(k)
            T.Variety(i) = varietyNamesTable.Variety(k);
        end
    end
end

section7of7 = "Descriptions and units have been added to the table. The function is complete."
%%  Common issues and solutions.
% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %% %%
% 1) Open T and look for NaN values in the Modulus, MaxLoad, and
%       DisplacementAtMaxLoad columns.
%
%       NaN values in these columns indicates that a text note was written
%       too lengthy in the Instron interface, and so the overview file
%       contains that text in unexpected places. This commonly results in
%       other columns being disturbed. 
%
%       If this is an issue, the relevant overview file needs opened and 
%       manually edited. If there is test that needs to be removed from a
%       cell, it should be able to be pasted at the end of the text within
%       the cell to its left, where the entire statement should be
%       contained.


