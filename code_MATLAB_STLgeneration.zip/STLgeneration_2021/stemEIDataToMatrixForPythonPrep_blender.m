i=1
while i<=44
    if plotnames{i}==plots(i)
        i=i+1;
    else
        plots(i)=[];
        mat(:,i)=[];
    end
end

%sort each column of mat

for i=1:44
    col=mat(:,i)
    
    
    
    col
end