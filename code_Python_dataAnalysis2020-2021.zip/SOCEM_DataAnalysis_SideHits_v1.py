'''
SOCEM Data Analysis_SideHitsAutoAssess
Author: Clayton Bennett
Created: April 3, 2022

Based heavily on SOCEM_DataAnalysis, originally created by Austin Bebee.

Description: Auto assess SOCEM side hit tests.

Future work:
        - Plot changes in initialPlot, prior to autosaving, showing xCut red-line selections
        - In choosePeaks(), show zone differentiation lines, halfway between each horz value and the next.
Bugs:
    - (Rarely, only during troubleshooting) The betaV value in the EI_Interaction tool cannot calculate because the arcsin query is above 1.0. Observed value of 1.04. Typical observed range of 0.8 to 0.99.
        o Fix: (Currently not active) If the arcsin query is above 1.0, change it to 1.0. This change must be made in the EI_Interaction_Fx script.
        o If value exceeds 1, have value print.
    - ...

Question: Use 5 rows, as in doc, or use 1 row, override?
Answer: Use 1 row!!

'''
# needed libraries
import math
import pandas as pd
from pandas import ExcelFile
from pandas import ExcelWriter
import numpy as np
from numpy import trapz
from datetime import date
from datetime import datetime as dt
import os
import xlsxwriter
# import peakutils
import matplotlib.pyplot as plt
from matplotlib.widgets import Cursor
# custom scripts
import EI_Interaction_Fx
import EI_No_Interaction_Fx
import pushDirection_fileNameScan
from getFileCreationDate import getFileCreationDate
from pushDirection_fileNameScan import pushDirection
import sideHitLengthRange_fileNameScan # not yet in service
from sideHitLengthRange_fileNameScan import sideHitLengthRange
from BuildFolders import buildfolders
#import generateGraphs_SOCEMAnalysis


overwriteAtWill = 'y' #change this to 'n' unless you know you're redoing a dataset.
# Edit these folders to change which data is analyzed and where they go
topFolder = r'D:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\Data - Instron and SOCEM\SOCEM_DATA_2021'
analysisDirectory =  '\\August23_Copy_RemoveEdges\\' # EDIT HERE

#folderToProcess = r'D:\Instron Wheat Testing 2021\SAVED_DATA_2021\August5\encoderWorkedNo' # moved out
folderToProcess = topFolder + analysisDirectory + 'encoderWorkedYes' # moved out
addressProcessed = topFolder + analysisDirectory + 'EI_outputFiles' # moved 
analyzedFolder = topFolder + analysisDirectory +  'analyzedRaw' # new files
documentationFolder =  topFolder + analysisDirectory +  'Documentation' # where plot images are autosaved
harvestManual = date(2020,9,4) # EDIT DATE WHEN THE FOLDER IS CHANGED
loc = 'Genesee, Badlus Road'
#loc = (str(input('Location? Examples: { Genesee, Poxleitner Farm }, { Genesee, Badlus Road }, { Moscow, Plant Science Road } ')))

#plotHeightSpreadsheet = r'C:\Users\clayton\Google Drive\School\University of Idaho\AgMEQ\SOCEM\SAVE_DATA_2020\August20\Documentation\plotHeights2020.xlsx' # this shouldn't change for data within the same field (Example, Baldus Rd)
plotHeightSpreadsheet = r'D:\Backups\GoogleDrive_AgMEQ_03312022\SOCEM\Experimental Design and Preparation\Planning Wheat 2021\plotHeights2021.xlsx'
fileCreationDates = getFileCreationDate(folderToProcess)
print(fileCreationDates)
#getFileCreationDate(folderToProcess)
harvestYear = 2021
harvestMonth = 8
dateFolderName = analysisDirectory.replace("\\","") # folderToProcess.split("\\",4)[3]

#dateTest = [int(i) for i in dateFolderName.split() if i.isdigit()] # this only works if there is a space
#daTest = 5 #findNumeric data in text string "August5"
harvest = harvestManual
harvestdate = harvest
print(harvestdate.strftime("%B"))

##if dateFolderName=='troubleshoot' or dateFolderName=='correctedHeights':
##    harvestManual = date(2021,8,5)
##else:
##    dayTest = int(dateFolderName.replace("August",""))
##    if date(harvestYear,harvestMonth,dayTest) == harvestManual:
##    # do nothing
##        harvest = harvestManual
##    else:
##        harvestDay = (int(input('Harvest day (DD)? '))) # in case I forget to change the date in the script # Future: Fix the internal clock on the raspberry pi!    
##        harvest = date(harvestYear,harvestMonth,harvestDay)
##    
#generateGraphs = (str(input('Would you like graphs to be generated in the exported analysis files (y/n)? ')))
generateGraphs = 'y'


df2 = pd.read_excel(plotHeightSpreadsheet)
varietyList = df2.iloc[0]
varietyList = varietyList.to_numpy().tolist()
plotList = df2.iloc[1]
plotList = plotList.to_numpy().tolist()
heightsArray = df2.iloc[2:10]
heightsArray = heightsArray.to_numpy()
dateList = df2.iloc[18]


class SnaptoCursor(object):
    '''
    Cursor crossshair snaps to nearest x, y point.
    '''
    def __init__(self, ax, x, y):
        self.ax = ax
        #self.lx = ax.axhline(color='gold') # horizontal line
        self.ly = ax.axvline(color='orange', linewidth=1, linestyle="--") # vertical line
        self.x = x
        self.y = y
        # text location in axes coords
        self.txt = ax.text(0.7, 0.9, '', transform=ax.transAxes)

    def mouse_move(self, event):
        if not event.inaxes:
            return

        x, y = event.xdata, event.ydata
        indx = min(np.searchsorted(self.x, x), len(self.x)-1)
        x = self.x[indx]
        y = self.y[indx]
        # update the line positions
        #self.lx.set_ydata(y)
        self.ly.set_xdata(x)

        self.txt.set_text('x=%1.2f, y=%1.2f' % (x, y))
        #print('x=%1.2f, y=%1.2f' % (x, y))
        self.ax.figure.canvas.draw()

class Cursor(object):
    '''
    Cursor crosshair that follows mouse
    '''

    def __init__(self, ax):
        self.ax = ax
        self.lx = ax.axhline(color='orange', linewidth=1, linestyle="--")
        self.ly = ax.axvline(color='orange', linewidth=1, linestyle="--")
        #text location in axes coords
        self.txt = ax.text(0.7, 0.9, '',transform=ax.transAxes)

    def mouse_move(self, event):
        if not event.inaxes:
            return
        x, y = event.xdata, event.ydata
        #update line positions
        self.lx.set_ydata(y)
        self.ly.set_xdata(x)

        self.txt.set_text('x=%1.2f, y=%1.2f' % (x, y))
        self.ax.figure.canvas.draw()



#####################################################################################################################
def initialPlot(dis, fpr, time, encoderWorked, horz, varietyAndPlotnameAndDetail, documentationFolder):
    fig, ax = plt.subplots()

    if encoderWorked == 'y':  
        #start = 20 # cut off 1st 20" usually
        #end = horz[-1]# x[-1] - 20 # cut off last 20" usually
        start = min(dis)
        end = max(dis)
        xCut = []
        xCut.append((start))
        xCut.append((end))
    else:
        speed = 17 # 1*12 # 0.5*12 # assume in/s (ave speed ~ 0.5 ft/s
        startDis = 20 # cut off 1st 20" usually
        start = startDis/speed # CB edit # 20/speed # find t where SOCEM ~ 20" into plot
        endDis = 120 # cut of after 120" usually
        end = endDis/speed # CB edit # time[-1] - (20/speed) # find t where SOCME ~ 20" before end of plot
        disReferenced = str(input('Would you like to type in known distance points (y/n)? '))
        if disReferenced == 'y':
            startDisRef = (int(input('Start point x (in): ')))
            endDisRef = (int(input('End point x (in): ')))
                  
              
        
    maxPt = max(fpr)
    # draw cut off lines
    cutStart = [start, start]
    cutEnd = [end, end]
    cutLine = [0, maxPt]
    ax.plot(cutStart,cutLine, color = 'red') # start cut off line
    ax.plot(cutEnd, cutLine, color = 'red') # end cut off line
    
    
    # plot dis vs fpr    
    if encoderWorked == 'y':
        ax.plot(dis, fpr, color='midnightblue')
        ax.set_xlabel('Distance (in.)')
        snap_cursor = SnaptoCursor(ax, dis, fpr) # create snap cursor object
    # plot time vs fpr
    else:
        ax.plot(time, fpr, color='midnightblue')
        ax.set_xlabel('Time (s)')
        snap_cursor = SnaptoCursor(ax, time, fpr) # create snap cursor object
    title3 = '\n*click outside plot if red lines good*'
    fig.suptitle(varietyAndPlotnameAndDetail + '\nCut off edges: click start x pt, then end x pt.' + title3)
    #ax.set_title('*click outside plot if red lines good*')
    ax.set_ylabel('Force/row (lbs.)')
    
    snap = fig.canvas.mpl_connect('motion_notify_event', snap_cursor.mouse_move) # update snap cursor upon mouse movement

    

    xCut = [] # stores where to cut off ends of plot (eliminate edge effects)
    def click(event): # get x coord once mouse is pressed
        x = event.xdata
        if x is None:
            print('red lines')
            xCut.append((start))
            xCut.append((end))
        else:
            print('x clicked = %1.2f' % x)
            xCut.append((x))
          #  self.fig.canvas.mpl_disconnect(cid)
        if len(xCut) >= 2:
            fig.canvas.mpl_disconnect(cid)
            fig.canvas.mpl_disconnect(snap)
            if encoderWorked == 'y':
                savename = varietyAndPlotnameAndDetail + '_' + str(round(xCut[0],1)) + '-' + str(round(xCut[1],1)) + '_raw.PNG'
            elif encoderWorked == 'n' and disReferenced == 'y':
                savename = varietyAndPlotnameAndDetail + '_' + str(round(xCut[0],1)) + '-' + str(round(xCut[1],1)) + '_disref' + '_raw.PNG'
            elif encoderWorked == 'n' and disReferenced == 'n':
                savename = varietyAndPlotnameAndDetail + '_' + str(round(xCut[0],1)) + '-' + str(round(xCut[1],1)) + '_timebased' + '_raw.PNG'
            ax.plot([xCut[0],xCut[0]],cutLine, color = 'orange', linewidth=1, linestyle="--") # start cut off line
            ax.plot([xCut[1],xCut[1]], cutLine, color = 'orange', linewidth=1, linestyle="--") # end cut off line
            plt.savefig(documentationFolder + '\\' + savename)
            plt.close()
        return xCut # return start & end x (dis. or time) pts
    
    cid = fig.canvas.mpl_connect('button_press_event', click) # connects click event

    #clicked = snap_cursor.click()
    #print('clicked', snap_cursor.click.coords)
    plt.show()
    #print('x', disCut)
    
    if encoderWorked == 'n':
        i=0
        while xCut[0]>time[i]: # since the encoderFailed, xCut is initially the start and end time, and will be converted to tCut
            i = i+1
            
        j=0
        while xCut[1]>time[j]: # 
            j = j+1
   
        disNew=[]
        disNew = [0]*len(time) # initialize list length
        if disReferenced == 'y':
            disNew[i]=startDisRef # assign startDisRef value to the disNew list at the index of start time
            disNew[j]=endDisRef # assign EndDisRef value to the disNew list at the index of end time

            
            ## unused portion of disref will stay zeros
            n=i  
            k=0.000000000
            while n<=j:
                disNew[n]=startDisRef+k*(endDisRef-startDisRef)
                k=k+(1.000000000/(j-i))
                n=n+1

            while n<(len(time)-1):
                disNew[n] = 0 ## fill in the unused portion with zeros
                n=n+1
            print('troubleshoot 6 , time[i] = ', time[i])  
            print('i = ',i , ', j = ', j)    
            xCut = [startDisRef,endDisRef] # change xCut values to referenced startDisRef and endDisRef         

    if encoderWorked == 'y':
        return xCut
    elif encoderWorked == 'n' and disReferenced == 'y':
        return xCut, disReferenced, disNew, i, j
    elif disReferenced == 'n':
        disNew = []
        return xCut, disReferenced, disNew, i, j


###############################################################################

def choosePeaks(xData, fpr, xCut, varietyAndPlotnameAndDetail, encoderWorked, disReferenced, documentationFolder, horz):
    
    def nearest_pt(pt): # get nearest dis index to starting pt in disCut
        idx = (np.abs(np.asarray(xData)- pt)).argmin()
        #print('idx ', idx)
        return idx

    startIdx = nearest_pt(xCut[0]) # starting index
    print('startIdx = ',startIdx) # , dis[startIdx])
    endIdx = nearest_pt(xCut[1])
    print('Closest distance pts: ', [xData[startIdx] , xData[endIdx]]) 
    xCenter = xData[startIdx:endIdx]
    fCenter = fpr[startIdx:endIdx]
    
    fig, ax = plt.subplots()
    fig.suptitle(varietyAndPlotnameAndDetail + '\nSelect Force Peaks, *click outside when done*')
    #fig.suptitle(varietyAndPlotnameAndDetail + '\nCut off edges: click start x pt, then end x pt.' + title3)
    #ax.set_title('*click outside when done*')
    ax.plot(xCenter, fCenter)
    maxPt = max(fpr)
    i=0;
##    while i< (len(horz)-1):
##        cutLine = [0, maxPt]
##        ax.plot([(horz[i]+horz[i+1])/2,(horz[i]+horz[i+1])/2],cutLine, color = 'black',linestyle=':') # start cut off line
##        i+=1
    ax.set_xlim(min(xCenter)-5, max(xCenter)+5)
    ax.set_ylabel('Force/row (lbs.)')
    if encoderWorked == 'y' or disReferenced == 'y':
        ax.set_xlabel('Distance (in.)')
    else:
        ax.set_xlabel('Time (s)')
            

    cursor = Cursor(ax) # create snap cursor object
    cursorMove = fig.canvas.mpl_connect('motion_notify_event', cursor.mouse_move) # update snap cursor upon mouse movement

    peaks = [] # force peaks
    xPeaks = [] # x (distance) pt of force peak
    ## edit here, to autoclick points
##    def autoclick(fpr, xData)
##        threshold = sum(fpr)/len(fpr) # average force per row
##        binmarkers_up = # where a number is less than the thrshold and the next one is above the threshold
##        if maxcount==3:
##        else:
            
            
    
    def click(event): # get x coord once mouse is pressed
        y, x = event.ydata, event.xdata
        if y is None:
            fig.canvas.mpl_disconnect(cid)
            fig.canvas.mpl_disconnect(cursorMove)
            # auto save file
            # example: CF452_24hr_4_23-156_disref_clicks.PNG
            if encoderWorked == 'y':
                savename = varietyAndPlotnameAndDetail + '_' + str(round(xCut[0],1)) + '-' + str(round(xCut[1],1)) + '_clicks.PNG'
            elif encoderWorked == 'n' and disReferenced == 'y':
                savename = varietyAndPlotnameAndDetail + '_' + str(round(xCut[0],1)) + '-' + str(round(xCut[1],1)) + '_disref' + '_clicks.PNG'
            elif encoderWorked == 'n' and disReferenced == 'n':
                savename = varietyAndPlotnameAndDetail + '_' + str(round(xCut[0],1)) + '-' + str(round(xCut[1],1)) + '_timebased' + '_clicks.PNG'

            if overwriteAtWill=='y' and (os.path.exists(documentationFolder + '\\' + savename)):
                os.remove(documentationFolder + '\\' + savename)
            plt.savefig(documentationFolder + '\\' + savename)
            plt.close()
        else:
            # print('Force clicked = %1.2f at %1.2f' % (y, x)) # hide, CB
            peaks.append((y))
            xPeaks.append((x))
            ax.scatter(x, y, color='red')
            
        if peaks == []:
            quit()
            
        return peaks # return start & end dis pts
    
    cid = fig.canvas.mpl_connect('button_press_event', click) # connects click event    
    
    plt.show()
    #startDis = np.where(dis == disCut[0]) # get index
    #print('start Dis ', startDis)
    print('xPeaks = ', xPeaks)
    return peaks, xPeaks

# computes EI along plot (accounts for changing stem heights)
def EIalong(xPeaks, peaks, horz, heights, fb_bottom, spacing):
    
    def nearest_pt(xPeak): # get index of nearest x to xPeak (to pair with heights)
        idx = (np.abs(horz - xPeak)).argmin() # xPeak is unmodified value of click, horz are the values where heights were measured.
        #print('idx ', idx)
        return idx
    
    hatPeaks = [] # h at Peaks (stores height at force peaks)
    for i in range(0, len(xPeaks)): # for every xPeak
        idx = nearest_pt(xPeaks[i])     
        #print('x nearest: ', horz[idx])
        hatPeaks.append(heights[idx])
    #print('H at Peaks ', hatPeaks) # hide, CB

    EIIs = []
    EINs = []
    EIMs = []

    for i in range(0, len(hatPeaks)):
        EII = EI_Interaction_Fx.EI_Interaction(peaks[i], fb_bottom, hatPeaks[i],spacing) # uses clicked forces (Y axis), force bar height, horizontal plot heights, and count density
        EIN = EI_No_Interaction_Fx.EI_NoInteraction(peaks[i], fb_bottom, hatPeaks[i], spacing) # the x value of the click does nothing other than find the nearest height from horz. It is not factored in to the number of beams or the character of the beams. 
        EIM = (EII + EIN)/2

        EIIs.append(EII)
        EINs.append(EIN)
        EIMs.append(EIM)

        EI_Interaction_Fx.clearAll()
        EI_No_Interaction_Fx.clearAll()

    return EIIs, EINs, EIMs, hatPeaks;

def Excel(*args):
#def Excel(filename, name, plotname, time, dis, rows, fpr, fb_bottom, stems, sampDis, spacing, x, heights, xPeaks, peaks, avgPeak, EI, EIs):

    # Create Lists to provide labels
    # single numbers
    analysisL = ['Analysis description']
    varietyL = ['Variety']
    plotnameL = ['Plot']
    detailL = ['Test description']
    filenameL = ['Filename']
    rowsL = ['Rows']
    fb_bottomL = ['Force bar bottom height (in.)']
    fb_middleL = ['Force bar middle height (in.)']
    aveHeightL = ['Avg height (in)']
    stemsL = ['Avg stem count']
    sampDisL = ['Sample distance (in)']
    spacingL = ['Spacing (in)']
               
    avgPeakL = ['Avg force peak (lbs)']
    avgForceL = ['Avg force (lbs), =(Area under curve)/(xCut[1]-xCut[0]) ']
    areaUnderCurveL = ['Area under curve (lbs*in)']
    EIIL = ['EI-I (lbs*in^2)'] # Full beam interaction
    EINL = ['EI-N (lbs*in^2)'] # No beam interaction
    EIML = ['EI-M (lbs*in^2)'] # # Average of full beam and no beam interaction
    aveEIIsL = ['Avg EI-Is (lbs*in^2)']
    aveEINsL = ['Avg EI-Ns (lbs*in^2)']
    aveEIMsL = ['Avg EI-Ms (lbs*in^2)']
    stdEIIsL = ['Std. EI-Is (lbs*in^2)']
    stdEINsL = ['Std. EI-Ns (lbs*in^2)']
    stdEIMsL = ['Std. EI-Ms (lbs*in^2)']
    
    
    
    # lists of numbers, from analysis choice
    xCutL = ['xCut (in), Distance, analysis range']
    tCutL = ['tCut (sec), Time, analysis range']

    # lists of numbers, from recorded data
    horzL = ['Horizontal point of vertical height measurement (in.)']
    heightsL = ['Stem heights at x (in.)']

    # page two extra detail data
    try:
        stemCountLeftL = ["Left Sample Stem Count"]
        stemCountRightL = ["Right Sample Stem Count"]
        countDisStartL = ["Sample Count Start Point (in.)"]
        countDisEndL = ["Sample Count End Point (in.)"]
    except:
        ##
        print()
    
    # lists of numbers, from processed output values
    # rich EI analysis values, one row for each click, for encoderWorked = 'y' or disReferened = 'y'
    
    if encoderWorked == 'y' or disReferenced == 'y':
        xPeaksL = ['x of force peak (in.)']
    else: #encoderWorked == 'n' and disReferenced == 'n':
        xPeaksL = ['Time of force peak (s)']
    peaksL = ['Force peaks at x (lbs.)']
    hatPeaksL = ['Assumed height (in.), hatPeaks']           
    EIIsL = ['EI-Is (lbs*in^2)']
    EINsL = ['EI-Ns(lbs*in^2)']
    EIMsL = ['EI-Ms (lbs*in^2)']
    
    # raw data, sheet 2, copy of raw data original
    timeL = ['Time (s)']
    disL = ['Distance (in)']
    fprL = ['Force/row (lbs)']
##    aveHeightL = ['Avg height (in)']
##    fb_bottomL = ['Force bar bottom height (in)']
##    rowsL = ['Rows']
##    stemsL = ['Avg stem count']
##    sampDisL = ['Sample distance (in)']
    
##    if encoderWorked == 'y' or disReferenced == 'y': # if valid distance data
##        EIMsStr = ['%.3f ' % ele for ele in EIs[2]] # control deci places to 3 (stores as str)
##        EIMsFlo = [float(ele) for ele in EIMsStr] # convert back to float (for plotting)
##        
##        EIMsL.extend(EIMsFlo)
##        hatPeaksL.extend('%.3f ' % ele for ele in EIs[3])
##        aveEIIsL.append('%.3f ' % np.mean(EIs[0]))
##        aveEINsL.append('%.3f ' % np.mean(EIs[1]))
##        aveEIMsL.append('%.3f ' % np.mean(EIs[2]))
##        stdEIIsL.append('%.3f ' % np.std(EIs[0]))
##        stdEINsL.append('%.3f ' % np.std(EIs[1]))
##        stdEIMsL.append('%.3f ' % np.std(EIs[2]))
##        EIIsL.extend('%.3f ' % ele for ele in EIs[0])
##        EINsL.extend('%.3f ' % ele for ele in EIs[1])
        
##    else: # invalid/erroneous distance data #encoderWorked == 'n' and disReferenced == 'n':
##        #x = 'NA'
##        xPeaksL[0] = ['Time of force peak (s)']
##        varietyL.append('TIME BASED') #  Location: Page one, first column, row two in EI analyzed file. 
    
    # append all data into corresponding list
    if encoderWorked == 'y':
        analysisL.append('ENCODER WORKED')
    elif encoderWorked == 'n' and disReferenced == 'y':
        analysisL.append('DISTANCE REFERENCED')
    else: #encoderWorked == 'n' and disReferenced == 'n':
        analysisL.append('TIME BASED')
    varietyL.append(variety)
    plotnameL.append(plotname)
    detailL.append(detailText)
    filenameL.append(filename)
    rowsL.append(rows)
    fb_bottomL.append(fb_bottom)
    aveHeightL.append(height)
    stemsL.append(stems)
    sampDisL.append(sampDis)
    #spacingL.append('%.3f' % spacing)
    spacingL.append(round(spacing,3))
    

    #avgPeakL.append('%.3f' % avgPeak)
    avgPeakL.append(round(avgPeak,3))
    avgForceL.append(round(avgForce,3))
    areaUnderCurveL.append(round(areaUnderCurve,4))

    
    xCutL.extend(list(xCut))
    tCutL.extend(list(tCut))
    #tCutL.extend(['%.3f ' % ele for ele in tCut])
    
    horzL.extend(horz)
    heightsL.extend(heights)
    #peaksL.extend(['%.3f ' % ele for ele in peaks])
    peaksL.extend(list(peaks))
    xPeaksStr = ['%.3f ' % ele for ele in xPeaks]
    xPeaksFlo =[float(ele) for ele in xPeaksStr] 
    xPeaksL.extend(xPeaksFlo)
    EIIL.append(round(EI[0],3))
    EINL.append(round(EI[1],3))
    EIML.append(round(EI[2],3))
    
    
    
    timeL.extend(list(time[i:j]))
    if encoderWorked == 'y':
        disL.extend(list(dis[i:j]))
    elif encoderWorked == 'n' and disReferenced == 'y':
        disL.extend(list(disNew[i:j]))
    else: #encoderWorked == 'n' and disReferenced == 'n':
        disL.extend(list(dis[i:j]))
    fprL.extend(list(fpr[i:j]))

    try:
        stemCountLeftL.append(stemCountLeft)
        stemCountRightL.append(stemCountRight)
        countDisStartL.append(countDisStart)
        countDisEndL.append(countDisEnd)
        fb_middleL.append(fb_middle)
    except:
        ##
        print()

    #originalText = filename;
    #detailTextWithFileType = filename.split("_",2)[2]
    #detailText = detailTextWithFileType.replace(".xlsx","")
    if encoderWorked == 'n' and disReferenced == 'n':
        saveAt = addressProcessed + '_timebased' + '/' + variety + '_' + plot + '_'+ detailText + '_timebased' + ".xlsx" # addressProcessed + filename
    if encoderWorked == 'n' and disReferenced == 'y':
        saveAt = addressProcessed + '/' + variety + '_' + plot + '_'+ detailText + '_disref' + ".xlsx" # addressProcessed + filename + '_disref'

    else:
        saveAt = addressProcessed + '/' + variety + '_' + plotname + '_'+ detailText + ".xlsx" # addressProcessed + filename

    if overwriteAtWill=='y' and (os.path.exists(saveAt)):
                os.remove(saveAt)
    workbook = xlsxwriter.Workbook(saveAt)
    worksheet = workbook.add_worksheet('EI_Computations')
    worksheet2 = workbook.add_worksheet('Details')

    worksheet.set_column('A:AG', 12)
    
    # sheet 1: EI Computations, single values
    worksheet.write_column('A1', analysisL)
    worksheet.write_column('B1', varietyL)
    worksheet.write_column('C1', plotnameL)
    worksheet.write_column('D1', detailL)
    worksheet.write_column('E1', filenameL)
    worksheet.write_column('F1', rowsL)
    worksheet.write_column('G1', fb_bottomL)
    worksheet.write_column('H1', aveHeightL)
    worksheet.write_column('I1', stemsL)
    worksheet.write_column('J1', sampDisL)
    worksheet.write_column('K1', spacingL)
    
    worksheet.write_column('L1', avgPeakL)
    worksheet.write_column('M1', avgForceL)
    worksheet.write_column('N1', areaUnderCurveL)
    worksheet.write_column('O1', EIIL)
    worksheet.write_column('P1', EINL)
    worksheet.write_column('Q1', EIML)
    worksheet.write_column('R1', aveEIIsL)
    worksheet.write_column('S1', stdEIIsL)
    worksheet.write_column('T1', aveEINsL)
    worksheet.write_column('U1', stdEINsL)
    worksheet.write_column('V1', aveEIMsL)
    worksheet.write_column('W1', stdEIMsL)
    
    
    # sheet 1: EI Computations, columns, 2 values
    worksheet.write_column('X1', xCutL)
    worksheet.write_column('Y1', tCutL)
    
    # sheet 1: EI Computations, columns of length = number of clicks
    worksheet.write_column('Z1', horzL)
    worksheet.write_column('AA1', heightsL)
    worksheet.write_column('AB1', xPeaksL)
    worksheet.write_column('AC1', peaksL)
    worksheet.write_column('AD1', hatPeaksL)
    worksheet.write_column('AE1', EIIsL)
    worksheet.write_column('AF1', EINsL)
    worksheet.write_column('AG1', EIMsL)
    

    # sheet 2: details
    worksheet2.write_column('A1', timeL)
    worksheet2.write_column('B1', disL)
    worksheet2.write_column('C1', fprL)
    worksheet2.write_column('D1', rowsL)
    worksheet2.write_column('E1', stemsL)
    worksheet2.write_column('F1', sampDisL)
    worksheet2.write_column('G1', filenameL)

    # sheet 2: extra details
    try:
        worksheet2.write_column('H1', fb_middleL)
        worksheet2.write_column('I1', stemCountLeftL)
        worksheet2.write_column('J1', stemCountRightL)
        worksheet2.write_column('K1', countDisStartL)
        worksheet2.write_column('L1', countDisEndtL)
    except:
        print()
    
    

    
    # Graphing: EI, heights, fpr vs distance automatic plot
    # move this into the inside of def Excel
    if generateGraphs == 'y':
        chart = workbook.add_chart({'type': 'scatter'})
        chart.set_style(12)
        chart.set_size({'width': 750, 'height': 500})
        l = len(disL)
        r = len(xPeaksL)
        q = len(heightsL)
        if type(EIs[2]) is list: # able to plot against distance
            chart.set_x_axis({'name' : 'Travel distance (inches)'})
            chart.set_y_axis({'name' : 'Height (in.), EIM (lbs.*in^2)'})
            chart.set_y2_axis({'name' : 'Force/row (lbs.)'})

            chart.add_series({'name': '=EI_Computations!$AG1', 'categories': '=EI_Computations!$AB$2:$AB$'+str(r) \
                              , 'values': '=EI_Computations!$AG$2:$AG$'+str(r) \
                              ,'marker':{'type': 'circle','border': {'width': 0,'color': 'blue'},'': 8,'fill':{'color': 'blue'},},})
            chart.add_series({'name': '=EI_Computations!$AA1', 'categories': '=EI_Computations!$Z$2:$Z$'+str(q) \
                              , 'values': '=EI_Computations!$AA$2:$AA$'+str(q) \
                              ,'line':{'color':'red','width':1},'marker':{'type': 'diamond','border': {'width': 0,'color': 'red'},'size': 8 \
                                                                          ,'fill':{'color': 'red'},},})
            chart.add_series({'name': '=Details!$C1', 'categories': '=Details!$B$2:$B$'+str(l), 'values': '=Details!$C$2:$C$'+str(l), 'y2_axis' : 1 \
                              , 'line':{'color': '#F79646', 'transparency': 50,'width':1} \
                              ,'marker':{'type': 'square','border': {'width': 0,'color': '#F79646', 'transparency': 50},'size': 5 \
                                         ,'fill':{'color': '#F79646', 'transparency': 50},},})

        else: # must plot against time
            chart.set_x_axis({'name' : 'Time (s)'})
            chart.set_y_axis({'name' : 'Force/row (lbs.)'})
            chart.add_series({'name': '=Details!$C1', 'categories': '=Details!$A$2:$A$'+str(l), 'values': '=Details!$C$2:$C$'+str(l), 'y2_axis' : 1 \
                              , 'line':{'color': '#F79646', 'transparency': 50,'width':1} \
                              ,'marker':{'type': 'square','border': {'width': 0,'color': '#F79646', 'transparency': 50},'size': 5 \
                                         ,'fill':{'color': '#F79646', 'transparency': 50},},})
            
        worksheet.insert_chart('B4', chart)
        
    elif generateGraphs == 'n':
        print('Graphs not created.')
    else: # assume generateGraphs == 'n'
        print('Graphs not created.')

    
    workbook.close()

# MAIN FUNCTION    
for filename in os.listdir(folderToProcess): # loop through files in folder

    file = str(folderToProcess+'/'+filename)
    print('\n' + 'NEXT!' + '\n' + file)    
    
    plotname = filename.split("_",2)[1] # works for RAW files only
    
    try:
        detailWithFileType = filename.split("_",2)[2]
    except:
        detailWithFileType = ".xlsx"
                
        
    detailText = detailWithFileType.replace(".xlsx","")
    plotname = plotname.replace(".xlsx","")
    plotname = plotname.upper()
    plotnamesList = plotList
    plotIdx = plotnamesList.index(plotname) # where does the filename match the concat of 
    variety = varietyList[plotIdx] #
    #date = dateList[plotIdx-1] # this line was added to process the 2020 data
    #if date == dt(2022, 8, 20, 0, 0):
    #    continue
    print('\n' + variety + '\n' + plotname)
    varietyAndPlotname = (variety + ', ' + plotname)
    varietyAndPlotnameAndDetail = (variety + ', ' + plotname + ', ' + detailText)

    df = pd.read_excel(file) # convert Excel into pandas df

    time = np.array(df['Time (s)'])
    dis = np.array(df['Distance (in.)'])
    force = np.array(df['Force (lbs.)'])
    try:
        height = df['Height (in)'].iloc[0]
    except:
        height = df['Height(in.)'].iloc[0]

    try:
        fb_bottom = df['Fb Bottom height (in.)'].iloc[0]
    except:
        fb_bottom = df['Fb Bottom Height (in.)'].iloc[0]
    
    rows = 1 # df['Rows'].iloc[0]
    try:
        stems = df['Avg Stem Count'].iloc[0]
    except:
        stems = df['Ave Stem Count'].iloc[0]
        
    sampDis = df['Sample distance (in.)'].iloc[0]
    
    try:
        fb_middle = df["Fb Middle Height (in.)"].iloc[0]
        stemCountLeft=df["Left Sample Stem Count"].iloc[0]
        stemCountRight=df["Right Sample Stem Count"].iloc[0]
        countDisStart = df["Sample Count Start Point (in.)"].iloc[0]
        countDisEnd = df["Sample Count End Point (in.)"].iloc[0]
    except:
        print('No new data from 2021 upgrade')
    
        # mess this around
##    topRow = df.iloc[0]
##    height = topRow[3]#              
##    fb_bottom = topRow[4] #
##    rows = topRow[5]
##    stems = topRow[6] # 
##    sampDis = topRow[7] #
    spacing = 1/(stems/sampDis) # (1/(stems/inch) = (inches/stem)
    # print('spacing calc ', spacing) # Hide, CB
            
    fpr = force/rows # force per row # assume 1 row, for side hit stuff, for now.
    print('FB ', fb_bottom)
    
    
    # get heights along plot from user
    # alongPlot = getHeights()
    #heights = heightsArray[:,plotIdx]
    #heights = heights.tolist()

    # check that direction is forward, and that this will work
    direction = pushDirection(filename)
    print('\n' + 'Test direction is: ' + str(direction))
    if direction == 'forward':
        print('Proceed!')
    else:
        print('\n' + 'Stop!' + '\n' + 'The test direction for this file is not forward.'+ '\n' + 'Quit the program and remove this file from the test folder' + '\n' + 'or change the test folder.' + '\n' + 'This program can currently correctly analyze only forward-direction test files.')

    # This works for forwad direction tests but still isn't ready for service for tests in other directions yet.
    if direction == 'forward':
        try:
            horz = df["Horizontal Measurement Index (in.)"].iloc[0:7]
            heights = df["Stem Heights (in.)"].iloc[0:7]
            horz = horz.to_numpy()
            heights = heights.to_numpy()
        except:
            horz = [20, 40, 60, 80, 100, 120, 140,160] # Horizontal points here heights were measured. No heights for the current data set were measured beyond 160 inches. Unused horz numbers will be automatically removed.
            heights = [] # height at x
            heights = heightsArray[:,plotIdx]
            heights = heights.tolist()
    else:
        horz = []
        #horz = [20, 40, 60, 80, 100, 120, 140,160] # Horizontal points here heights were measured. No heights for the current data set were measured beyond 160 inches. Unused horz numbers will be automatically removed.
        heights = [] # height at x
        #heights = heightsArray[:,plotIdx]
        #heights = heights.tolist()

    i=0 # remove NaN values
    while i<len(heights):
        if math.isnan(heights[i]):
            nanIdx = i
            heights.pop(i)
            horz.pop(i)
        else:
            i=i+1
            
    print('Horizontal: ', horz)
    print('Heights: ', heights)
    

    if max(dis) > 10: # Assess if the encoder worked or not. Assuems that if it worked, the max value would exceeed 1 inch.
        encoderWorked = 'y' # 
    else: encoderWorked = 'n'

    print('Encoder? ', encoderWorked)
    print('max(dis) = ', str(max(dis)))
    print(plotname)
    
    if encoderWorked == 'n':
        xCut, disReferenced, disNew,i,j = initialPlot(dis, fpr, time, encoderWorked, horz, varietyAndPlotnameAndDetail, documentationFolder)
    elif encoderWorked == 'y':
        xCut = initialPlot(dis, fpr, time, encoderWorked, horz, varietyAndPlotnameAndDetail, documentationFolder)
        disReferenced = 'n'
        
    if encoderWorked == 'y':
        print('Distance cut at: ', xCut)
        getPeaks = choosePeaks(dis, fpr, xCut,varietyAndPlotnameAndDetail,encoderWorked, disReferenced,documentationFolder, horz)
    elif encoderWorked == 'n' and disReferenced == 'y':
        print('troubleshoot702')
        print('Distance cut at: ', xCut)
        getPeaks = choosePeaks(disNew, fpr, xCut,varietyAndPlotnameAndDetail,encoderWorked, disReferenced, documentationFolder, horz)
    else:
        print('Time cut at: ', xCut)
        getPeaks = choosePeaks(time, fpr, xCut,varietyAndPlotnameAndDetail,encoderWorked, disReferenced, documentationFolder, horz)

    if encoderWorked == 'y': # or disReferenced == 'y':
        i=0
        while xCut[0]>dis[i]: # if encode failed, used estimation from assumed travel speed and area under time curve
            i = i+1
        
        j=0
        while xCut[1]>dis[j]: # if encode failed, used estimation from assumed travel speed and area under time curve
            j = j+1

        areaUnderCurve = []
        areaUnderCurve = trapz(fpr[i:j],dis[i:j]) # 
        print('Area under curve:' + str(areaUnderCurve) + ' inch-pounds')
        avgForce = areaUnderCurve/(dis[j]-dis[i]) # pounds
        print('Average force:' + str(avgForce) + ' pounds')
        print('xCut in loop:' + str(xCut))
        tCut = [0,0]
        tCut[0] = time[i]
        tCut[1] = time[j]
    elif encoderWorked == 'n' and disReferenced == 'y':
        # if distance start and end points are typed in manually, at known reference points, due to comparison with data from same plot
        areUnderCurve = []
        areaUnderCurve = trapz(fpr[i:j],disNew[i:j]) # 
        print('Area under curve:' + str(areaUnderCurve) + ' inch-pounds')
        avgForce = areaUnderCurve/(disNew[j]-disNew[i]) # pounds
        print('Average force:' + str(avgForce) + ' pounds')
        print('xCut in loop:' + str(xCut))
        tCut = [0,0]
        tCut[0] = time[i] # should be i and j values produced inside of xCut if disReferenced == 'y'
        tCut[1] = time[j]
    
    elif encoderWorked == 'n' and disReferenced == 'n':
        tCut = xCut
        i=0
        while tCut[0]>time[i]: # if encode failed, used estimation from assumed travel speed and area under time curve
            i = i+1
        
        j=0
        while tCut[1]>time[j]: # if encode failed, used estimation from assumed travel speed and area under time curve
            j = j+1

        areUnderCurve = []
        areaUnderCurve = trapz(fpr[i:j],time[i:j]) # why not, second-pounds
        print('Area under curve:' + str(areaUnderCurve) + ' second-pounds')
        avgForce = areaUnderCurve/(time[j]-time[i]) # average
        print('Average force:' + str(avgForce) + ' pounds')
        xCut = [0,0]
        
    print('xCut = ' + str(xCut))
    print('tCut = ' + str(tCut))

    peaks = getPeaks[0] # force peaks
    xPeaks = getPeaks[1] # force peaks x pts
    # print('xPeaks ', xPeaks) # hide, CB
    # print('Peaks: ', peaks) # hide, CB
    avgPeak = np.mean(peaks)
    # print('Mean peak: ', avgPeak) # hide, CB
    
    # computer EI from single, mean values
    EII = EI_Interaction_Fx.EI_Interaction(avgPeak, fb_bottom, height,spacing)
    EIN = EI_No_Interaction_Fx.EI_NoInteraction(avgPeak, fb_bottom, height, spacing)
    EIM = (EII + EIN)/2
    EI = [EII, EIN, EIM]

    EI_Interaction_Fx.clearAll()
    EI_No_Interaction_Fx.clearAll()
    
    print('EII = ', EII) 
    print('EIN = ', EIN)
    print('EIM = ', EIM)

    # if useDis == True:
    if 1==0: # encoderWorked == 'y' or disReferenced == 'y':
        EIs = EIalong(xPeaks, peaks, horz, heights, fb_bottom, spacing)
        #print("EIs: ", EIs) # hide, CB
    else:
        EIs = ['NA', 'NA', 'NA', 'NA']

    plot = plotname
    try:
        Excel(filename, variety, plotname, detailText, time, dis, rows, fpr, fb_bottom, stems, sampDis, spacing, horz, heights, height, xPeaks, peaks, avgPeak, EI, EIs \
          , areaUnderCurve, xCut, disReferenced, encoderWorked, generateGraphs, stemCountLeft, stemCountRight, countDisStart, countDisEnd, fb_middle)

    except:
        Excel(filename, variety, plotname, detailText, time, dis, rows, fpr, fb_bottom, stems, sampDis, spacing, horz, heights, height, xPeaks, peaks, avgPeak, EI, EIs \
          , areaUnderCurve, xCut, disReferenced, encoderWorked, generateGraphs)


    print('\n' + 'DOVE DELIEVERED!') # Dove = data, duh.
    if encoderWorked == 'y':
        renameAndMoveRawDataHere = analyzedFolder+'/'+filename
    elif encoderWorked == 'n' and disReferenced == 'y':
        renameAndMoveRawDataHere = analyzedFolder +'_disReferenced'+'/'+filename
    elif encoderWorked == 'n' and disReferenced == 'n':
        renameAndMoveRawDataHere = analyzedFolder +'_timebased'+'/'+filename
        
    if overwriteAtWill=='y' and (os.path.exists(renameAndMoveRawDataHere)):
        os.remove(analyzedFolder+'/'+filename)
    os.rename(file,renameAndMoveRawDataHere)
    print('SOCEM data file moved to Analyzed folder.')

    # to pause program, to check variable values
##    proceedPlease = str(input('Would you like to proceed (y/n)? '))
##    if proceedPlease == 'n':
##        quit()
    
