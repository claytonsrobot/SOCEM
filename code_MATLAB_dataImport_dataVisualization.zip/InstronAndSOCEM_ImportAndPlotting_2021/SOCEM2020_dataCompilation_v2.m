% Title: SOCEM2021_dataCompilation_v2.m
% Author: Clayton Bennett
% Created: 16 March 2022
% Last edited: 16 March 2022
%
% Purpose:
% - Pull in data from analyzed SOCEM files, in "EI, Analyzed" and "EI,
%      Analyzed_timebased" folders.
% - This data does not include things like run numbers and hour label,
% though these are discernible from Test description.

format compact
importKeyVariables
%% Import data
% names key folders
directory_script = 'D:\Instron Wheat Testing 2021\MatlabCode';
%directory_data = 'C:\Users\clayton\Google Drive\School\University of Idaho\AgMEQ\SOCEM\SAVE_DATA_2020\'; % overview files and height data lives here
directory_data = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\SOCEM Script Testing\EI_analysis_2020_Barley\';
directory_data = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\SAVED_DATA_2020_Barley\firstHits\EI_outputFiles\';
if (directory_data(end)~='\')
    directory_data = strcat(directory_data,'\');
end

if (directory_script(end)~='\')
    directory_script = strcat(directory_script,'\');
end

% folders for dividing up the 2021 data
level1names = {'August20'};
level2names = {'EI_outputFiles'}; % Use both of these?
list_xlsxfiles = {};

%for i_level1name = 1:numel(level1names) % i_level1name=4;
%    for j_level2name = 1:numel(level2names) % j_level2name=1;
%        activefolder = strcat(directory_data,level1names{i_level1name},'\',level2names{j_level2name},'\');
        activefolder = directory_data;
        cd(activefolder)
        % files files in active folder, then remove files that are not of the
        % proper filetype
        desired_import_filetype = '.xlsx';
        list_xlsxfiles_active = strtrim(string(ls())); %string(ls()) % cellstr(ls())
        i=1;
        while i<=numel(list_xlsxfiles_active)
            if not(contains(list_xlsxfiles_active(i),desired_import_filetype))
                list_xlsxfiles_active(i)=[];
            else
                list_xlsxfiles_active(i) = strcat(activefolder,list_xlsxfiles_active(i));
                i=i+1;
            end
        end
        
        for i=1:numel(list_xlsxfiles_active)
            list_xlsxfiles{end+1}=list_xlsxfiles_active(i);
        end
%    end % end level 1 names loop
%end % end level 2 names loop
n_files = numel(list_xlsxfiles);

%% Import data from each file
% Look one column at a time. Record the column header name. If the column
% is greater than one row long, package it as a cell
sheetname1 = 'EI_Computations'; % These should be constant. Won't work if you change the names from the python output.
sheetname2 = 'Details';

% Some numeric data saved by python was output as string. Find which.
stringToDouble1=[];
stringToDouble2=[];
cellTrack1=[];
cellTrack2=[];

handle_waitbar=waitbar(0,strcat('Data is being imported from ',string(n_files),' SOCEM files. Computer speed, go!'));
for i=1:n_files
    
    filename = list_xlsxfiles{i};
    strfile=filename;
    opts1 = detectImportOptions(strfile,'Sheet',sheetname1,'PreserveVariableNames',1);
    opts2 = detectImportOptions(strfile,'Sheet',sheetname2,'PreserveVariableNames',1);
    
    charIdx=string(opts1.VariableTypes)=='char';
    charNames=opts1.VariableNames(charIdx);
    opts1=setvartype(opts1,charNames,'string');
    
    charIdx=string(opts2.VariableTypes)=='char';
    charNames=opts2.VariableNames(charIdx);
    opts2=setvartype(opts2,charNames,'string');
    
    % find duplicates, to remove from second sheet
    k=1;
    while k<=numel(opts2.VariableNames)
        if sum(opts2.VariableNames{k}==string(opts1.VariableNames))>0
            opts2.VariableNames(k)=[];
        else
            k=k+1;
        end
    end
    
    %create table
    T_active_sheet1 = table('Size',[size(opts1.VariableNames)],'VariableNames',opts1.VariableNames,'VariableTypes',opts1.VariableTypes);
    T_active_sheet2 = table('Size',[size(opts2.VariableNames)],'VariableNames',opts2.VariableNames,'VariableTypes',opts2.VariableTypes);
    
    % get raw data
    t_active_sheet1 = readtable(filename,opts1,'Sheet',sheetname1);
    t_active_sheet2 = readtable(filename,opts2,'Sheet',sheetname2);
    
    % allocate raw data into a single row for sheet 1
    for k = 1:width(t_active_sheet1)
        columnData=rmmissing(t_active_sheet1.(k));
        if isempty(columnData)
            if sum(cellTrack1==k)>0
                columnData = [];
                T_active_sheet1.(k)={columnData};
            elseif sum(cellTrack1==k)==0 && sum(stringToDouble1==k)>0
                columnData = NaN;
                T_active_sheet1.(k)=columnData;
            end
        elseif numel(columnData)>1
            if isstring(columnData) && logical(mean(not(isnan(double(columnData)))))
                columnData = double(columnData);
                if sum(stringToDouble1==k)==0
                    stringToDouble1(end+1)=k;
                end
                
            end
            
            if sum(cellTrack1==k)==0
                cellTrack1(end+1)=k;
            end
            T_active_sheet1.(k)={columnData};
        elseif numel(columnData)==1
            if isstring(columnData) && not(isnan(double(columnData))) % some numeric data was saved by python as a string. This fixes it.
                columnData = double(columnData);
                if sum(stringToDouble1==k)==0
                    stringToDouble1(end+1)=k;
                end
            end
            T_active_sheet1.(k)=columnData;
        end
    end
    %% sheet 2
        for k = 1:width(t_active_sheet2)
        columnData=rmmissing(t_active_sheet2.(k));
        if isempty(columnData)
            if sum(cellTrack2==k)>0
                columnData = [];
                T_active_sheet2.(k)={columnData};
            elseif sum(cellTrack2==k)==0 && sum(stringToDouble1==k)>0
                columnData = NaN;
                T_active_sheet2.(k)=columnData;
            end
        elseif numel(columnData)>1
            if isstring(columnData) && logical(mean(not(isnan(double(columnData)))))
                columnData = double(columnData);
                if sum(stringToDouble2==k)==0
                    stringToDouble2(end+1)=k;
                end
                
            end
            
            if sum(cellTrack2==k)==0
                cellTrack2(end+1)=k;
            end
            T_active_sheet2.(k)={columnData};
        elseif numel(columnData)==1
            if isstring(columnData) && not(isnan(double(columnData))) % some numeric data was saved by python as a string. This fixes it.
                columnData = double(columnData);
                if sum(stringToDouble2==k)==0
                    stringToDouble2(end+1)=k;
                end
            end
            T_active_sheet2.(k)=columnData;
        end
    end
    %%
    
    % allocate raw data into a single row for sheet 2
%     for k = 1:width(t_active_sheet2)
%         columnData=rmmissing(t_active_sheet2.(k));
%         if numel(columnData)>1
%             T_active_sheet2.(k)={columnData};
%         elseif numel(columnData)==2
%             if isstring(columnData) && not(isnan(double(columnData))) % some numeric data was saved by python as a string. This fixes it.
%                 columnData = double(columnData);
%             end
%             if sum(columnTrack2==k)==0
%                 cellTrack2(end+1)=k;
%             end
%             T_active_sheet2.(k)=columnData;
%         end
%     end
    
    T_active = [T_active_sheet1,T_active_sheet2];
    
    if i==1
        T = T_active;
        msg='1'
    elseif string(T.Properties.VariableNames)==string(T_active.Properties.VariableNames);
        T=[T;T_active];
    else % different variable names, different number of columns
        msg= strcat("Your files have a columns that differ.", newline(), filename);
        disp(msg)
        % if class(string), use <missing>
        % if class(double), use NaN
        % if other, use ....?
    end
    
    fprintf('%d.', i)
    waitbar(i/n_files,handle_waitbar)
    
end
close(handle_waitbar)
fprintf('\n')
cd(directory_script)

%% prep for CSV, remove columns with cells
Tcsv=T;
[rows,cols]=size(T);
c=1;
while c<=cols
    if iscell(Tcsv.(c))
        Tcsv.(c)=[];
    elseif logical(mean(ismissing(Tcsv.(c))))
        Tcsv.(c)=[];
    elseif isstring(Tcsv.(c))
        c=c+1;
    elseif sum(Tcsv.(c))==0
        Tcsv.(c)=[];
    
    else
        c=c+1;
        
    end
    [rows,cols]=size(Tcsv);
end

%% XSLX creation
% cd(directory_compiledData)
% filenameCSV_withCells = 'T_wheat2020_SOCEM_directImport_withCells.csv';
% %writetable(T,filenameCSV_withCells,'FileType','Text','WriteVariableNames',1)
% 
% filenameCSV = 'T_wheat2020_SOCEM_directImport.csv';
% %writetable(Tcsv,filenameCSV,'FileType','Text','WriteVariableNames',1)
% cd(directory_script)

%filenameXLSX = strcat('T_wheat2021_',useUnits,'.xlsx');
filenameXLSX = 'T_SOCEM_barley2020_correctedHeights.XLSX';
cd(directory_compiledData)
%writecell(Tcsv.Properties.VariableNames,filenameXLSX,'FileType','Spreadsheet','Range','A1')
%writecell(Tcsv.Properties.VariableUnits,filenameXLSX,'FileType','Spreadsheet','Range','A2')
writetable(Tcsv,filenameXLSX,'FileType','Spreadsheet','WriteVariableNames',1)
cd(directory_code)

