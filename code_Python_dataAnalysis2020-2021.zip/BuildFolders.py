'''
Title: BuiltFolders.py
Author: Clayton Bennett
Created: 02/17/2022
Last edited: 02/17/2022

Description:
'''
import numpy as np
import os

def buildfolders(pathtop):
    #pathtop = r'D:\Instron Wheat Testing 2021\SAVED_DATA_2021\emptySkeletonFolders'
    basename = os.path.basename(os.path.normpath(pathtop))

    os.chdir(pathtop)
    listdir=os.listdir()
    # print(listdir)

    targetlistdir = ['analyzedRaw', 'analyzedRaw_disReferenced', 'analyzedRaw_timebased', 'cleanRaw', 'cleanRaw - Copy' \
                 , 'Documentation', 'EI_outputFiles', 'encoderWorkedNo', 'encoderWorkedYes', 'error']

    if os.path.exists(pathtop):
        for folder in targetlistdir:
            targetfolder=str(pathtop+'\\'+folder)
            if not os.path.exists(targetfolder):
                os.makedirs(targetfolder)
                print("A sapling folder tree has been planted in " + basename + ".")
            else:
                print(basename + " already has " + folder)
        #return basename
    else:
        createPathtop = str(input('The folder you want to use does not exist. Would you like to build it? (y/n) '))
        if createPathtop == 'y':
            os.makedirs(pathtop)
            for folder in targetlistdir:
                targetfolder=str(pathtop+'\\'+folder)
                os.makedirs(targetfolder)
                print(basename + "created!" + "A sapling folder tree has been planted in " + basename + ".")
            


        ##if listdir==targetlistdir:
        ##    print("The desired folder tree exists")
        ##else:




