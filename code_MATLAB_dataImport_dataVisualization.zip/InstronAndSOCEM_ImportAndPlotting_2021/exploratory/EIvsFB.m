% Purpose: find average of Forcebar height in each bin/unique value

Ts1=Ts(Ts.j==1,:);
Ts10=Ts1(Ts1.Hour==0,:);
hunique=unique(Ts10.ForceBarHeight);
fbavg=zeros(numel(hunique),3);

cd(directory_code)


for k=1:numel(hunique)
    fbavg(k,1)=hunique(k);
    fbavg(k,2)=mean(table2array(Ts(hunique(k)==Ts10.ForceBarHeight,find(Ts10.Properties.VariableNames=="EIM"))));
    fbavg(k,3)=sum(hunique(k)==Ts10.ForceBarHeight);
    
end

subplot(1,2,1)
[abc,a,b,c,Rsq,RMSE,SSE,lm,f0,string1]=linearFitting(Ts10.EIM,Ts10.ForceBarHeight,1,1,1);
h1=annotation(gcf,'textbox',[0.121,0.78,1,1],'String',string1,'EdgeColor','none','FitBoxToText','on','verticalalignment', 'bottom', 'color','k');
ylabel('Forcebar height setting (inches)')
xlabel('SOCEM EI (lb*in^2)')
title('Forcebar Height vs EI trend, SOCEM Wheat 2021')

subplot(1,2,2)
[abc,a,b,c,Rsq,RMSE,SSE,lm,f0,string2]=linearFitting(fbavg(:,2),fbavg(:,1),1,1,1);
h2=annotation(gcf,'textbox',[0.121,0.78,1,1],'String',string2,'EdgeColor','none','FitBoxToText','on','verticalalignment', 'bottom', 'color','k');
ylabel('Forcebar height setting (inches)')
xlabel('SOCEM EI (lb*in^2)')
title('Forcebar Height vs EI trend, SOCEM Wheat 2021')

%%
close gcf

Ts10_Irv = Ts10(Ts10.Variety=="Irv",[6,7,11,12,13,21])
Ts10_Norwest553 = Ts10(Ts10.Variety=="Norwest 553",[6,7,11,12,13,21])
plot(Ts10.EIM, Ts10.AvgStemCount,'o')
hold on
plot(Ts10_Irv.EIM, Ts10_Irv.AvgStemCount,'or')
plot(Ts10_Norwest553.EIM, Ts10_Norwest553.AvgStemCount,'og')

%%

uniquevariety=unique(Ts10.Variety);

colormat = [77/255 190/255 70/255 % green
0,0.4470,0.7410 % blue
255/255 153/255 200/255 % pink
0.9290,0.6940,0.1250  % yellow
0.4940,0.1840,0.5560 % purple
0.6350,0.0780,0.1840 % crimson
178/255 140/255 0/255 % tan
0/255 0/255 0/255 % black
255/255 155/255 50/255 % orange
75/255 190/255 240/255 % light blue
155/255 155/255 155/255 % gray
150/255 255/255 150/255 % sea green
0/255 0/255 0/255 % ugly bright yellow
255/255 0/255 0/255]; % bright red
shapemat = string({'+','o','x','+','*','s','d','v','^','<','>','p','h','h'});
linemat = string({'-.','-.','-.','-.','-.','-.','-.','-','-.','-.','-.','-.','-.','-.'});
stylemat = linemat+shapemat; % shapemat;% linemat+shapemat; % edit line style here
sizemat = 100*ones(numel(uniquevariety),1);

for k=1:numel(uniquevariety)
Ts10_temp=Ts10(Ts10.Variety== uniquevariety(k),:);
plot(Ts10_temp.EIM, Ts10_temp.AvgStemCount,shapemat(k),'Color',colormat(k,:));
hold on
end

legend(uniquevariety,'Location','eastoutside')
title('EI vs Stem count')
ylabel('Avg Stem count')
xlabel('SOCEM EI (lb*in^2)')
text(3,50,'A linear trend exemplifies a potential problem with how stem density is handled.')
%%
% Avg Stem count
% FB height/Avg Stem height
% Avg Force Peak
% Ei

for k=1:numel(uniquevariety)
Ts10_temp=Ts10(Ts10.Variety== uniquevariety(k),:);
ratioFBoAvgH=Ts10_temp.ForceBarHeight./Ts10_temp.AvgHeight;
plot3(Ts10_temp.EIM, Ts10_temp.AvgStemCount,ratioFBoAvgH,shapemat(k),'Color',colormat(k,:));
hold on
end

legend(uniquevariety,'Location','eastoutside')
title('EI vs Stem count vs FB height / Avg Stem Height')

xlabel('SOCEM EI (lb*in^2)')
ylabel('Avg Stem count')
zlabel('FB height / Avg Stem Height')

%%
close gcf
hold off
plot(Ts10.EIM,Ts10.AvgForcePeak,'o')

for k=1:numel(uniquevariety)
Ts10_temp=Ts10(Ts10.Variety== uniquevariety(k),:);
ratioFBoAvgH=Ts10_temp.ForceBarHeight./Ts10_temp.AvgHeight;
plot3(Ts10_temp.EIM, Ts10_temp.AvgForcePeak,ratioFBoAvgH,shapemat(k),'Color',colormat(k,:));
hold on
end

legend(uniquevariety,'Location','eastoutside')
title('EI vs Avg Force Peak vs FB height / Avg Stem Height')

xlabel('SOCEM EI (lb*in^2)')
ylabel('Avg Force Peak')
zlabel('FB height / Avg Stem Height')
%%
close gcf
hold off
%plot(Ts10.EIM,Ts10.AvgForcePeak,'o')

for k=1:numel(uniquevariety)
Ts10_temp=Ts10(Ts10.Variety== uniquevariety(k),:);
ratioFBoAvgH=Ts10_temp.ForceBarHeight./Ts10_temp.AvgHeight;
plot3(Ts10_temp.EIM, Ts10_temp.AvgForcePeak,Ts10_temp.AvgStemCount,shapemat(k),'Color',colormat(k,:));
hold on
end

legend(uniquevariety,'Location','eastoutside')
title('EI vs Stem count vs Avg Force Peak')

xlabel('SOCEM EI (lb*in^2)')
ylabel('Avg Force Peak')
zlabel('Stem Count')

%%
Ts10.AvgDiameter=zeros(height(Ts10),1);
for i=1:height(Ts10)
Ts10.AvgDiameter(i) = mean(table2array(Ti(Ts10.Plot(i)==Ti.Plot,find(Ti.Properties.VariableNames=="NodeMajorDiameter"))));

end

%plot(Ts10.AvgDiameter,Ts10.AvgForcePeak,'o')
Ts10(Ts10.AvgDiameter>3.7,:)
[abc,a,b,c,Rsq,RMSE,SSE,lm,f0,string2]=linearFitting(Ts10.AvgDiameter,Ts10.AvgForcePeak,1,1,1);
h2=annotation(gcf,'textbox',[0.121,0.78,1,1],'String',string2,'EdgeColor','none','FitBoxToText','on','verticalalignment', 'bottom', 'color','k');

%%
for k=1:numel(uniquevariety)
Ts10_temp=Ts10(Ts10.Variety== uniquevariety(k),:);
ratioFBoAvgH=Ts10_temp.ForceBarHeight./Ts10_temp.AvgHeight;
plot3(Ts10_temp.AvgDiameter.^4, Ts10_temp.AvgForcePeak,Ts10_temp.AvgStemCount,shapemat(k),'Color',colormat(k,:));
hold on
end

legend(uniquevariety,'Location','eastoutside')
title('Diameter vs Stem count vs Avg Force Peak')

xlabel('Avg Diameter^4 (in^4)')
ylabel('Avg Force Peak')
zlabel('Stem Count')

%%
for k=1:numel(uniquevariety)
Ts10_temp=Ts10(Ts10.Variety== uniquevariety(k),:);
ratioFBoAvgH=Ts10_temp.ForceBarHeight./Ts10_temp.AvgHeight;
%proportional_temp=(Ts10_temp.AvgDiameter.*Ts10_temp.AvgStemCount.*Ts10_temp.ForceBarHeight); % 
%proportional_temp=(Ts10_temp.AvgDiameter.*Ts10_temp.AvgStemCount.*Ts10_temp.AvgHeight); % 
%proportional_temp=(Ts10_temp.AvgDiameter.*Ts10_temp.AvgStemCount.*(ratioFBoAvgH)); % .

proportional_temp=((Ts10_temp.AvgDiameter.^4)); % 
proportional_temp=((Ts10_temp.AvgDiameter.^4)./Ts10_temp.AvgStemCount); % 
%proportional_temp=(Ts10_temp.AvgStemCount);
%proportional_temp=((Ts10_temp.AvgStemCount); % 
%proportional_temp=((Ts10_temp.AvgDiameter.^1).*(Ts10_temp.AvgStemCount.^1)./(ratioFBoAvgH)); % ./(ratioFBoAvgH)
%proportional_temp=((Ts10_temp.AvgDiameter.^2).*(Ts10_temp.AvgStemCount.^2)./(ratioFBoAvgH)); % ./(ratioFBoAvgH)
%proportional_temp=((Ts10_temp.AvgDiameter.^1).*(Ts10_temp.AvgStemCount.^1)./(ratioFBoAvgH.^2)); % ./(ratioFBoAvgH)
proportional_temp2=(ratioFBoAvgH); % ./(ratioFBoAvgH)


data_temp=Ts10_temp.EIM;
data_temp2=Ts10_temp.AvgForcePeak;
data_temp3=Ts10_temp.AreaUnderCurve;
x=mean(proportional_temp);
x2=mean(proportional_temp2);
y=mean(data_temp);
y2=mean(data_temp2);
y3=mean(data_temp3);

plot(x,y,shapemat(k),'Color',colormat(k,:));
%plot(proportional_temp,data_temp,shapemat(k),'Color',colormat(k,:));

hold on
end

legend(uniquevariety,'Location','eastoutside')
title('Proportional Coeff vs EIM')
title('Proportional Coeff vs Avg Force Peak')
title('EIM vs Avg Force')
title('EIM vs Area Under Curve')
title('Proportional Coeff vs AreaUnderCurve')
title('EIM vs AvgDiameter^4')
title('EIM vs Stem Count')
title('AvgDiameter^4 vs Avg Force Peak')
title('AvgDiameter^4 vs SOCEM EIM')

xlabel('EIM (lb*in^2)')

xlabel('Porportional coefficient')
xlabel('Force Bar Height / Avg Plot Height')
xlabel('Stem Count')
xlabel('Avg Stem Diameter^4 (mm^4)')

ylabel('Avg Force Peak (lb)')
ylabel('SOCEM EIM (lb*in^2)')
%ylabel('AreaUnderCurve (lb*in)')
%text(1.1*10^5,1.2,strcat('Proportional coeff = ',string(newline),'(AvgDiam^2)*(AvgStemCount^2)/(ratioFBoAvgH))'))
%text(50,0.8,strcat('Proportional coeff = ',string(newline),'(AvgDiam)*(AvgStemCount)/(ratioFBoAvgH))'),'Rotation',90)
text(420,1.2,strcat('Proportional coeff = ',string(newline),'(AvgDiam)*(AvgStemCount)/(ratioFBoAvgH))'),'Rotation',0)
%text(520,1.2,strcat('Proportional coeff = ',string(newline),'(AvgDiam)*(AvgStemCount)/(ratioFBoAvgH^2))'))

%% Plot Tn.StiffnessDifference  vs Ts.EIM vs Ti.EI
Newtons2Pounds = 0.225;
mmsqr2insqr = 1/645;
uniqueplotTn=unique(Tn.Plot);
legendstring={};
k=1;
for i=1:length(uniqueplotTn)
    p=uniqueplotTn(i);
    if sum(Ts10.Plot==p)>0
        TsEI=table2array(Ts10(Ts10.Plot==p,find(Ts10.Properties.VariableNames=="EIM")));
        TiEI=mean(table2array(Ti(Ti.Plot==p,find(Ti.Properties.VariableNames=="EI"))).*Newtons2Pounds.*mmsqr2insqr);
        TnSPD=mean(table2array(Tn(Tn.Plot==p,find(Tn.Properties.VariableNames=="StiffnessPercentDifference"))));
        
        variety=table2array(Ts10(Ts10.Plot==p,find(Ts10.Properties.VariableNames=="Variety")));
        if variety == "Irv"
            legendstring{end+1}=strcat({'Irv, '},p);
            plot(TnSPD,TiEI,'^b')%shapemat(i),'Color',colormat(i,:))
            hold on
        elseif variety == "Norwest 553"
            legendstring{end+1}=strcat({'Norwest 553, '},p);
            plot(TnSPD,TiEI,'vr')%shapemat(i),'Color',colormat(i,:))
            hold on
        elseif TiEI>9.4
            legendstring{end+1}=strcat(variety,{', '},p);
            plot(TnSPD,TsEI,'*','Color',colormat(k,:))
            hold on
            k=k+1;
        else
            legendstring{end+1}=(p);
            plot(TnSPD,TiEI,'oc')%shapemat(i),'Color',colormat(i,:))
            hold on
        end
    end
end
legend(legendstring,'Location','eastoutside')

xlabel('Stiffness Difference (N*mm)')
xlabel('Stiffness Difference %')
xlabel('Diameter Difference (mm)')
ylabel('SOCEM EI (lb*in^2)')
ylabel('Instron EI (lb*in^2)')
title(strcat('Instron Node to Node Stiffness Difference',string(newline),'Compared to SOCEM EI'))
title(strcat('Instron Node to Node Stiffness Percent Difference',string(newline),'Compared to SOCEM EI'))
title(strcat('Instron Node to Node Diameter Percent Difference',string(newline),'Compared to SOCEM EI'))
title(strcat('Instron Node to Node Diameter Percent Difference',string(newline),'Compared to Instron EI'))
title(strcat('Instron Node to Node Diameter Difference',string(newline),'Compared to Instron EI'))
title(strcat('Instron Node to Node Stiffness Percent Difference',string(newline),'Compared to Instron EI'))
