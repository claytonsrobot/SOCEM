% title: SOCEM_RawPlotterSamePlot.m
% author: Clayton Bennett
% created: August 30, 2021
% last edits: Augus 30, 2021
% %%%

% Plot everything in the directory on top of each other

%% Directory choice

% Edit this to change directory and generate a different plot.
plotName = 'HW218';
heightPercentage = '70';

% Don't edit this.
directory_SW436 = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Patent\Visco Comparison 70 vs 90 percent\Copy - SW436 - 90percent\';
directory_SW136 = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Patent\Visco Comparison 70 vs 90 percent\Copy - SW136 - 90percent\';
directory_HW422 = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Patent\Visco Comparison 70 vs 90 percent\Copy - HW422 - 70percent\';
directory_SW407 = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Patent\Visco Comparison 70 vs 90 percent\Copy - SW407 - 90percent\';
directory_CF147 = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Patent\Visco Comparison 70 vs 90 percent\Copy - CF147 - 70percent\';
directory_CF342 = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Patent\Visco Comparison 70 vs 90 percent\Copy - CF342 - 70percent\';
directory_HW218 = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Patent\Visco Comparison 70 vs 90 percent\Copy - HW218 - 70percent\';

    
%

directory = eval(strcat('directory_',plotName));
directory_savePlot = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Patent\Visco Comparison 70 vs 90 percent\';
directory_processingCode = 'C:\Users\clayton\OneDrive - University of Idaho\AqMEQ\SOCEM\Processing Code - Research Camp Echo\';

cd(directory_savePlot);
%cd(directory_processingCode);

%% initialize table

            %% Identify Instron files that have individual test arrays for Time, Displacement, and Force.
            %individualFileNameXLSX = strcat('RAW','*.xlsx'); % Ensure that only CSV files are looked for.
            individualFileNameXLSX = strcat('*.xlsx'); % Ensure that only CSV files are looked for.
            filelist_individual = dir(strcat(directory,individualFileNameXLSX)); % INPUT OPPORTUNITY.
            files_individual = {filelist_individual.name};
            % 
            % "files_indvidual" is a list of CSV files that start with
            % "individualFileName". This name will be tranlated to the expected
            % overview filename for each instance.
            % %%%

            %% PREPARE THE TABLE
            n = numel(files_individual)'; % How many indivdual files are there in the directory?

            varnames = {'i','File','Time', 'Distance','Force','AverageForce'};
            S = cell2table(cell(n,numel(varnames)), 'VariableNames', varnames); % Create table T.
            S.i = nan(height(S),1); % Prepare column "i" to be numbers.
            %S.Plot = strings([height(S),1]); % Prepare column "Plot" to be strings.
            %S.Run = nan(height(S),1); % Prepare column "Run" to be numbers.
            S.File = strings([height(S),1]); % Prepare column "File" to be strings.
            S.AverageForce = nan(height(S),1); % Prepare column "Run" to be numbers.
            section1of7 = "The table S has been prepped, with index, name, and array variables initialized." % Output message.
             %% Naming Interpretation, if the name refers to sample numbers, notes, etc.
            % % %% Variables that are managed here:
            % % %    Filename
            % % %        Referred to as:
            % % %            File
            % % %            T.File(j)
            % % %            file_individual(j)
            % % % 
            % % %    Plotname
            % % %        Referred to as:
            % % %            Plot
            % % %            T.Plot(j)
            % % % 
            % % % 
            % % %    Run number
            % % %        Referred to as:
            % % %            Run
            % % %            T.Run(j)
            % % %        Based on how many repeated tests were run on each stem.
            % % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % %
            % %  All of this information comes directly from the filename for each
            % % %%      indivdual test.
            % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % 
             for j=1:n
            %     
            %     % Identify each file name, one at a time.
                File = string(files_individual(j)); 
            %     
            %     % %% Store active variables, pulled from each file name, into row j of table T.
                 S.i(j)=j;
                 S.File(j)=File;
            %     
             end
            % 
             section2of7 = "File names have been interpretted." % Output message.

            %% Display first five rows of the table T, so that you know what it looks like.

                headT_preDataImport = head(S,5) % Display.

            section3of7 = "Sample view of table S has been displayed."
            %% IMPORT ARRAYS FROM INDIVIDUAL FILES
            % This is slow, because each file must be opened, recorded, and closed. That's okay.
            % This import method should work for all individual Instron files.

            heightS=height(S);
            handle_waitbar_individualFiles=waitbar(0,strcat('Arrays are being imported from ',string(heightS),'individual SOCEM files. It is slow. But it is probably faster than you.')); % develop this more

            for j = 1:height(S)
                %fprintf('%d,', j); % As a functinal loading bar, this will print j, the index
                %   number of the row.
                waitbar(j/height(S),handle_waitbar_individualFiles)
                %j
                %S.File(j)
                filename = strcat(directory,S.File(j));
                c=readtable(filename,'Filetype','spreadsheet', 'Range','A:C','PreserveVariableNames',1);
                %[Time, Distance,Force]=csvimport(strcat(directory, S.File{j}),'columns',[1,2,3],'noHeader', true);
                Time = c(1:end,1);
                Distance = c(1:end,2);
                Force = c(1:end,3);

                hopeArray = find(table2array(Time)<0.0005);
                if numel(hopeArray)>=2
                    hopeIndex = hopeArray(2)-1;
                    Time = Time(1:hopeIndex,1);
                    Distance = Distance(1:hopeIndex,1);
                    Force = Force(1:hopeIndex,1);
                    % column is often messed up and (way) larger than 0
                end

                Time = table2array(Time);
                Distance = table2array(Distance);
                Force = table2array(Force);
                % %% Remove first value from each imported column.
                Time=Time(2:end);
                Distance=Distance(2:end);
                Force=Force(2:end);

                % %% Store entire arrays for each Instron test into each row j of table T.
                S.Time(j)=mat2cell(Time,numel(Time),1);
                S.Distance(j)=mat2cell(Distance,numel(Distance),1);
                S.Force(j)=mat2cell(Force,numel(Force),1);
                S.AverageForce(j)=mean(Force);

            end

            close(handle_waitbar_individualFiles)

            %  Up to this point, most things apply to importing only individual
            % %%      files.
            section4of7 = "Arrays have been imported from individual files."
            %% Prepare the table S, by adding more columns, to import numerical and text data from overview files.
            % %% This section is possibly too custom to scale, because different


            %S.LoadDeflection = nan(height(S),1); % Prepare column "LoadDeflection" to be numbers.
            %S.Notes = strings([height(S),1]);

            % section5of7 = "The table is prepared for overview values."
            %% Go through each line in table and assign loadDeflection, Modulus, MaxLoad, DisplacementAtMaxLoad, Notes, BreakType

            %% Descriptions and units
            % %% Is scalable only if in metric and these are the expected variables. +*#*#*#*#*#*+
            S.Properties.VariableUnits = {'','', 's', 'in', 'lb', 'lb'}; 
            S.Properties.VariableDescriptions{'Time'} = 'Array of time values during SOCEM test.';
            S.Properties.VariableDescriptions{'Distance'} = 'Array of distance values during SOCEM test.';
            S.Properties.VariableDescriptions{'Force'} = 'Array of force values during SOCEM test.';
            S.Properties.VariableDescriptions{'AverageForce'} = 'Average from array of force values';

            section7of7 = "Descriptions and units have been added to the table. The function is complete."

%% Import raw data into table

%% run calculations, add to table

%% plot raw data, SW407
% overlay all table entries onto same plot
subplot(2,2,1)
heightPercentage = '90';
plotName = 'SW407';
S=S_SW407_import;
for j = 1:height(S)
    
    %plot each
    
    % plot best fit line through points 3:end
    % display slope number or percentage
    
%hold on

%title()
%xlabel()
%ylabel()
    plot(cell2mat(S.Distance(j)),cell2mat(S.Force(j)),'LineWidth',1.0);
    hold on
    %plot(cell2mat(S.Distance(j)),ones(numel(cell2mat(S.Distance(j))),1)*S.AverageForce(j),'r-')
    %plot(cell2mat(S.Distance(j)),ones(numel(cell2mat(S.Distance(j))),1)*min(cell2mat(S.Force(j))),'c-')
    %plot(cell2mat(S.Distance(j)),ones(numel(cell2mat(S.Distance(j))),1)*max(cell2mat(S.Force(j))),'m-')

% legend?
end

    string_title=strcat('Repeated Tests, Plot:_.', plotName ,', Bar Height:_.',heightPercentage,'%');
    title(string_title)
    title('Repeated Tests, Plot: SW407, Bar Height: 90%')
    
    xlabel('Distance (in)')
    ylabel('Force (lbs)')
    
    axis([0,200,0,4.5])
    legend('Run 1','Run 2', 'Run 3', 'Run 4','Location', 'north')
    fig = gcf;
    filenametext = strcat(plotName,'_',heightPercentage,'percent','.png');
    %exportgraphics(fig, filenametext,'Resolution',300)
    
    hold off

cd(directory_processingCode);

%% plot raw data, HW218
% overlay all table entries onto same plot
subplot(2,2,2)
heightPercentage = '70';
plotName = 'HW218';
S=S_HW218_import;
for j = 1:height(S)
    
    %plot each
    
    % plot best fit line through points 3:end
    % display slope number or percentage
    
%hold on

%title()
%xlabel()
%ylabel()
    plot(cell2mat(S.Distance(j)),cell2mat(S.Force(j)),'LineWidth',1.0);
    hold on
    %plot(cell2mat(S.Distance(j)),ones(numel(cell2mat(S.Distance(j))),1)*S.AverageForce(j),'r-')
    %plot(cell2mat(S.Distance(j)),ones(numel(cell2mat(S.Distance(j))),1)*min(cell2mat(S.Force(j))),'c-')
    %plot(cell2mat(S.Distance(j)),ones(numel(cell2mat(S.Distance(j))),1)*max(cell2mat(S.Force(j))),'m-')

% legend?
end

    string_title=strcat('Repeated Tests, Plot:_.', plotName ,', Bar Height:_.',heightPercentage,'%');
    title(string_title)
    title('Repeated Tests, Plot: HW218, Bar Height: 70%')
    
    xlabel('Distance (in)')
    ylabel('Force (lbs)')
    
    axis([0,200,0,8])
    legend('Run 1','Run 2', 'Run 3', 'Run 4','Location', 'north')
    fig = gcf;
    filenametext = strcat(plotName,'_',heightPercentage,'percent','.png');
    %exportgraphics(fig, filenametext,'Resolution',300)
    
    hold off

cd(directory_processingCode);



